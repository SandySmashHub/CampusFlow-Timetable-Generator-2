'use strict';
const { schedule } = require('./src/scheduler');
const { validate }  = require('./src/validator');
const { proposeMove, applyMove } = require('./src/editor');
const { CONFIG } = require('./src/data');

let pass=0, fail=0;
function test(name, fn) {
  try { fn(); console.log('PASS', name); pass++; }
  catch(e) { console.log('FAIL', name, '=>', e.message); fail++; }
}
function assert(cond, msg) { if (!cond) throw new Error(msg || 'Assertion failed'); }

// ── SCHEDULE DEMO DATASET ──────────────────────────────────
let demoResult = null;

test('T01: Demo dataset – complete schedule', () => {
  demoResult = schedule(CONFIG);
  assert(demoResult.status === 'complete',
    'status=' + demoResult.status + ' unscheduled=' + demoResult.unscheduledTasks.length);
});

test('T02: Validator passes on demo result', () => {
  const vr = validate(demoResult.sessions, CONFIG);
  assert(vr.valid, 'errors=' + vr.errors.map(e => e.code + ':' + e.message).join(', '));
});

test('T03: Validator reports complete', () => {
  const vr = validate(demoResult.sessions, CONFIG);
  assert(vr.complete, 'not complete – scheduled=' + vr.summary.totalScheduled + '/' + vr.summary.totalRequired);
});

test('T04: No faculty clashes (V05)', () => {
  const vr = validate(demoResult.sessions, CONFIG);
  const clashes = vr.errors.filter(e => e.code === 'V05');
  assert(clashes.length === 0, JSON.stringify(clashes));
});

test('T05: No division clashes (V04)', () => {
  const vr = validate(demoResult.sessions, CONFIG);
  const clashes = vr.errors.filter(e => e.code === 'V04');
  assert(clashes.length === 0, JSON.stringify(clashes));
});

test('T06: No room clashes (V06)', () => {
  const vr = validate(demoResult.sessions, CONFIG);
  const clashes = vr.errors.filter(e => e.code === 'V06');
  assert(clashes.length === 0, JSON.stringify(clashes));
});

test('T07: Faculty availability respected (V07)', () => {
  const vr = validate(demoResult.sessions, CONFIG);
  const errs = vr.errors.filter(e => e.code === 'V07');
  assert(errs.length === 0, JSON.stringify(errs));
});

test('T08: Room availability respected (V08)', () => {
  const vr = validate(demoResult.sessions, CONFIG);
  const errs = vr.errors.filter(e => e.code === 'V08');
  assert(errs.length === 0, JSON.stringify(errs));
});

test('T09: Consecutive practicals (V11/V12)', () => {
  const vr = validate(demoResult.sessions, CONFIG);
  const errs = vr.errors.filter(e => e.code === 'V11' || e.code === 'V12');
  assert(errs.length === 0, JSON.stringify(errs));
});

test('T10: Room type match (V09)', () => {
  const vr = validate(demoResult.sessions, CONFIG);
  const errs = vr.errors.filter(e => e.code === 'V09');
  assert(errs.length === 0, JSON.stringify(errs));
});

test('T11: Faculty load limits (V14/V15)', () => {
  const vr = validate(demoResult.sessions, CONFIG);
  const errs = vr.errors.filter(e => e.code === 'V14' || e.code === 'V15');
  assert(errs.length === 0, JSON.stringify(errs));
});

test('T12: Session count correct (V13)', () => {
  const vr = validate(demoResult.sessions, CONFIG);
  const errs = vr.errors.filter(e => e.code === 'V13');
  assert(errs.length === 0, JSON.stringify(errs));
});

// ── IMPOSSIBLE CONFIG ──────────────────────────────────────
test('T13: No rooms → failed/partial (not complete)', () => {
  const bad = { ...CONFIG, rooms: [], maxBacktracks: 100 };
  const r = schedule(bad);
  assert(r.status !== 'complete', 'Expected partial/failed, got ' + r.status);
  assert(r.unscheduledTasks.length > 0, 'Expected unscheduled tasks');
});

test('T14: All faculty blocked → failed/partial', () => {
  const blockedAll = new Set();
  for (const d of CONFIG.workingDays)
    for (const p of CONFIG.schedulablePeriodIds)
      blockedAll.add(d + ':' + p);
  const bad = { ...CONFIG, faculty: CONFIG.faculty.map(f => ({ ...f, blockedSlots: blockedAll })), maxBacktracks: 100 };
  const r = schedule(bad);
  assert(r.status !== 'complete', 'Expected failure, got ' + r.status);
});

// ── SEARCH LIMIT ───────────────────────────────────────────
test('T15: Search limit flag is boolean', () => {
  const r = schedule({ ...CONFIG, maxBacktracks: 1 });
  assert(typeof r.stats.searchLimitReached === 'boolean', 'not boolean');
  assert(['complete','partial','failed'].includes(r.status), 'invalid status');
});

// ── VALIDATOR INJECTION TESTS ──────────────────────────────
test('T16: Validator detects injected faculty clash (V05)', () => {
  const clash = { ...demoResult.sessions[0], taskId: 'CLASH1' };
  const vr = validate([...demoResult.sessions, clash], CONFIG);
  assert(vr.errors.some(e => e.code === 'V05'), 'Expected V05 error');
});

test('T17: Validator detects session count mismatch (V13)', () => {
  const trimmed = demoResult.sessions.slice(2);
  const vr = validate(trimmed, CONFIG);
  assert(vr.errors.some(e => e.code === 'V13'), 'Expected V13');
});

test('T18: Validator detects non-consecutive practical (V11)', () => {
  const broken = { taskId: 'NC', divisionId: 'DIV-A', subjectId: 'CS201', subjectName: 'DS', sessionType: 'practical', facultyId: 'FAC-001', roomId: 'LAB-CS1', day: 'Monday', periodIds: [1, 3] };
  const vr = validate([broken], CONFIG);
  assert(vr.errors.some(e => e.code === 'V11'), 'Expected V11');
});

test('T19: Validator detects room type mismatch (V09)', () => {
  const bad = { taskId: 'RM', divisionId: 'DIV-A', subjectId: 'CS201', subjectName: 'DS', sessionType: 'practical', facultyId: 'FAC-001', roomId: 'CR-101', day: 'Tuesday', periodIds: [1,2] };
  const vr = validate([bad], CONFIG);
  assert(vr.errors.some(e => e.code === 'V09'), 'Expected V09');
});

// ── MANUAL EDIT ────────────────────────────────────────────
test('T20: Valid manual move accepted', () => {
  const lec = demoResult.sessions.find(s => s.sessionType === 'lecture');
  assert(lec, 'No lecture session');
  let proposal = null;
  for (const day of CONFIG.workingDays) {
    if (day === lec.day) continue;
    proposal = proposeMove(demoResult.sessions, CONFIG, { taskId: lec.taskId, newDay: day, newStartPeriodId: lec.periodIds[0], newRoomId: lec.roomId });
    if (proposal.accepted) break;
  }
  assert(proposal && proposal.accepted, 'No valid move found. Last: ' + (proposal && proposal.reason));
});

test('T21: Faculty clash move rejected', () => {
  const s1 = { taskId: 'E1', divisionId: 'DIV-A', subjectId: 'CS201', subjectName: 'DS', sessionType: 'lecture', facultyId: 'FAC-001', roomId: 'CR-101', day: 'Monday', periodIds: [1] };
  const s2 = { taskId: 'E2', divisionId: 'DIV-A', subjectId: 'CS201', subjectName: 'DS', sessionType: 'lecture', facultyId: 'FAC-001', roomId: 'CR-102', day: 'Wednesday', periodIds: [2] };
  const proposal = proposeMove([s1, s2], CONFIG, { taskId: 'E2', newDay: 'Monday', newStartPeriodId: 1 });
  assert(!proposal.accepted, 'Expected rejection: faculty clash');
  assert(proposal.violations.length > 0, 'Expected violations list');
});

test('T22: Practical move rejected at last period (no room for consecutive)', () => {
  const prac = demoResult.sessions.find(s => s.sessionType === 'practical');
  assert(prac, 'No practical session');
  const proposal = proposeMove(demoResult.sessions, CONFIG, { taskId: prac.taskId, newStartPeriodId: 10, newRoomId: prac.roomId });
  assert(!proposal.accepted, 'Expected rejection: insufficient consecutive periods');
});

test('T23: Apply move – timetable remains valid', () => {
  const lec = demoResult.sessions.find(s => s.sessionType === 'lecture');
  assert(lec, 'No lecture');
  let proposal = null;
  for (const day of CONFIG.workingDays) {
    if (day === lec.day) continue;
    proposal = proposeMove(demoResult.sessions, CONFIG, { taskId: lec.taskId, newDay: day, newStartPeriodId: lec.periodIds[0], newRoomId: lec.roomId });
    if (proposal.accepted) break;
  }
  if (!proposal || !proposal.accepted) { console.log('  (skip: no free slot found – this is a data-dependent test)'); return; }
  const newSessions = applyMove(demoResult.sessions, proposal);
  const vr = validate(newSessions, CONFIG);
  assert(vr.valid, 'Timetable invalid after move: ' + vr.errors.map(e => e.message).join('; '));
});

// ── SUMMARY ────────────────────────────────────────────────
console.log('');
console.log('═════════════════════════════════════');
console.log('RESULTS: ' + pass + ' PASS  ' + fail + ' FAIL  (of ' + (pass+fail) + ')');
console.log('═════════════════════════════════════');
process.exit(fail > 0 ? 1 : 0);
