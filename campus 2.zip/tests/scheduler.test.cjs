/**
 * CampusFlow – Test Suite
 * ========================
 * Uses Node.js built-in `node:test` (available since Node 18).
 * Run with:   node --test tests/scheduler.test.js
 *             node --test tests/scheduler.test.js --reporter=spec   (verbose)
 *
 * COVERED TESTS
 * -------------
 * T01 – Feasible timetable: complete schedule, validator reports valid
 * T02 – Faculty clash prevention
 * T03 – Class/division clash prevention
 * T04 – Room clash prevention
 * T05 – Faculty availability (blocked slots respected)
 * T06 – Room type matching
 * T07 – Room availability (blocked slots respected)
 * T08 – Consecutive practicals: must occupy adjacent schedulable periods
 * T09 – Weekly session count requirements met
 * T10 – Faculty workload limits respected
 * T11 – Impossible configuration: zero rooms → failed/partial result
 * T12 – Search limit reached reporting (not falsely claiming infeasible)
 * T13 – Validator detects faculty clash in hand-crafted invalid timetable
 * T14 – Validator detects division clash
 * T15 – Validator detects session count mismatch (V13)
 * T16 – Validator detects room type mismatch (V09)
 * T17 – Validator detects non-consecutive practical (V11)
 * T18 – Manual edit accepted (valid move)
 * T19 – Manual edit rejected (faculty clash)
 * T20 – Manual edit rejected (room type mismatch)
 * T21 – Practical move handled as a group (consecutive requirement)
 * T22 – Full realistic dataset: status complete and validator valid
 */

'use strict';

const { test, describe, before } = require('node:test');
const assert = require('node:assert/strict');

const { schedule, expandTasks, indexBy } = require('../src/scheduler.cjs');
const { validate }   = require('../src/validator.cjs');
const { proposeMove, applyMove } = require('../src/editor.cjs');
const { CONFIG }     = require('../src/data.cjs');

// ─────────────────────────────────────────────────────────────────────────────
// MINIMAL CONFIG BUILDER
// Helper to create small, isolated configs for targeted tests.
// ─────────────────────────────────────────────────────────────────────────────

function baseConfig(overrides = {}) {
  const periods = [
    { id: 1, label: '08:00–08:55', type: 'lecture' },
    { id: 2, label: '08:55–09:50', type: 'lecture' },
    { id: 3, label: '09:50–10:45', type: 'lecture' },
    { id: 4, label: '10:45–11:00', type: 'break'   },
    { id: 5, label: '11:00–11:55', type: 'lecture' },
    { id: 6, label: '11:55–12:50', type: 'lecture' },
    { id: 7, label: '12:50–13:35', type: 'lunch'   },
    { id: 8, label: '13:35–14:30', type: 'lecture' },
    { id: 9, label: '14:30–15:25', type: 'lecture' },
    { id: 10, label: '15:25–16:20', type: 'lecture' },
  ];
  return {
    workingDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    periods,
    schedulablePeriodIds: periods.filter(p => p.type === 'lecture').map(p => p.id),
    rooms: [
      { id: 'CR1', name: 'Room 1', type: 'classroom', capacity: 70 },
      { id: 'LAB1', name: 'Lab 1', type: 'lab', capacity: 35 },
    ],
    faculty: [
      { id: 'F1', name: 'Prof. Alpha', maxPeriodsPerDay: 4, maxPeriodsPerWeek: 20 },
      { id: 'F2', name: 'Prof. Beta',  maxPeriodsPerDay: 4, maxPeriodsPerWeek: 20 },
    ],
    subjects: [
      { id: 'SUB1', name: 'Math',    lecturesPerWeek: 2, practicalsPerWeek: 0, practicalPeriods: 0, roomType: 'classroom', labRoomType: null },
      { id: 'SUB2', name: 'Physics', lecturesPerWeek: 2, practicalsPerWeek: 1, practicalPeriods: 2, roomType: 'classroom', labRoomType: 'lab' },
    ],
    divisions: [
      { id: 'DA', name: 'Div A', strength: 30 },
    ],
    assignments: [
      { divisionId: 'DA', subjectId: 'SUB1', facultyLectureId: 'F1', facultyPracticalId: null },
      { divisionId: 'DA', subjectId: 'SUB2', facultyLectureId: 'F2', facultyPracticalId: 'F2' },
    ],
    maxBacktracks: 100_000,
    ...overrides,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// T01 – Feasible basic timetable
// ─────────────────────────────────────────────────────────────────────────────
describe('T01 – Feasible timetable', () => {
  test('schedule() returns complete status', () => {
    const result = schedule(baseConfig());
    assert.equal(result.status, 'complete', `Expected complete, got ${result.status}. Unscheduled: ${JSON.stringify(result.unscheduledTasks.map(t => t.id))}`);
  });

  test('validator reports valid on feasible result', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    const report = validate(result.sessions, cfg);
    assert.equal(report.valid, true,
      `Validation errors: ${report.errors.map(e => e.message).join('; ')}`);
  });

  test('validator reports complete on feasible result', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    const report = validate(result.sessions, cfg);
    assert.equal(report.complete, true);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T02 – Faculty clash prevention
// ─────────────────────────────────────────────────────────────────────────────
describe('T02 – Faculty clash prevention', () => {
  test('single faculty teaching two divisions never double-booked', () => {
    const cfg = baseConfig({
      divisions: [
        { id: 'DA', name: 'Div A', strength: 30 },
        { id: 'DB', name: 'Div B', strength: 30 },
      ],
      rooms: [
        { id: 'CR1', name: 'Room 1', type: 'classroom', capacity: 70 },
        { id: 'CR2', name: 'Room 2', type: 'classroom', capacity: 70 },
        { id: 'LAB1', name: 'Lab 1', type: 'lab', capacity: 35 },
        { id: 'LAB2', name: 'Lab 2', type: 'lab', capacity: 35 },
      ],
      assignments: [
        { divisionId: 'DA', subjectId: 'SUB1', facultyLectureId: 'F1', facultyPracticalId: null },
        { divisionId: 'DB', subjectId: 'SUB1', facultyLectureId: 'F1', facultyPracticalId: null },
        { divisionId: 'DA', subjectId: 'SUB2', facultyLectureId: 'F2', facultyPracticalId: 'F2' },
        { divisionId: 'DB', subjectId: 'SUB2', facultyLectureId: 'F2', facultyPracticalId: 'F2' },
      ],
    });
    const result = schedule(cfg);
    // Check via validator
    const report = validate(result.sessions, cfg);
    const facultyClashes = report.errors.filter(e => e.code === 'V05');
    assert.equal(facultyClashes.length, 0, `Faculty clashes: ${JSON.stringify(facultyClashes)}`);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T03 – Class/division clash prevention
// ─────────────────────────────────────────────────────────────────────────────
describe('T03 – Division clash prevention', () => {
  test('a division is never double-booked in same slot', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    const report = validate(result.sessions, cfg);
    const divClashes = report.errors.filter(e => e.code === 'V04');
    assert.equal(divClashes.length, 0, `Division clashes: ${JSON.stringify(divClashes)}`);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T04 – Room clash prevention
// ─────────────────────────────────────────────────────────────────────────────
describe('T04 – Room clash prevention', () => {
  test('no room is used by two sessions at the same time', () => {
    const cfg = baseConfig({
      divisions: [
        { id: 'DA', name: 'Div A', strength: 30 },
        { id: 'DB', name: 'Div B', strength: 30 },
      ],
      rooms: [
        { id: 'CR1', name: 'Room 1', type: 'classroom', capacity: 70 }, // only 1 classroom
        { id: 'LAB1', name: 'Lab 1', type: 'lab', capacity: 70 },
      ],
      assignments: [
        { divisionId: 'DA', subjectId: 'SUB1', facultyLectureId: 'F1', facultyPracticalId: null },
        { divisionId: 'DB', subjectId: 'SUB1', facultyLectureId: 'F2', facultyPracticalId: null },
        { divisionId: 'DA', subjectId: 'SUB2', facultyLectureId: 'F1', facultyPracticalId: 'F1' },
        { divisionId: 'DB', subjectId: 'SUB2', facultyLectureId: 'F2', facultyPracticalId: 'F2' },
      ],
    });
    const result = schedule(cfg);
    const report = validate(result.sessions, cfg);
    const roomClashes = report.errors.filter(e => e.code === 'V06');
    assert.equal(roomClashes.length, 0, `Room clashes: ${JSON.stringify(roomClashes)}`);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T05 – Faculty availability constraints
// ─────────────────────────────────────────────────────────────────────────────
describe('T05 – Faculty availability', () => {
  test('sessions never placed in faculty blocked slots', () => {
    const cfg = baseConfig({
      faculty: [
        {
          id: 'F1', name: 'Prof. Alpha', maxPeriodsPerDay: 4, maxPeriodsPerWeek: 20,
          // Block Monday entirely
          blockedSlots: new Set(['Monday:1','Monday:2','Monday:3','Monday:5','Monday:6','Monday:8','Monday:9','Monday:10']),
        },
        { id: 'F2', name: 'Prof. Beta', maxPeriodsPerDay: 4, maxPeriodsPerWeek: 20 },
      ],
    });
    const result = schedule(cfg);
    const report = validate(result.sessions, cfg);
    const availErrs = report.errors.filter(e => e.code === 'V07');
    assert.equal(availErrs.length, 0, `Faculty availability violations: ${JSON.stringify(availErrs)}`);
    // F1 sessions must not be on Monday
    const f1Sessions = result.sessions.filter(s => s.facultyId === 'F1');
    for (const s of f1Sessions) {
      assert.notEqual(s.day, 'Monday', `F1 session scheduled on blocked Monday`);
    }
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T06 – Room type matching
// ─────────────────────────────────────────────────────────────────────────────
describe('T06 – Room type matching', () => {
  test('practicals go to labs, lectures go to classrooms', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    for (const s of result.sessions) {
      const room = cfg.rooms.find(r => r.id === s.roomId);
      if (s.sessionType === 'practical') {
        assert.equal(room.type, 'lab', `Practical ${s.taskId} placed in non-lab room ${room.id}`);
      } else {
        assert.equal(room.type, 'classroom', `Lecture ${s.taskId} placed in non-classroom room ${room.id}`);
      }
    }
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T07 – Room availability
// ─────────────────────────────────────────────────────────────────────────────
describe('T07 – Room availability', () => {
  test('sessions never placed in room blocked slots', () => {
    const cfg = baseConfig({
      rooms: [
        {
          id: 'CR1', name: 'Room 1', type: 'classroom', capacity: 70,
          blockedSlots: new Set(['Monday:1','Monday:2','Monday:3']), // block Monday morning
        },
        { id: 'CR2', name: 'Room 2', type: 'classroom', capacity: 70 },
        { id: 'LAB1', name: 'Lab 1', type: 'lab', capacity: 35 },
      ],
    });
    const result = schedule(cfg);
    const report = validate(result.sessions, cfg);
    const roomAvailErrs = report.errors.filter(e => e.code === 'V08');
    assert.equal(roomAvailErrs.length, 0, `Room availability violations: ${JSON.stringify(roomAvailErrs)}`);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T08 – Consecutive practicals
// ─────────────────────────────────────────────────────────────────────────────
describe('T08 – Consecutive practicals', () => {
  test('practical periods are consecutive and schedulable', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    for (const s of result.sessions) {
      if (s.sessionType !== 'practical') continue;
      // Periods must be consecutive integers
      for (let i = 1; i < s.periodIds.length; i++) {
        assert.equal(s.periodIds[i], s.periodIds[i - 1] + 1,
          `Practical ${s.taskId} has non-consecutive periods: ${s.periodIds}`);
      }
      // No period in the run can be a break/lunch
      for (const pid of s.periodIds) {
        const period = cfg.periods.find(p => p.id === pid);
        assert.equal(period.type, 'lecture',
          `Practical ${s.taskId} includes non-lecture period ${pid} (${period.type})`);
      }
    }
  });

  test('validator catches non-consecutive practical periods', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    // Hand-craft a broken practical session
    const broken = {
      taskId: 'BROKEN',
      divisionId: 'DA',
      subjectId: 'SUB2',
      subjectName: 'Physics',
      sessionType: 'practical',
      facultyId: 'F2',
      roomId: 'LAB1',
      day: 'Tuesday',
      periodIds: [1, 3], // NOT consecutive (2 is missing)
    };
    const report = validate([...result.sessions, broken], cfg);
    const ncErrors = report.errors.filter(e => e.code === 'V11');
    assert.ok(ncErrors.length > 0, 'Expected V11 error for non-consecutive practical');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T09 – Weekly session count
// ─────────────────────────────────────────────────────────────────────────────
describe('T09 – Weekly session counts', () => {
  test('all required sessions are scheduled in feasible config', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    const required = expandTasks(cfg);
    assert.equal(result.sessions.length, required.length,
      `Scheduled ${result.sessions.length} of ${required.length} required sessions`);
  });

  test('validator detects session count mismatch (V13)', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    // Remove one session to create a mismatch
    const trimmed = result.sessions.slice(1);
    const report = validate(trimmed, cfg);
    const v13 = report.errors.filter(e => e.code === 'V13');
    assert.ok(v13.length > 0, 'Expected V13 error for missing session');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T10 – Faculty workload limits
// ─────────────────────────────────────────────────────────────────────────────
describe('T10 – Faculty workload limits', () => {
  test('daily and weekly load limits not exceeded', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    const report = validate(result.sessions, cfg);
    const loadErrs = report.errors.filter(e => e.code === 'V14' || e.code === 'V15');
    assert.equal(loadErrs.length, 0, `Load violations: ${JSON.stringify(loadErrs)}`);
  });

  test('very tight load limit forces partial/failed schedule', () => {
    // maxPeriodsPerWeek=1 for both faculty but we need 5+ sessions
    const cfg = baseConfig({
      faculty: [
        { id: 'F1', name: 'Prof. Alpha', maxPeriodsPerDay: 1, maxPeriodsPerWeek: 1 },
        { id: 'F2', name: 'Prof. Beta',  maxPeriodsPerDay: 1, maxPeriodsPerWeek: 1 },
      ],
    });
    const result = schedule(cfg);
    assert.ok(['partial', 'failed'].includes(result.status),
      `Expected partial/failed with tight load, got ${result.status}`);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T11 – Impossible configuration
// ─────────────────────────────────────────────────────────────────────────────
describe('T11 – Impossible configuration', () => {
  test('no rooms → failed or partial status', () => {
    const cfg = baseConfig({ rooms: [] });
    const result = schedule(cfg);
    assert.ok(['failed', 'partial'].includes(result.status),
      `Expected failed/partial, got ${result.status}`);
    assert.ok(result.unscheduledTasks.length > 0);
  });

  test('no faculty available on any working day → failed or partial', () => {
    // Block all periods on all days for both faculty
    const blockedAll = new Set();
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const pids = [1, 2, 3, 5, 6, 8, 9, 10];
    for (const d of days) for (const p of pids) blockedAll.add(`${d}:${p}`);

    const cfg = baseConfig({
      faculty: [
        { id: 'F1', name: 'Prof. Alpha', maxPeriodsPerDay: 4, maxPeriodsPerWeek: 20, blockedSlots: blockedAll },
        { id: 'F2', name: 'Prof. Beta',  maxPeriodsPerDay: 4, maxPeriodsPerWeek: 20, blockedSlots: blockedAll },
      ],
    });
    const result = schedule(cfg);
    assert.ok(['failed', 'partial'].includes(result.status),
      `Expected failed/partial when faculty blocked everywhere`);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T12 – Search limit reporting
// ─────────────────────────────────────────────────────────────────────────────
describe('T12 – Search limit reporting', () => {
  test('sets searchLimitReached=true when maxBacktracks is 0', () => {
    // With maxBacktracks=0, the backtracker gives up immediately on first failure
    const cfg = baseConfig({
      maxBacktracks: 0,
      // Ensure contention so backtracking actually happens
      rooms: [
        { id: 'CR1', name: 'Room 1', type: 'classroom', capacity: 70 },
        { id: 'LAB1', name: 'Lab 1', type: 'lab', capacity: 35 },
      ],
      assignments: [
        { divisionId: 'DA', subjectId: 'SUB1', facultyLectureId: 'F1', facultyPracticalId: null },
        { divisionId: 'DA', subjectId: 'SUB2', facultyLectureId: 'F2', facultyPracticalId: 'F2' },
      ],
    });
    const result = schedule(cfg);
    // If all tasks happen to be placed first-try, searchLimitReached can be false.
    // We just verify the field exists and is boolean.
    assert.equal(typeof result.stats.searchLimitReached, 'boolean');
    // Regardless, status should never be 'complete' with 0 backtracks limit if any contention
    // (may or may not be complete depending on first-fit luck — acceptable)
    assert.ok(['complete','partial','failed'].includes(result.status));
  });

  test('backtrack count is reported accurately', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    assert.equal(typeof result.stats.backtracks, 'number');
    assert.ok(result.stats.backtracks >= 0);
  });

  test('searchLimitReached does not claim configuration is impossible', () => {
    // The result object must only set status=failed if truly nothing was scheduled
    // and must distinguish from 'partial' when some sessions were placed
    const cfg = baseConfig({ maxBacktracks: 1 });
    const result = schedule(cfg);
    if (result.stats.searchLimitReached) {
      // status must reflect actual sessions placed, not just "impossible"
      if (result.sessions.length > 0) {
        assert.equal(result.status, 'partial');
      } else {
        assert.ok(['failed', 'partial'].includes(result.status));
      }
    }
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T13 – Validator detects faculty clash in hand-crafted invalid timetable
// ─────────────────────────────────────────────────────────────────────────────
describe('T13 – Validator: faculty clash detection', () => {
  test('detects V05 for overlapping faculty sessions', () => {
    const cfg = baseConfig();
    // Two sessions same faculty, same day, same period
    const sessions = [
      {
        taskId: 'A1', divisionId: 'DA', subjectId: 'SUB1', subjectName: 'Math',
        sessionType: 'lecture', facultyId: 'F1', roomId: 'CR1',
        day: 'Monday', periodIds: [1],
      },
      {
        taskId: 'A2', divisionId: 'DA', subjectId: 'SUB1', subjectName: 'Math',
        sessionType: 'lecture', facultyId: 'F1', roomId: 'CR1',
        day: 'Monday', periodIds: [1], // same slot → clash
      },
    ];
    const report = validate(sessions, cfg);
    assert.ok(report.errors.some(e => e.code === 'V05'),
      'Expected V05 (faculty clash)');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T14 – Validator detects division clash
// ─────────────────────────────────────────────────────────────────────────────
describe('T14 – Validator: division clash detection', () => {
  test('detects V04 for overlapping division sessions', () => {
    const cfg = baseConfig();
    const sessions = [
      {
        taskId: 'B1', divisionId: 'DA', subjectId: 'SUB1', subjectName: 'Math',
        sessionType: 'lecture', facultyId: 'F1', roomId: 'CR1',
        day: 'Tuesday', periodIds: [2],
      },
      {
        taskId: 'B2', divisionId: 'DA', subjectId: 'SUB2', subjectName: 'Physics',
        sessionType: 'lecture', facultyId: 'F2', roomId: 'CR1',
        day: 'Tuesday', periodIds: [2], // same division + period → clash
      },
    ];
    const report = validate(sessions, cfg);
    assert.ok(report.errors.some(e => e.code === 'V04'),
      'Expected V04 (division clash)');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T15 – Validator detects session count mismatch
// ─────────────────────────────────────────────────────────────────────────────
describe('T15 – Validator: session count mismatch (V13)', () => {
  test('detects fewer sessions than required', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    // Remove two sessions
    const trimmed = result.sessions.slice(2);
    const report = validate(trimmed, cfg);
    assert.ok(report.errors.some(e => e.code === 'V13'),
      'Expected V13 for missing sessions');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T16 – Validator detects room type mismatch
// ─────────────────────────────────────────────────────────────────────────────
describe('T16 – Validator: room type mismatch (V09)', () => {
  test('detects practical placed in classroom', () => {
    const cfg = baseConfig();
    const sessions = [
      {
        taskId: 'C1', divisionId: 'DA', subjectId: 'SUB2', subjectName: 'Physics',
        sessionType: 'practical', facultyId: 'F2',
        roomId: 'CR1', // classroom, not lab → V09
        day: 'Wednesday', periodIds: [1, 2],
      },
    ];
    const report = validate(sessions, cfg);
    assert.ok(report.errors.some(e => e.code === 'V09'),
      `Expected V09 for practical in classroom. Errors: ${report.errors.map(e=>e.code).join(',')}`);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T17 – Validator detects non-consecutive practical periods
// ─────────────────────────────────────────────────────────────────────────────
describe('T17 – Validator: non-consecutive practical (V11)', () => {
  test('detects periods 1 and 3 as non-consecutive', () => {
    const cfg = baseConfig();
    const sessions = [
      {
        taskId: 'D1', divisionId: 'DA', subjectId: 'SUB2', subjectName: 'Physics',
        sessionType: 'practical', facultyId: 'F2',
        roomId: 'LAB1',
        day: 'Thursday', periodIds: [1, 3], // gap at 2 → V11
      },
    ];
    const report = validate(sessions, cfg);
    assert.ok(report.errors.some(e => e.code === 'V11'),
      'Expected V11 for non-consecutive practical');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T18 – Manual edit: valid move accepted
// ─────────────────────────────────────────────────────────────────────────────
describe('T18 – Manual edit: valid move', () => {
  test('proposeMove accepts a conflict-free relocation', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    assert.equal(result.status, 'complete');

    // Pick a lecture session
    const lecture = result.sessions.find(s => s.sessionType === 'lecture');
    assert.ok(lecture, 'Need at least one lecture session');

    // Find a free day/period combination for F1 that doesn't conflict
    // Strategy: try a different day, same start period
    const otherDays = cfg.workingDays.filter(d => d !== lecture.day);
    let proposal = null;
    for (const day of otherDays) {
      proposal = proposeMove(result.sessions, cfg, {
        taskId: lecture.taskId,
        newDay: day,
        newStartPeriodId: lecture.periodIds[0],
        newRoomId: lecture.roomId,
      });
      if (proposal.accepted) break;
    }

    // At least one free day should exist given the sparse test config
    assert.ok(proposal && proposal.accepted,
      `No valid move found. Last reason: ${proposal?.reason}`);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T19 – Manual edit: rejected due to faculty clash
// ─────────────────────────────────────────────────────────────────────────────
describe('T19 – Manual edit: rejected for faculty clash', () => {
  test('moving session into a slot where faculty is busy is rejected', () => {
    const cfg = baseConfig();
    // Hand-place two sessions for F1 on Monday p1 and Wednesday p1
    const sessions = [
      {
        taskId: 'E1', divisionId: 'DA', subjectId: 'SUB1', subjectName: 'Math',
        sessionType: 'lecture', facultyId: 'F1', roomId: 'CR1',
        day: 'Monday', periodIds: [1],
      },
      {
        taskId: 'E2', divisionId: 'DA', subjectId: 'SUB1', subjectName: 'Math',
        sessionType: 'lecture', facultyId: 'F1', roomId: 'CR1',
        day: 'Wednesday', periodIds: [2],
      },
    ];

    // Try to move E2 to Monday period 1 → F1 is already teaching E1 there
    const proposal = proposeMove(sessions, cfg, {
      taskId: 'E2',
      newDay: 'Monday',
      newStartPeriodId: 1,
    });

    assert.equal(proposal.accepted, false, 'Expected rejection due to faculty clash');
    assert.ok(proposal.violations.length > 0);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T20 – Manual edit: rejected for room type mismatch
// ─────────────────────────────────────────────────────────────────────────────
describe('T20 – Manual edit: rejected for room type mismatch', () => {
  test('moving a practical to a classroom is rejected', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    const practical = result.sessions.find(s => s.sessionType === 'practical');
    assert.ok(practical, 'Need a practical session');

    const proposal = proposeMove(result.sessions, cfg, {
      taskId: practical.taskId,
      newRoomId: 'CR1', // classroom, not lab
    });

    assert.equal(proposal.accepted, false,
      `Expected rejection for room type mismatch, got: ${proposal.reason}`);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T21 – Practical move handled as a group (consecutive requirement)
// ─────────────────────────────────────────────────────────────────────────────
describe('T21 – Manual edit: practical consecutive group move', () => {
  test('moving practical to start at a period with insufficient runway is rejected', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    const practical = result.sessions.find(s => s.sessionType === 'practical');
    assert.ok(practical, 'Need a practical session');

    // period 10 is the last schedulable period; a 2-period block cannot start here
    const proposal = proposeMove(result.sessions, cfg, {
      taskId: practical.taskId,
      newStartPeriodId: 10, // only 1 period left at end of day → can't fit 2 consecutive
      newRoomId: practical.roomId,
    });

    assert.equal(proposal.accepted, false,
      `Expected rejection for insufficient consecutive periods`);
  });

  test('moving practical to a valid consecutive slot is accepted', () => {
    const cfg = baseConfig();
    const result = schedule(cfg);
    const practical = result.sessions.find(s => s.sessionType === 'practical');
    assert.ok(practical, 'Need a practical session');

    // Try different days/start periods until we find a free slot
    let proposal = null;
    for (const day of cfg.workingDays) {
      for (const startPid of [1, 2, 5, 8]) {
        proposal = proposeMove(result.sessions, cfg, {
          taskId: practical.taskId,
          newDay: day,
          newStartPeriodId: startPid,
          newRoomId: practical.roomId,
        });
        if (proposal.accepted) break;
      }
      if (proposal?.accepted) break;
    }
    assert.ok(proposal?.accepted,
      `No free consecutive slot found. Last: ${proposal?.reason}`);

    // Apply and verify the resulting sessions list still passes validation
    const newSessions = applyMove(result.sessions, proposal);
    const report = validate(newSessions, cfg);
    assert.equal(report.valid, true,
      `Post-edit validation errors: ${report.errors.map(e=>e.message).join('; ')}`);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// T22 – Full realistic dataset
// ─────────────────────────────────────────────────────────────────────────────
describe('T22 – Full realistic dataset (CampusFlow CONFIG)', () => {
  let result;
  let report;

  before(() => {
    result = schedule(CONFIG);
    report = validate(result.sessions, CONFIG);
  });

  test('status is complete', () => {
    assert.equal(result.status, 'complete',
      `Status: ${result.status}. Unscheduled (${result.unscheduledTasks.length}): ` +
      result.unscheduledTasks.map(t => `${t.id}:${t.divisionId}/${t.subjectId}/${t.sessionType}`).join(', ') +
      `\nDiagnostics: ${result.diagnosticMessages.join('; ')}`
    );
  });

  test('validator reports valid', () => {
    assert.equal(report.valid, true,
      `Validation errors (${report.errors.length}): ` +
      report.errors.map(e => `[${e.code}] ${e.message}`).join('\n'));
  });

  test('validator reports complete', () => {
    assert.equal(report.complete, true);
  });

  test('no faculty clashes', () => {
    const clashes = report.errors.filter(e => e.code === 'V05');
    assert.equal(clashes.length, 0, JSON.stringify(clashes));
  });

  test('no division clashes', () => {
    const clashes = report.errors.filter(e => e.code === 'V04');
    assert.equal(clashes.length, 0, JSON.stringify(clashes));
  });

  test('no room clashes', () => {
    const clashes = report.errors.filter(e => e.code === 'V06');
    assert.equal(clashes.length, 0, JSON.stringify(clashes));
  });

  test('no faculty availability violations', () => {
    const violations = report.errors.filter(e => e.code === 'V07');
    assert.equal(violations.length, 0, JSON.stringify(violations));
  });

  test('all practicals are consecutive', () => {
    const violations = report.errors.filter(e => e.code === 'V11' || e.code === 'V12');
    assert.equal(violations.length, 0, JSON.stringify(violations));
  });

  test('no room type mismatches', () => {
    const violations = report.errors.filter(e => e.code === 'V09');
    assert.equal(violations.length, 0, JSON.stringify(violations));
  });

  test('no load limit violations', () => {
    const violations = report.errors.filter(e => e.code === 'V14' || e.code === 'V15');
    assert.equal(violations.length, 0, JSON.stringify(violations));
  });

  test('reports backtrack statistics', () => {
    assert.ok(result.stats.backtracks >= 0);
    assert.equal(typeof result.stats.searchLimitReached, 'boolean');
    assert.ok(result.stats.totalTasks > 0);
  });
});
