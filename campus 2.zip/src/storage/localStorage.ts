import { CollegeConfig, PlacedSession, ScheduleResult } from '../types';
import { DEMO_CONFIG } from '../engine/demoData';

const CONFIG_KEY = 'campusflow_college_config_v1';
const SESSIONS_KEY = 'campusflow_placed_sessions_v1';
const RESULT_KEY = 'campusflow_schedule_result_v1';

export function loadStoredConfig(): CollegeConfig {
  try {
    const raw = localStorage.getItem(CONFIG_KEY);
    if (!raw) return DEMO_CONFIG;
    const parsed = JSON.parse(raw);
    if (parsed && parsed.collegeName && Array.isArray(parsed.periods)) {
      return parsed;
    }
    return DEMO_CONFIG;
  } catch (e) {
    console.error('Failed to load config from localStorage, defaulting to DEMO_CONFIG', e);
    return DEMO_CONFIG;
  }
}

export function saveStoredConfig(config: CollegeConfig): void {
  try {
    localStorage.setItem(CONFIG_KEY, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save config to localStorage', e);
  }
}

export function loadStoredSessions(): PlacedSession[] | null {
  try {
    const raw = localStorage.getItem(SESSIONS_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load sessions from localStorage', e);
    return null;
  }
}

export function saveStoredSessions(sessions: PlacedSession[]): void {
  try {
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
  } catch (e) {
    console.error('Failed to save sessions to localStorage', e);
  }
}

export function loadStoredResult(): ScheduleResult | null {
  try {
    const raw = localStorage.getItem(RESULT_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load schedule result from localStorage', e);
    return null;
  }
}

export function saveStoredResult(result: ScheduleResult): void {
  try {
    localStorage.setItem(RESULT_KEY, JSON.stringify(result));
  } catch (e) {
    console.error('Failed to save schedule result to localStorage', e);
  }
}

export function clearStoredData(): void {
  try {
    localStorage.removeItem(CONFIG_KEY);
    localStorage.removeItem(SESSIONS_KEY);
    localStorage.removeItem(RESULT_KEY);
  } catch (e) {
    console.error('Failed to clear stored data', e);
  }
}
