/**
 * CampusFlow – Sample Input Data
 * --------------------------------
 * Defines the schema and a realistic dataset for a 2nd-year Computer Science
 * department with 2 divisions (A & B), 6 subjects, shared faculty, and two labs.
 *
 * All IDs are plain strings.  Availability is expressed as a Set-like whitelist
 * of "day:period" strings.  An absent `availability` key means "always available".
 */

'use strict';

// ─────────────────────────────────────────────
// 1. WORKING DAYS
// ─────────────────────────────────────────────
const WORKING_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

// ─────────────────────────────────────────────
// 2. PERIOD DEFINITIONS
//    type: 'lecture' | 'break' | 'lunch'
//    Periods that are break/lunch are never scheduled.
// ─────────────────────────────────────────────
const PERIODS = [
  { id: 1, label: '08:00–08:55', type: 'lecture' },
  { id: 2, label: '08:55–09:50', type: 'lecture' },
  { id: 3, label: '09:50–10:45', type: 'lecture' },
  { id: 4, label: '10:45–11:00', type: 'break'   },  // short break
  { id: 5, label: '11:00–11:55', type: 'lecture' },
  { id: 6, label: '11:55–12:50', type: 'lecture' },
  { id: 7, label: '12:50–13:35', type: 'lunch'   },  // lunch
  { id: 8, label: '13:35–14:30', type: 'lecture' },
  { id: 9, label: '14:30–15:25', type: 'lecture' },
  { id: 10, label: '15:25–16:20', type: 'lecture' },
];

/** Convenience: IDs of periods available for scheduling */
const SCHEDULABLE_PERIOD_IDS = PERIODS
  .filter(p => p.type === 'lecture')
  .map(p => p.id);

// ─────────────────────────────────────────────
// 3. ROOMS
//    type: 'classroom' | 'lab'
//    capacity: max students
//    availability (optional): array of "Day:periodId" strings that are BLOCKED
//      (i.e. "not available").  Absent means fully available.
// ─────────────────────────────────────────────
const ROOMS = [
  {
    id: 'CR-101',
    name: 'Classroom 101',
    type: 'classroom',
    capacity: 70,
  },
  {
    id: 'CR-102',
    name: 'Classroom 102',
    type: 'classroom',
    capacity: 70,
  },
  {
    id: 'CR-103',
    name: 'Classroom 103',
    type: 'classroom',
    capacity: 70,
    // CR-103 unavailable Friday afternoons (used by administration)
    blockedSlots: new Set(['Friday:8', 'Friday:9', 'Friday:10']),
  },
  {
    id: 'LAB-CS1',
    name: 'CS Lab 1',
    type: 'lab',
    capacity: 35,
  },
  {
    id: 'LAB-CS2',
    name: 'CS Lab 2',
    type: 'lab',
    capacity: 35,
    // LAB-CS2 unavailable Monday morning (maintenance)
    blockedSlots: new Set(['Monday:1', 'Monday:2', 'Monday:3']),
  },
];

// ─────────────────────────────────────────────
// 4. FACULTY
//    availability (optional blocked slots): Set of "Day:periodId"
//    maxPeriodsPerDay: hard upper bound on teaching periods per day
//    maxPeriodsPerWeek: hard upper bound on teaching periods per week
// ─────────────────────────────────────────────
const FACULTY = [
  {
    id: 'FAC-001',
    name: 'Dr. Alice Mathews',
    maxPeriodsPerDay: 4,
    maxPeriodsPerWeek: 16,
  },
  {
    id: 'FAC-002',
    name: 'Prof. Bob Sharma',
    maxPeriodsPerDay: 3,
    maxPeriodsPerWeek: 12,
    // Not available Wednesday (research day)
    blockedSlots: new Set([
      'Wednesday:1','Wednesday:2','Wednesday:3',
      'Wednesday:5','Wednesday:6','Wednesday:8','Wednesday:9','Wednesday:10',
    ]),
  },
  {
    id: 'FAC-003',
    name: 'Dr. Carol Nair',
    maxPeriodsPerDay: 4,
    maxPeriodsPerWeek: 16,
  },
  {
    id: 'FAC-004',
    name: 'Prof. David Lee',
    maxPeriodsPerDay: 4,
    maxPeriodsPerWeek: 14,
    // Unavailable Friday period 1
    blockedSlots: new Set(['Friday:1']),
  },
  {
    id: 'FAC-005',
    name: 'Dr. Eva Patel',
    maxPeriodsPerDay: 3,
    maxPeriodsPerWeek: 12,
  },
];

// ─────────────────────────────────────────────
// 5. SUBJECTS
//    lecturesPerWeek : number of single-period lecture sessions needed
//    practicalsPerWeek: number of practical BLOCKS needed
//    practicalPeriods  : how many consecutive periods each practical block occupies
//    roomType         : required room type for lectures ('classroom') and practicals ('lab')
// ─────────────────────────────────────────────
const SUBJECTS = [
  {
    id: 'CS201',
    name: 'Data Structures',
    lecturesPerWeek: 3,
    practicalsPerWeek: 1,
    practicalPeriods: 2,   // 2 consecutive periods per practical block
    roomType: 'classroom',
    labRoomType: 'lab',
  },
  {
    id: 'CS202',
    name: 'Operating Systems',
    lecturesPerWeek: 3,
    practicalsPerWeek: 1,
    practicalPeriods: 2,
    roomType: 'classroom',
    labRoomType: 'lab',
  },
  {
    id: 'CS203',
    name: 'Computer Networks',
    lecturesPerWeek: 3,
    practicalsPerWeek: 1,
    practicalPeriods: 2,
    roomType: 'classroom',
    labRoomType: 'lab',
  },
  {
    id: 'CS204',
    name: 'Database Management',
    lecturesPerWeek: 3,
    practicalsPerWeek: 1,
    practicalPeriods: 2,
    roomType: 'classroom',
    labRoomType: 'lab',
  },
  {
    id: 'CS205',
    name: 'Mathematics – III',
    lecturesPerWeek: 4,
    practicalsPerWeek: 0,
    practicalPeriods: 0,
    roomType: 'classroom',
    labRoomType: null,
  },
  {
    id: 'CS206',
    name: 'Software Engineering',
    lecturesPerWeek: 2,
    practicalsPerWeek: 0,
    practicalPeriods: 0,
    roomType: 'classroom',
    labRoomType: null,
  },
];

// ─────────────────────────────────────────────
// 6. DIVISIONS (classes)
//    Each division has its own timetable.
//    strength: student count (for room capacity checks)
// ─────────────────────────────────────────────
const DIVISIONS = [
  {
    id: 'DIV-A', name: 'CS-A', strength: 60,
    /** Number of students per lab rotation (practical batch).
     *  Defaults to Math.ceil(strength/2) when absent. */
    practicalBatchSize: 30,
  },
  {
    id: 'DIV-B', name: 'CS-B', strength: 58,
    practicalBatchSize: 29,
  },
];

// ─────────────────────────────────────────────
// 7. ASSIGNMENTS
//    Maps (division, subject) → faculty.
//    For practicals, facultyPractical can differ from facultyLecture.
//    preferredDays / preferredPeriods: soft hints (no hard enforcement).
// ─────────────────────────────────────────────
const ASSIGNMENTS = [
  // ── Division A ──────────────────────────────
  {
    divisionId: 'DIV-A', subjectId: 'CS201',
    facultyLectureId: 'FAC-001', facultyPracticalId: 'FAC-001',
    preferredDays: ['Monday', 'Wednesday', 'Friday'],
  },
  {
    divisionId: 'DIV-A', subjectId: 'CS202',
    facultyLectureId: 'FAC-002', facultyPracticalId: 'FAC-002',
  },
  {
    divisionId: 'DIV-A', subjectId: 'CS203',
    facultyLectureId: 'FAC-003', facultyPracticalId: 'FAC-003',
  },
  {
    divisionId: 'DIV-A', subjectId: 'CS204',
    facultyLectureId: 'FAC-004', facultyPracticalId: 'FAC-004',
  },
  {
    divisionId: 'DIV-A', subjectId: 'CS205',
    facultyLectureId: 'FAC-005', facultyPracticalId: null,
  },
  {
    divisionId: 'DIV-A', subjectId: 'CS206',
    facultyLectureId: 'FAC-001', facultyPracticalId: null,
  },

  // ── Division B ──────────────────────────────
  {
    divisionId: 'DIV-B', subjectId: 'CS201',
    facultyLectureId: 'FAC-001', facultyPracticalId: 'FAC-001',
  },
  {
    divisionId: 'DIV-B', subjectId: 'CS202',
    facultyLectureId: 'FAC-002', facultyPracticalId: 'FAC-002',
  },
  {
    divisionId: 'DIV-B', subjectId: 'CS203',
    facultyLectureId: 'FAC-003', facultyPracticalId: 'FAC-003',
  },
  {
    divisionId: 'DIV-B', subjectId: 'CS204',
    facultyLectureId: 'FAC-004', facultyPracticalId: 'FAC-004',
    preferredDays: ['Tuesday', 'Thursday'],
  },
  {
    divisionId: 'DIV-B', subjectId: 'CS205',
    facultyLectureId: 'FAC-005', facultyPracticalId: null,
  },
  {
    divisionId: 'DIV-B', subjectId: 'CS206',
    facultyLectureId: 'FAC-001', facultyPracticalId: null,
  },
];

// ─────────────────────────────────────────────
// 8. GLOBAL SCHEDULING CONFIGURATION
// ─────────────────────────────────────────────
const CONFIG = {
  workingDays: WORKING_DAYS,
  periods: PERIODS,
  schedulablePeriodIds: SCHEDULABLE_PERIOD_IDS,
  rooms: ROOMS,
  faculty: FACULTY,
  subjects: SUBJECTS,
  divisions: DIVISIONS,
  assignments: ASSIGNMENTS,
  /** Maximum backtracks before giving up (prevents infinite loops) */
  maxBacktracks: 500_000,
};

module.exports = {
  CONFIG,
  WORKING_DAYS,
  PERIODS,
  SCHEDULABLE_PERIOD_IDS,
  ROOMS,
  FACULTY,
  SUBJECTS,
  DIVISIONS,
  ASSIGNMENTS,
};
