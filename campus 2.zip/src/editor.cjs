/**
 * CampusFlow – Manual Session Editor
 * ====================================
 * Proposes and validates moves/changes to placed sessions.
 *
 * WORKFLOW
 * --------
 * 1. Call `proposeMove(sessions, config, moveSpec)` with a description of
 *    what you want to change.
 * 2. The function rebuilds occupancy state from the existing sessions,
 *    temporarily removes the target session, then checks all hard constraints
 *    for the proposed new placement.
 * 3. Returns an EditProposal indicating whether the move is valid or rejected.
 * 4. Call `applyMove(sessions, proposal)` to get a NEW sessions array with the
 *    change applied (immutable – the original is never mutated).
 *
 * PRACTICAL GROUP HANDLING
 * ------------------------
 * If the session to move is a practical with periodsRequired > 1, ALL periods
 * in the block are treated as a unit.  The move spec must supply a new
 * startPeriodId; the editor computes the full consecutive period list
 * automatically.
 *
 * EDIT SPEC SCHEMA
 * ----------------
 * {
 *   taskId:        string   – ID of the session (PlacedSession.taskId) to move
 *   newDay?:       string   – target day (omit to keep same day)
 *   newStartPeriodId?: number – new start period (omit to keep same start)
 *   newRoomId?:    string   – new room (omit to keep same room)
 * }
 */

'use strict';

const {
  indexBy, slotKey,
  createState, placeSession, getConsecutivePeriods, checkConstraints,
} = require('./scheduler.cjs');

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Rebuild a full ScheduleState from a sessions array.
 * @param {import('./scheduler').PlacedSession[]} sessions
 * @param {object} config
 * @returns {import('./scheduler').ScheduleState}
 */
function rebuildState(sessions, config) {
  const state = createState(config);
  for (const s of sessions) placeSession(state, s);
  return state;
}

// ─────────────────────────────────────────────────────────────────────────────
// PUBLIC API: proposeMove()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @typedef {object} MoveSpec
 * @property {string}  taskId
 * @property {string}  [newDay]
 * @property {number}  [newStartPeriodId]
 * @property {string}  [newRoomId]
 *
 * @typedef {object} EditProposal
 * @property {boolean} accepted
 * @property {string}  reason         – human-readable result
 * @property {import('./scheduler').PlacedSession|null} originalSession
 * @property {import('./scheduler').PlacedSession|null} proposedSession
 * @property {string[]} violations    – constraint violation messages (if rejected)
 */

/**
 * Propose moving / modifying a session.
 *
 * @param {import('./scheduler').PlacedSession[]} sessions
 * @param {object} config
 * @param {MoveSpec} moveSpec
 * @returns {EditProposal}
 */
function proposeMove(sessions, config, moveSpec) {
  const roomMap    = indexBy(config.rooms,    r => r.id);
  const facultyMap = indexBy(config.faculty,  f => f.id);
  const divisionMap= indexBy(config.divisions,d => d.id);
  const periodMap  = indexBy(config.periods,  p => p.id);
  const subjectMap = indexBy(config.subjects, s => s.id);

  // ── Find the target session ──────────────────────────────────
  const original = sessions.find(s => s.taskId === moveSpec.taskId);
  if (!original) {
    return {
      accepted: false,
      reason: `Session '${moveSpec.taskId}' not found in timetable.`,
      originalSession: null,
      proposedSession: null,
      violations: [],
    };
  }

  // ── Resolve proposed values (fall back to current) ───────────
  const newDay          = moveSpec.newDay          ?? original.day;
  const newStartPeriod  = moveSpec.newStartPeriodId ?? original.periodIds[0];
  const newRoomId       = moveSpec.newRoomId        ?? original.roomId;
  const room            = roomMap.get(newRoomId);

  if (!room) {
    return {
      accepted: false,
      reason: `Unknown room '${newRoomId}'.`,
      originalSession: original,
      proposedSession: null,
      violations: [`Room '${newRoomId}' does not exist in config.`],
    };
  }

  // ── Compute new period list ──────────────────────────────────
  const periodsRequired = original.periodIds.length;
  let newPeriodIds;

  if (periodsRequired === 1) {
    const period = periodMap.get(newStartPeriod);
    if (!period || period.type !== 'lecture') {
      return {
        accepted: false,
        reason: `Period ${newStartPeriod} is not a schedulable lecture period.`,
        originalSession: original,
        proposedSession: null,
        violations: [`Period ${newStartPeriod} is a ${period?.type ?? 'unknown'} slot.`],
      };
    }
    newPeriodIds = [newStartPeriod];
  } else {
    newPeriodIds = getConsecutivePeriods(
      newStartPeriod, periodsRequired, config.schedulablePeriodIds, periodMap
    );
    if (!newPeriodIds) {
      return {
        accepted: false,
        reason: `Cannot fit ${periodsRequired} consecutive lecture periods starting at period ${newStartPeriod} on ${newDay}.`,
        originalSession: original,
        proposedSession: null,
        violations: [`Consecutive period requirement not met for practical session.`],
      };
    }
  }

  // ── Rebuild state WITHOUT the original session ────────────────
  const sessionsWithout = sessions.filter(s => s.taskId !== original.taskId);
  const stateWithout    = rebuildState(sessionsWithout, config);

  // ── Build the proposed session object ───────────────────────
  const proposed = {
    ...original,
    day:       newDay,
    periodIds: newPeriodIds,
    roomId:    newRoomId,
  };

  // ── Check constraints for the proposed placement ─────────────
  const faculty  = facultyMap.get(original.facultyId);
  const division = divisionMap.get(original.divisionId);

  // Build a minimal task descriptor for checkConstraints
  const subject = subjectMap.get(original.subjectId);
  const task = {
    id:               original.taskId,
    divisionId:       original.divisionId,
    subjectId:        original.subjectId,
    sessionType:      original.sessionType,
    facultyId:        original.facultyId,
    requiredRoomType: original.sessionType === 'practical'
      ? (subject?.labRoomType || 'lab')
      : (subject?.roomType || 'classroom'),
    periodsRequired,
  };

  const violation = checkConstraints(stateWithout, task, newDay, newPeriodIds, room, faculty, division);

  if (violation) {
    return {
      accepted: false,
      reason: `Move rejected: ${violation}`,
      originalSession: original,
      proposedSession: proposed,
      violations: [violation],
    };
  }

  return {
    accepted: true,
    reason: `Move accepted: ${original.taskId} → ${newDay} period(s) [${newPeriodIds.join(',')}] in ${room.name}.`,
    originalSession: original,
    proposedSession: proposed,
    violations: [],
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// PUBLIC API: applyMove()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Apply an accepted EditProposal and return a new sessions array.
 * Throws if the proposal was not accepted.
 *
 * @param {import('./scheduler').PlacedSession[]} sessions
 * @param {EditProposal} proposal
 * @returns {import('./scheduler').PlacedSession[]}
 */
function applyMove(sessions, proposal) {
  if (!proposal.accepted) {
    throw new Error(`Cannot apply a rejected proposal: ${proposal.reason}`);
  }
  return sessions
    .filter(s => s.taskId !== proposal.originalSession.taskId)
    .concat([proposal.proposedSession]);
}

module.exports = { proposeMove, applyMove };
