import React, { useState, useEffect, useCallback } from 'react';
import {
  CollegeConfig,
  PlacedSession,
  ScheduleResult,
  ValidationReport,
  ActiveTab,
  Subject,
  Faculty,
  Room,
  SubjectAssignment,
  EditProposal,
} from './types';
import { DEMO_CONFIG } from './engine/demoData';
import { schedule } from './engine/scheduler';
import { validate } from './engine/validator';
import {
  loadStoredConfig,
  saveStoredConfig,
  loadStoredSessions,
  saveStoredSessions,
  loadStoredResult,
  saveStoredResult,
  clearStoredData,
} from './storage/localStorage';
import { validateAndParseImportedJSON } from './engine/exportUtils';

import { Navbar } from './components/common/Navbar';
import { Sidebar } from './components/common/Sidebar';
import { ToastContainer, ToastMessage } from './components/common/Toast';
import { ConfirmModal } from './components/common/ConfirmModal';

import { Dashboard } from './components/dashboard/Dashboard';
import { TimetableGrid } from './components/timetable/TimetableGrid';
import { CollegeConfigForm } from './components/config/CollegeConfigForm';
import { SubjectManagement } from './components/subjects/SubjectManagement';
import { FacultyManagement } from './components/faculty/FacultyManagement';
import { RoomManagement } from './components/rooms/RoomManagement';
import { DiagnosticsPanel } from './components/diagnostics/DiagnosticsPanel';

export const App: React.FC = () => {
  // Main states
  const [config, setConfig] = useState<CollegeConfig>(() => loadStoredConfig());
  const [sessions, setSessions] = useState<PlacedSession[]>(() => {
    const stored = loadStoredSessions();
    if (stored && stored.length > 0) return stored;
    // Initial generation on first open so app works immediately
    const initialResult = schedule(loadStoredConfig());
    saveStoredSessions(initialResult.sessions);
    saveStoredResult(initialResult);
    return initialResult.sessions;
  });

  const [scheduleResult, setScheduleResult] = useState<ScheduleResult | null>(() => {
    const stored = loadStoredResult();
    if (stored) return stored;
    return schedule(loadStoredConfig());
  });

  const [validationReport, setValidationReport] = useState<ValidationReport | null>(null);
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  // Undo history stack for manual timetable modifications
  const [history, setHistory] = useState<PlacedSession[][]>([]);

  // Toast notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback(
    (type: ToastMessage['type'], title: string, message?: string) => {
      const id = Date.now().toString() + Math.random().toString().slice(2, 6);
      setToasts((prev) => [...prev, { id, type, title, message }]);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Keep validator report updated whenever sessions or config change
  useEffect(() => {
    if (sessions && sessions.length > 0) {
      const report = validate(sessions, config);
      setValidationReport(report);
    } else {
      setValidationReport(null);
    }
  }, [sessions, config]);

  // Timetable Generation Action
  const handleGenerate = useCallback(() => {
    setIsGenerating(true);
    // Short tick so UI shows generating spinner
    setTimeout(() => {
      try {
        const result = schedule(config);
        setScheduleResult(result);
        setSessions(result.sessions);
        setHistory([]); // clear undo on fresh generation

        saveStoredSessions(result.sessions);
        saveStoredResult(result);

        const report = validate(result.sessions, config);
        setValidationReport(report);

        if (result.status === 'complete') {
          addToast(
            'success',
            'Timetable Generated Successfully!',
            `Scheduled all ${result.stats.totalTasks} sessions with 0 hard conflicts in ${result.stats.executionTimeMs}ms.`
          );
        } else if (result.status === 'partial') {
          addToast(
            'warning',
            'Partial Timetable Generated',
            `Placed ${result.stats.scheduledCount} of ${result.stats.totalTasks} sessions. Check diagnostics for resource bottleneck suggestions.`
          );
        } else {
          addToast(
            'error',
            'Scheduling Failed',
            'Could not place sessions under current constraints. Check room availability or faculty load.'
          );
        }
      } catch (err: any) {
        addToast('error', 'Generation Error', err.message || 'An unexpected error occurred');
      } finally {
        setIsGenerating(false);
      }
    }, 250);
  }, [config, addToast]);

  // Reset to Demo Data
  const handleConfirmReset = () => {
    clearStoredData();
    const demo = DEMO_CONFIG;
    setConfig(demo);
    saveStoredConfig(demo);

    const result = schedule(demo);
    setScheduleResult(result);
    setSessions(result.sessions);
    setHistory([]);
    saveStoredSessions(result.sessions);
    saveStoredResult(result);

    setIsResetConfirmOpen(false);
    addToast('info', 'Demo Data Loaded', 'Restored St. Xavier’s CSE curriculum, faculty, and room configuration.');
  };

  // Manual Session Move
  const handleApplyMove = (updatedSessions: PlacedSession[], proposal: EditProposal) => {
    setHistory((prev) => [...prev, sessions]);
    setSessions(updatedSessions);
    saveStoredSessions(updatedSessions);

    addToast(
      'success',
      'Session Relocated',
      proposal.reason || 'Timetable updated and verified conflict-free.'
    );
  };

  // Undo Last Move
  const handleUndo = () => {
    if (history.length === 0) return;
    const previous = history[history.length - 1];
    setHistory((prev) => prev.slice(0, prev.length - 1));
    setSessions(previous);
    saveStoredSessions(previous);
    addToast('info', 'Edit Undone', 'Reverted timetable to previous placement.');
  };

  // Config Update
  const handleSaveConfig = (updated: CollegeConfig) => {
    setConfig(updated);
    saveStoredConfig(updated);
    addToast('success', 'Settings Saved', 'College settings, working days, and period structure updated.');
  };

  // Subjects Update
  const handleUpdateSubjects = (
    updatedSubjects: Subject[],
    updatedAssignments: SubjectAssignment[]
  ) => {
    const updated: CollegeConfig = {
      ...config,
      subjects: updatedSubjects,
      assignments: updatedAssignments,
    };
    setConfig(updated);
    saveStoredConfig(updated);
    addToast('success', 'Subjects Updated', 'Subject definitions and division allocations updated.');
  };

  // Faculty Update
  const handleUpdateFaculty = (updatedFaculty: Faculty[]) => {
    const updated: CollegeConfig = {
      ...config,
      faculty: updatedFaculty,
    };
    setConfig(updated);
    saveStoredConfig(updated);
    addToast('success', 'Faculty Updated', 'Faculty records and availability matrices updated.');
  };

  // Rooms Update
  const handleUpdateRooms = (updatedRooms: Room[]) => {
    const updated: CollegeConfig = {
      ...config,
      rooms: updatedRooms,
    };
    setConfig(updated);
    saveStoredConfig(updated);
    addToast('success', 'Facilities Updated', 'Classroom and laboratory parameters updated.');
  };

  // JSON Import
  const handleImportJSON = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const { valid, config: importedConfig, sessions: importedSessions, error } =
        validateAndParseImportedJSON(text);

      if (!valid || !importedConfig) {
        addToast('error', 'Import Failed', error || 'Invalid project JSON schema.');
        return;
      }

      setConfig(importedConfig);
      saveStoredConfig(importedConfig);

      if (importedSessions && importedSessions.length > 0) {
        setSessions(importedSessions);
        saveStoredSessions(importedSessions);
      } else {
        const result = schedule(importedConfig);
        setScheduleResult(result);
        setSessions(result.sessions);
        saveStoredSessions(result.sessions);
        saveStoredResult(result);
      }

      setHistory([]);
      addToast(
        'success',
        'Project Configuration Imported',
        `Loaded ${importedConfig.collegeName} (${importedConfig.subjects.length} subjects, ${importedConfig.faculty.length} faculty).`
      );
    };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 selection:bg-gold-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        config={config}
        sessions={sessions}
        scheduleResult={scheduleResult}
        isGenerating={isGenerating}
        onGenerate={handleGenerate}
        onResetConfirm={() => setIsResetConfirmOpen(true)}
        onImportJSON={handleImportJSON}
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
      />

      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {/* Sidebar Navigation */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={(tab) => setActiveTab(tab)}
          isMobileOpen={isMobileMenuOpen}
          onCloseMobile={() => setIsMobileMenuOpen(false)}
          validationReport={validationReport}
        />

        {/* Main Tab Content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0 overflow-y-auto">
          {activeTab === 'dashboard' && (
            <Dashboard
              config={config}
              sessions={sessions}
              scheduleResult={scheduleResult}
              validationReport={validationReport}
              isGenerating={isGenerating}
              onGenerate={handleGenerate}
              onNavigate={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'timetable' && (
            <TimetableGrid
              config={config}
              sessions={sessions}
              canUndo={history.length > 0}
              onUndo={handleUndo}
              onApplyMove={handleApplyMove}
              onRegenerate={handleGenerate}
              isGenerating={isGenerating}
            />
          )}

          {activeTab === 'config' && (
            <CollegeConfigForm config={config} onSaveConfig={handleSaveConfig} />
          )}

          {activeTab === 'subjects' && (
            <SubjectManagement config={config} onUpdateSubjects={handleUpdateSubjects} />
          )}

          {activeTab === 'faculty' && (
            <FacultyManagement
              config={config}
              sessions={sessions}
              onUpdateFaculty={handleUpdateFaculty}
            />
          )}

          {activeTab === 'rooms' && (
            <RoomManagement
              config={config}
              sessions={sessions}
              onUpdateRooms={handleUpdateRooms}
            />
          )}

          {activeTab === 'diagnostics' && (
            <DiagnosticsPanel
              scheduleResult={scheduleResult}
              validationReport={validationReport}
              config={config}
              onNavigate={(tab) => setActiveTab(tab)}
            />
          )}
        </main>
      </div>

      {/* Reset Confirmation Modal */}
      <ConfirmModal
        isOpen={isResetConfirmOpen}
        title="Reset to Realistic Demo Data?"
        message="This will overwrite current subjects, faculty, and room configurations with the default St. Xavier's CS curriculum and regenerate a clean timetable."
        confirmLabel="Reset & Regenerate"
        isDestructive={false}
        onConfirm={handleConfirmReset}
        onCancel={() => setIsResetConfirmOpen(false)}
      />

      {/* Global Toast Notifications */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
};

export default App;
