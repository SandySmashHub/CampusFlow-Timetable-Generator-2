/**
 * CampusFlow – Independent Timetable Validator
 * =============================================
 * Validates a completed timetable INDEPENDENTLY of the scheduling algorithm.
 * This means it re-checks every constraint from scratch using only:
 *   • The list of placed sessions
 *   • The original config (rooms, faculty, periods, assignments)
 *
 * VALIDATION CHECKS
 * -----------------
 *  V01  Invalid session references (unknown division/faculty/room/subject)
 *  V02  Session on a non-working day
 *  V03  Session in a break or lunch period
 *  V04  Division clash (two sessions for same division at same day+period)
 *  V05  Faculty clash (faculty teaching two sessions simultaneously)
 *  V06  Room clash (room double-booked)
 *  V07  Faculty unavailability (session in faculty blocked slot)
 *  V08  Room unavailability (session in room blocked slot)
 *  V09  Room type mismatch
 *  V10  Room capacity violation
 *  V11  Practical non-consecutive periods
 *  V12  Practical periods crossing a break/lunch
 *  V13  Weekly session count mismatch (too few OR too many)
 *  V14  Faculty daily load exceeded
 *  V15  Faculty weekly load exceeded
 *
 * Returns a ValidationReport object (see typedef below).
 */

'use strict';

const { indexBy, slotKey } = require('./scheduler.cjs');

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Create a ValidationError entry.
 * @param {string} code
 * @param {string} message
 * @param {object} [context]
 * @returns {ValidationError}
 *
 * @typedef {object} ValidationError
 * @property {string} code
 * @property {string} message
 * @property {object} [context]
 */
function err(code, message, context) {
  return { code, message, context };
}

// ─────────────────────────────────────────────────────────────────────────────
// PUBLIC API: validate()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Validate a timetable against the original config.
 *
 * @param {import('./scheduler').PlacedSession[]} sessions
 * @param {object} config
 * @returns {ValidationReport}
 *
 * @typedef {object} ValidationReport
 * @property {boolean}           valid      - true iff zero errors
 * @property {boolean}           complete   - true iff all required sessions present
 * @property {ValidationError[]} errors
 * @property {object}            summary
 */
function validate(sessions, config) {
  const errors = [];

  // Build lookup maps
  const roomMap     = indexBy(config.rooms,     r => r.id);
  const facultyMap  = indexBy(config.faculty,   f => f.id);
  const divisionMap = indexBy(config.divisions, d => d.id);
  const subjectMap  = indexBy(config.subjects,  s => s.id);
  const periodMap   = indexBy(config.periods,   p => p.id);
  const workingDaySet = new Set(config.workingDays);

  // Occupancy re-built from sessions (for clash detection)
  // Map<"divId|day:pid" | "facId|day:pid" | "roomId|day:pid", taskId[]>
  const divisionSlots = new Map();  // "divId:day:pid" → [taskId, ...]
  const facultySlots  = new Map();  // "facId:day:pid" → [taskId, ...]
  const roomSlots     = new Map();  // "roomId:day:pid" → [taskId, ...]

  function addOccupancy(map, key, taskId) {
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(taskId);
  }

  // Track load per faculty
  const facultyDailyLoad  = new Map(); // "facId:day" → count
  const facultyWeeklyLoad = new Map(); // facId → count

  // ──────────────────────────────────────────────────────────────
  // Pass 1: Per-session structural checks
  // ──────────────────────────────────────────────────────────────
  for (const session of sessions) {
    const { taskId, divisionId, subjectId, subjectName, sessionType,
            facultyId, roomId, day, periodIds } = session;

    // V01 – Invalid references
    const division = divisionMap.get(divisionId);
    const faculty  = facultyMap.get(facultyId);
    const room     = roomMap.get(roomId);
    const subject  = subjectMap.get(subjectId);

    if (!division) {
      errors.push(err('V01', `Unknown division '${divisionId}'`, { taskId }));
      continue;
    }
    if (!faculty) {
      errors.push(err('V01', `Unknown faculty '${facultyId}'`, { taskId }));
    }
    if (!room) {
      errors.push(err('V01', `Unknown room '${roomId}'`, { taskId }));
      continue;
    }
    if (!subject) {
      errors.push(err('V01', `Unknown subject '${subjectId}'`, { taskId }));
    }

    // V02 – Non-working day
    if (!workingDaySet.has(day)) {
      errors.push(err('V02', `Session on non-working day '${day}'`, { taskId, day }));
    }

    // V03 – Period must be lecture type; V11/V12 – Practical consecutiveness
    let prevPeriodId = null;
    for (const pid of periodIds) {
      const period = periodMap.get(pid);
      if (!period) {
        errors.push(err('V03', `Unknown period id ${pid}`, { taskId }));
        continue;
      }
      if (period.type !== 'lecture') {
        errors.push(err('V03', `Session in a ${period.type} slot (period ${pid})`, { taskId, pid }));
      }

      // V11 – Non-consecutive (period numbers must be sequential)
      if (prevPeriodId !== null && pid !== prevPeriodId + 1) {
        errors.push(err('V11', `Practical periods not consecutive: ${prevPeriodId} → ${pid}`, { taskId }));
      }

      // V12 – Crossing break/lunch between consecutive periods
      if (prevPeriodId !== null) {
        for (let check = prevPeriodId + 1; check < pid; check++) {
          const between = periodMap.get(check);
          if (between && between.type !== 'lecture') {
            errors.push(err('V12', `Practical spans a ${between.type} at period ${check}`, { taskId }));
          }
        }
      }

      prevPeriodId = pid;
    }

    // Occupancy recording + clash detection will happen in pass 2
    for (const pid of periodIds) {
      const k = `${day}:${pid}`;
      addOccupancy(divisionSlots, `${divisionId}|${k}`, taskId);
      if (faculty) addOccupancy(facultySlots, `${facultyId}|${k}`, taskId);
      addOccupancy(roomSlots, `${roomId}|${k}`, taskId);

      // V07 – Faculty availability
      if (faculty?.blockedSlots?.has(slotKey(day, pid))) {
        errors.push(err('V07', `Faculty '${faculty.name}' unavailable at ${slotKey(day, pid)}`, { taskId }));
      }

      // V08 – Room availability
      if (room.blockedSlots?.has(slotKey(day, pid))) {
        errors.push(err('V08', `Room '${room.name}' unavailable at ${slotKey(day, pid)}`, { taskId }));
      }
    }

    // V09 – Room type
    const requiredType = sessionType === 'practical'
      ? (subject?.labRoomType || 'lab')
      : (subject?.roomType || 'classroom');
    if (room.type !== requiredType) {
      errors.push(err('V09',
        `Room type mismatch for ${taskId}: need '${requiredType}', room is '${room.type}'`,
        { taskId, roomId, requiredType, actual: room.type }
      ));
    }

    // V10 – Room capacity
    const relevantStrength = (room.type === 'lab')
      ? (division.practicalBatchSize ?? Math.ceil(division.strength / 2))
      : division.strength;
    if (room.capacity < relevantStrength) {
      errors.push(err('V10',
        `Room '${room.name}' capacity ${room.capacity} < ${relevantStrength} (${room.type === 'lab' ? 'batch' : 'class'})`,
        { taskId }
      ));
    }

    // Faculty load accumulation
    if (faculty) {
      const dlKey = `${facultyId}:${day}`;
      facultyDailyLoad.set(dlKey, (facultyDailyLoad.get(dlKey) || 0) + periodIds.length);
      facultyWeeklyLoad.set(facultyId, (facultyWeeklyLoad.get(facultyId) || 0) + periodIds.length);
    }
  }

  // ──────────────────────────────────────────────────────────────
  // Pass 2: Clash detection across sessions
  // ──────────────────────────────────────────────────────────────

  // V04 – Division clashes
  for (const [key, ids] of divisionSlots.entries()) {
    if (ids.length > 1) {
      const [divId, day, pid] = key.split('|');
      errors.push(err('V04', `Division clash at ${day}:${pid} for ${divId} — tasks: ${ids.join(', ')}`,
        { key, taskIds: ids }));
    }
  }

  // V05 – Faculty clashes
  for (const [key, ids] of facultySlots.entries()) {
    if (ids.length > 1) {
      const [facId, day, pid] = key.split('|');
      errors.push(err('V05', `Faculty clash at ${day}:${pid} for ${facId} — tasks: ${ids.join(', ')}`,
        { key, taskIds: ids }));
    }
  }

  // V06 – Room clashes
  for (const [key, ids] of roomSlots.entries()) {
    if (ids.length > 1) {
      const [roomId, day, pid] = key.split('|');
      errors.push(err('V06', `Room clash at ${day}:${pid} for ${roomId} — tasks: ${ids.join(', ')}`,
        { key, taskIds: ids }));
    }
  }

  // ──────────────────────────────────────────────────────────────
  // Pass 3: Faculty load checks
  // ──────────────────────────────────────────────────────────────

  for (const faculty of config.faculty) {
    // V14 – Daily load
    for (const day of config.workingDays) {
      const count = facultyDailyLoad.get(`${faculty.id}:${day}`) || 0;
      if (count > faculty.maxPeriodsPerDay) {
        errors.push(err('V14',
          `${faculty.name} daily load on ${day}: ${count} > max ${faculty.maxPeriodsPerDay}`,
          { facultyId: faculty.id, day, count, max: faculty.maxPeriodsPerDay }
        ));
      }
    }
    // V15 – Weekly load
    const wk = facultyWeeklyLoad.get(faculty.id) || 0;
    if (wk > faculty.maxPeriodsPerWeek) {
      errors.push(err('V15',
        `${faculty.name} weekly load: ${wk} > max ${faculty.maxPeriodsPerWeek}`,
        { facultyId: faculty.id, count: wk, max: faculty.maxPeriodsPerWeek }
      ));
    }
  }

  // ──────────────────────────────────────────────────────────────
  // Pass 4: V13 – Session count completeness
  // ──────────────────────────────────────────────────────────────
  const { expandTasks } = require('./scheduler.cjs');
  const requiredTasks = expandTasks(config);
  const requiredCountMap = new Map(); // "divId:subjectId:sessionType" → count

  for (const t of requiredTasks) {
    const k = `${t.divisionId}:${t.subjectId}:${t.sessionType}`;
    requiredCountMap.set(k, (requiredCountMap.get(k) || 0) + 1);
  }

  const scheduledCountMap = new Map();
  for (const s of sessions) {
    const k = `${s.divisionId}:${s.subjectId}:${s.sessionType}`;
    scheduledCountMap.set(k, (scheduledCountMap.get(k) || 0) + 1);
  }

  for (const [k, required] of requiredCountMap.entries()) {
    const scheduled = scheduledCountMap.get(k) || 0;
    if (scheduled !== required) {
      const [divId, subjectId, sessionType] = k.split(':');
      errors.push(err('V13',
        `${divId}/${subjectId}/${sessionType}: required ${required}, scheduled ${scheduled}`,
        { divisionId: divId, subjectId, sessionType, required, scheduled }
      ));
    }
  }
  // Also check for extra sessions (sessions not required)
  for (const [k, scheduled] of scheduledCountMap.entries()) {
    if (!requiredCountMap.has(k)) {
      const [divId, subjectId, sessionType] = k.split(':');
      errors.push(err('V13',
        `${divId}/${subjectId}/${sessionType}: ${scheduled} extra session(s) not required`,
        { divisionId: divId, subjectId, sessionType, required: 0, scheduled }
      ));
    }
  }

  // ──────────────────────────────────────────────────────────────
  // Summary
  // ──────────────────────────────────────────────────────────────
  const totalRequired = requiredTasks.length;
  const totalScheduled = sessions.length;

  return {
    valid: errors.length === 0,
    complete: totalScheduled === totalRequired && errors.filter(e => e.code === 'V13').length === 0,
    errors,
    summary: {
      totalErrors: errors.length,
      totalRequired,
      totalScheduled,
      errorsByCode: errors.reduce((acc, e) => {
        acc[e.code] = (acc[e.code] || 0) + 1;
        return acc;
      }, {}),
    },
  };
}

module.exports = { validate };
