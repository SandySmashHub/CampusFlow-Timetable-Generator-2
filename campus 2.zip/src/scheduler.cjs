/**
 * CampusFlow – Core Scheduling Engine
 * =====================================
 * Constraint-based backtracking scheduler with MCV (Most Constrained Variable)
 * ordering heuristic.
 *
 * ALGORITHM OVERVIEW
 * ------------------
 * 1. Session Expansion
 *    Convert every (division, subject, assignment) record into flat "task" objects,
 *    one per required lecture and one practical BLOCK per required practical session.
 *
 * 2. Ordering (MCV heuristic)
 *    Tasks are sorted so the hardest-to-schedule sessions are attempted first:
 *      a. Practical blocks (consecutive-period requirement makes them harder).
 *      b. Sessions with fewer valid candidate slots (fewest available faculty/room
 *         intersections across all days).
 *      c. Prefer sessions whose faculty or room is shared across many divisions.
 *
 * 3. Backtracking Search
 *    For each unscheduled task (in MCV order):
 *      – Generate candidate (day, startPeriod, room) triples.
 *      – Score candidates using soft-preference hints (preferred days/periods).
 *      – Iterate candidates cheapest-first.
 *      – For each candidate, check ALL hard constraints (see checkConstraints).
 *      – If valid, place the session; recurse to schedule the next task.
 *      – If recursion fails, undo and try next candidate (backtrack).
 *    Terminate early when backtrack count exceeds maxBacktracks.
 *
 * 4. Hard Constraints Checked on Every Placement
 *    C1  – Division: no two sessions overlap for the same division.
 *    C2  – Faculty: no two sessions overlap for the same faculty member.
 *    C3  – Room: no two sessions overlap for the same room.
 *    C4  – Faculty availability (blockedSlots).
 *    C5  – Room availability (blockedSlots).
 *    C6  – Room type match (classroom / lab).
 *    C7  – Room capacity ≥ division strength.
 *    C8  – Practical periods must be consecutive and within the same day without
 *           crossing a break/lunch slot.
 *    C9  – Faculty daily load limit.
 *    C10 – Faculty weekly load limit.
 *
 * 5. Result
 *    Returns a structured result object (see scheduleResult schema at bottom).
 *
 * DATA STRUCTURES USED INTERNALLY
 * --------------------------------
 *  occupancy maps  – {divisionId/facultyId/roomId → Set<"Day:periodId">}
 *    for O(1) conflict checking without re-scanning the timetable.
 *  dailyLoad map   – {facultyId:Day → count}
 *  weeklyLoad map  – {facultyId → count}
 */

'use strict';

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────

/** Create a slot key string. */
function slotKey(day, periodId) {
  return `${day}:${periodId}`;
}

/**
 * Build lookup maps from arrays for O(1) access.
 * @template T
 * @param {T[]} arr
 * @param {(item: T) => string} keyFn
 * @returns {Map<string, T>}
 */
function indexBy(arr, keyFn) {
  const map = new Map();
  for (const item of arr) map.set(keyFn(item), item);
  return map;
}

// ─────────────────────────────────────────────────────────────────────────────
// SESSION / TASK EXPANSION
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Expand the config assignments into flat task descriptors.
 * Each task represents one session that must be placed in the timetable.
 *
 * @param {object} config
 * @returns {Task[]}
 *
 * @typedef {object} Task
 * @property {string}   id             - Unique task identifier
 * @property {string}   divisionId
 * @property {string}   subjectId
 * @property {string}   subjectName
 * @property {'lecture'|'practical'} sessionType
 * @property {string}   facultyId
 * @property {string}   requiredRoomType  - 'classroom' | 'lab'
 * @property {number}   periodsRequired   - 1 for lecture, N for practical
 * @property {string[]|null} preferredDays
 * @property {number[]|null} preferredPeriods
 */
function expandTasks(config) {
  const { assignments, subjects } = config;
  const subjectMap = indexBy(subjects, s => s.id);
  const tasks = [];
  let seq = 0;

  for (const asgn of assignments) {
    const subj = subjectMap.get(asgn.subjectId);
    if (!subj) continue;

    // Lectures
    for (let i = 0; i < subj.lecturesPerWeek; i++) {
      tasks.push({
        id: `T${++seq}`,
        divisionId: asgn.divisionId,
        subjectId: subj.id,
        subjectName: subj.name,
        sessionType: 'lecture',
        facultyId: asgn.facultyLectureId,
        requiredRoomType: subj.roomType,
        periodsRequired: 1,
        preferredDays: asgn.preferredDays || null,
        preferredPeriods: asgn.preferredPeriods || null,
      });
    }

    // Practical blocks
    if (subj.practicalsPerWeek > 0 && asgn.facultyPracticalId) {
      for (let i = 0; i < subj.practicalsPerWeek; i++) {
        tasks.push({
          id: `T${++seq}`,
          divisionId: asgn.divisionId,
          subjectId: subj.id,
          subjectName: subj.name,
          sessionType: 'practical',
          facultyId: asgn.facultyPracticalId,
          requiredRoomType: subj.labRoomType || 'lab',
          periodsRequired: subj.practicalPeriods,
          preferredDays: asgn.preferredDays || null,
          preferredPeriods: asgn.preferredPeriods || null,
        });
      }
    }
  }

  return tasks;
}

// ─────────────────────────────────────────────────────────────────────────────
// CANDIDATE GENERATION
// ─────────────────────────────────────────────────────────────────────────────

/**
 * For a given task, generate all (day, startPeriodId, room) triples that
 * STRUCTURALLY could host the session (ignoring current occupancy).
 * Used for MCV ordering.
 *
 * @param {Task} task
 * @param {object} config
 * @param {Map} roomMap
 * @param {Map} facultyMap
 * @param {Map<number,object>} periodMap
 * @returns {Array<{day:string, startPeriodId:number, room:object, prefScore:number}>}
 */
function generateCandidates(task, config, roomMap, facultyMap, periodMap) {
  const { workingDays, schedulablePeriodIds } = config;
  const faculty = facultyMap.get(task.facultyId);
  const candidates = [];

  for (const day of workingDays) {
    for (const startPeriodId of schedulablePeriodIds) {
      // Check consecutive periods exist for practicals
      if (task.periodsRequired > 1) {
        const consecutive = getConsecutivePeriods(
          startPeriodId, task.periodsRequired, schedulablePeriodIds, periodMap
        );
        if (!consecutive) continue;
      }

      // Check faculty structural availability for all required periods
      const periodIds = task.periodsRequired === 1
        ? [startPeriodId]
        : getConsecutivePeriods(startPeriodId, task.periodsRequired, schedulablePeriodIds, periodMap) || [];
      if (periodIds.length === 0) continue;

      if (faculty && faculty.blockedSlots) {
        let blocked = false;
        for (const pid of periodIds) {
          if (faculty.blockedSlots.has(slotKey(day, pid))) { blocked = true; break; }
        }
        if (blocked) continue;
      }

      // Check suitable rooms
      for (const room of config.rooms) {
        if (room.type !== task.requiredRoomType) continue;

        let roomBlocked = false;
        if (room.blockedSlots) {
          for (const pid of periodIds) {
            if (room.blockedSlots.has(slotKey(day, pid))) { roomBlocked = true; break; }
          }
        }
        if (roomBlocked) continue;

        // Preference score (lower = more preferred)
        let prefScore = 0;
        if (task.preferredDays && !task.preferredDays.includes(day)) prefScore += 10;
        if (task.preferredPeriods && !task.preferredPeriods.includes(startPeriodId)) prefScore += 5;

        candidates.push({ day, startPeriodId, room, prefScore });
      }
    }
  }

  return candidates;
}

/**
 * Return an array of N consecutive schedulable period IDs starting from startId,
 * or null if the window crosses a non-lecture period or runs out of bounds.
 *
 * @param {number} startId
 * @param {number} count
 * @param {number[]} schedulablePeriodIds  - sorted ascending
 * @param {Map<number,object>} periodMap
 * @returns {number[]|null}
 */
function getConsecutivePeriods(startId, count, schedulablePeriodIds, periodMap) {
  const result = [];
  let current = startId;
  for (let i = 0; i < count; i++) {
    const period = periodMap.get(current);
    if (!period || period.type !== 'lecture') return null;
    if (!schedulablePeriodIds.includes(current)) return null;
    result.push(current);
    current++; // periods are numbered sequentially; gaps (breaks/lunch) break the run
  }
  // Verify no break/lunch in sequence
  for (const id of result) {
    const p = periodMap.get(id);
    if (!p || p.type !== 'lecture') return null;
  }
  return result;
}

// ─────────────────────────────────────────────────────────────────────────────
// MCV ORDERING
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Sort tasks so the most constrained are scheduled first.
 * Heuristic priority (descending importance):
 *   1. Practical tasks before lecture tasks.
 *   2. Fewest structural candidates (ascending).
 *   3. Tie-break by task id.
 *
 * @param {Task[]} tasks
 * @param {object} config
 * @param {Map} roomMap
 * @param {Map} facultyMap
 * @param {Map} periodMap
 * @returns {Task[]}
 */
function sortByMCV(tasks, config, roomMap, facultyMap, periodMap) {
  const candidateCounts = new Map();
  for (const task of tasks) {
    const cands = generateCandidates(task, config, roomMap, facultyMap, periodMap);
    candidateCounts.set(task.id, cands.length);
  }

  return [...tasks].sort((a, b) => {
    // Practicals first
    const aIsPrac = a.sessionType === 'practical' ? 0 : 1;
    const bIsPrac = b.sessionType === 'practical' ? 0 : 1;
    if (aIsPrac !== bIsPrac) return aIsPrac - bIsPrac;
    // Fewer candidates first
    const diff = candidateCounts.get(a.id) - candidateCounts.get(b.id);
    if (diff !== 0) return diff;
    return a.id.localeCompare(b.id);
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// STATE / OCCUPANCY MANAGEMENT
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Create the mutable scheduling state.
 * @param {object} config
 * @returns {ScheduleState}
 *
 * @typedef {object} ScheduleState
 * @property {Map<string, Set<string>>} divisionOccupancy  - divId → Set<"Day:pid">
 * @property {Map<string, Set<string>>} facultyOccupancy   - facId → Set<"Day:pid">
 * @property {Map<string, Set<string>>} roomOccupancy      - roomId → Set<"Day:pid">
 * @property {Map<string, number>}      dailyLoad          - "facId:Day" → count
 * @property {Map<string, number>}      weeklyLoad         - facId → count
 * @property {PlacedSession[]}          sessions
 *
 * @typedef {object} PlacedSession
 * @property {string}   taskId
 * @property {string}   divisionId
 * @property {string}   subjectId
 * @property {string}   subjectName
 * @property {'lecture'|'practical'} sessionType
 * @property {string}   facultyId
 * @property {string}   roomId
 * @property {string}   day
 * @property {number[]} periodIds
 */
function createState(config) {
  const divOcc = new Map();
  const facOcc = new Map();
  const roomOcc = new Map();
  const dailyLoad = new Map();
  const weeklyLoad = new Map();

  for (const div of config.divisions) divOcc.set(div.id, new Set());
  for (const fac of config.faculty) {
    facOcc.set(fac.id, new Set());
    weeklyLoad.set(fac.id, 0);
    for (const day of config.workingDays) dailyLoad.set(`${fac.id}:${day}`, 0);
  }
  for (const room of config.rooms) roomOcc.set(room.id, new Set());

  return { divisionOccupancy: divOcc, facultyOccupancy: facOcc, roomOccupancy: roomOcc,
           dailyLoad, weeklyLoad, sessions: [] };
}

/**
 * Place a session into the state (mutates).
 * @param {ScheduleState} state
 * @param {PlacedSession} session
 */
function placeSession(state, session) {
  const { day, periodIds, divisionId, facultyId, roomId } = session;
  for (const pid of periodIds) {
    const k = slotKey(day, pid);
    state.divisionOccupancy.get(divisionId).add(k);
    state.facultyOccupancy.get(facultyId).add(k);
    state.roomOccupancy.get(roomId).add(k);
  }
  const dlKey = `${facultyId}:${day}`;
  state.dailyLoad.set(dlKey, (state.dailyLoad.get(dlKey) || 0) + periodIds.length);
  state.weeklyLoad.set(facultyId, (state.weeklyLoad.get(facultyId) || 0) + periodIds.length);
  state.sessions.push(session);
}

/**
 * Remove the last placed session from the state (mutates, used for backtracking).
 * @param {ScheduleState} state
 */
function removeLastSession(state) {
  const session = state.sessions.pop();
  if (!session) return;
  const { day, periodIds, divisionId, facultyId, roomId } = session;
  for (const pid of periodIds) {
    const k = slotKey(day, pid);
    state.divisionOccupancy.get(divisionId).delete(k);
    state.facultyOccupancy.get(facultyId).delete(k);
    state.roomOccupancy.get(roomId).delete(k);
  }
  const dlKey = `${facultyId}:${day}`;
  state.dailyLoad.set(dlKey, (state.dailyLoad.get(dlKey) || 0) - periodIds.length);
  state.weeklyLoad.set(facultyId, (state.weeklyLoad.get(facultyId) || 0) - periodIds.length);
}

// ─────────────────────────────────────────────────────────────────────────────
// CONSTRAINT CHECKING
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Check all hard constraints for placing a candidate session.
 * Returns null on success, or a reason string on failure.
 *
 * @param {ScheduleState} state
 * @param {Task} task
 * @param {string} day
 * @param {number[]} periodIds
 * @param {object} room
 * @param {object} faculty
 * @param {object} division
 * @returns {null|string}  null = OK, string = constraint violation description
 */
function checkConstraints(state, task, day, periodIds, room, faculty, division) {
  for (const pid of periodIds) {
    const k = slotKey(day, pid);

    // C1 – Division clash
    if (state.divisionOccupancy.get(task.divisionId)?.has(k)) {
      return `Division clash: ${task.divisionId} already busy at ${k}`;
    }

    // C2 – Faculty clash
    if (faculty && state.facultyOccupancy.get(task.facultyId)?.has(k)) {
      return `Faculty clash: ${faculty.name} already teaching at ${k}`;
    }

    // C3 – Room clash
    if (state.roomOccupancy.get(room.id)?.has(k)) {
      return `Room clash: ${room.name} already in use at ${k}`;
    }

    // C4 – Faculty availability
    if (faculty?.blockedSlots?.has(k)) {
      return `Faculty unavailable: ${faculty.name} at ${k}`;
    }

    // C5 – Room availability
    if (room.blockedSlots?.has(k)) {
      return `Room unavailable: ${room.name} at ${k}`;
    }
  }

  // C6 – Room type
  if (room.type !== task.requiredRoomType) {
    return `Room type mismatch: need ${task.requiredRoomType}, got ${room.type}`;
  }

  // C7 – Room capacity
  // For labs (practicals), use practicalBatchSize if defined; else fall back to full strength.
  // For classrooms (lectures), use full division strength.
  if (division) {
    const relevantStrength = (room.type === 'lab')
      ? (division.practicalBatchSize ?? Math.ceil(division.strength / 2))
      : division.strength;
    if (room.capacity < relevantStrength) {
      return `Room capacity insufficient: ${room.capacity} < ${relevantStrength} (${room.type === 'lab' ? 'batch' : 'class'})`;
    }
  }

  // C9 – Faculty daily load
  if (faculty) {
    const dlKey = `${faculty.id}:${day}`;
    const currentDaily = state.dailyLoad.get(dlKey) || 0;
    if (currentDaily + periodIds.length > faculty.maxPeriodsPerDay) {
      return `Faculty daily load exceeded: ${faculty.name} on ${day}`;
    }

    // C10 – Faculty weekly load
    const currentWeekly = state.weeklyLoad.get(faculty.id) || 0;
    if (currentWeekly + periodIds.length > faculty.maxPeriodsPerWeek) {
      return `Faculty weekly load exceeded: ${faculty.name}`;
    }
  }

  return null; // all constraints satisfied
}

// ─────────────────────────────────────────────────────────────────────────────
// BACKTRACKING SEARCH
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Recursive backtracking scheduler.
 *
 * @param {Task[]} tasks            - Remaining tasks to schedule (MCV ordered)
 * @param {number} index            - Current task index
 * @param {ScheduleState} state
 * @param {object} config
 * @param {Map} roomMap
 * @param {Map} facultyMap
 * @param {Map} divisionMap
 * @param {Map} periodMap
 * @param {{count: number}} backtracks  - Mutable counter
 * @returns {boolean}  true if all tasks were successfully scheduled
 */
function backtrack(tasks, index, state, config, roomMap, facultyMap, divisionMap, periodMap, backtracks) {
  if (index === tasks.length) return true; // all tasks placed ✓

  if (backtracks.count >= config.maxBacktracks) return false; // search limit

  const task = tasks[index];
  const faculty = facultyMap.get(task.facultyId);
  const division = divisionMap.get(task.divisionId);

  // Generate candidates for this task (only structurally valid slots)
  const rawCandidates = generateCandidates(task, config, roomMap, facultyMap, periodMap);

  // Sort: prefer lower prefScore (matches preferred days/periods)
  rawCandidates.sort((a, b) => a.prefScore - b.prefScore);

  for (const cand of rawCandidates) {
    const { day, startPeriodId, room } = cand;

    // Resolve full period list for this candidate
    const periodIds = task.periodsRequired === 1
      ? [startPeriodId]
      : getConsecutivePeriods(startPeriodId, task.periodsRequired, config.schedulablePeriodIds, periodMap) || [];

    if (periodIds.length === 0) continue;

    // Check all hard constraints
    const violation = checkConstraints(state, task, day, periodIds, room, faculty, division);
    if (violation) continue; // try next candidate

    // Place session
    const session = {
      taskId: task.id,
      divisionId: task.divisionId,
      subjectId: task.subjectId,
      subjectName: task.subjectName,
      sessionType: task.sessionType,
      facultyId: task.facultyId,
      roomId: room.id,
      day,
      periodIds,
    };
    placeSession(state, session);

    // Recurse
    if (backtrack(tasks, index + 1, state, config, roomMap, facultyMap, divisionMap, periodMap, backtracks)) {
      return true;
    }

    // Backtrack
    removeLastSession(state);
    backtracks.count++;
  }

  return false; // no valid candidate found for this task
}

// ─────────────────────────────────────────────────────────────────────────────
// DIAGNOSTICS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Analyse why sessions couldn't be scheduled and provide suggestions.
 * @param {Task[]} unscheduledTasks
 * @param {ScheduleState} state
 * @param {object} config
 * @param {Map} roomMap
 * @param {Map} facultyMap
 * @param {Map} periodMap
 * @returns {{messages: string[], suggestions: string[]}}
 */
function diagnose(unscheduledTasks, state, config, roomMap, facultyMap, periodMap) {
  const messages = [];
  const suggestions = [];

  for (const task of unscheduledTasks) {
    const faculty = facultyMap.get(task.facultyId);
    const rawCandidates = generateCandidates(task, config, roomMap, facultyMap, periodMap);

    messages.push(
      `[${task.id}] ${task.divisionId} / ${task.subjectName} (${task.sessionType}) – ` +
      `${rawCandidates.length} structural slot(s) before occupancy check`
    );

    if (rawCandidates.length === 0) {
      messages.push(`  → No structural slot exists (check faculty/room availability and type).`);

      if (faculty) {
        const wkLoad = state.weeklyLoad.get(faculty.id) || 0;
        messages.push(`  → ${faculty.name} weekly load: ${wkLoad}/${faculty.maxPeriodsPerWeek}`);
        if (wkLoad >= faculty.maxPeriodsPerWeek) {
          suggestions.push(`Increase weekly load limit for ${faculty.name}, or assign another faculty.`);
        }
      }

      const suitableRooms = config.rooms.filter(r => r.type === task.requiredRoomType);
      if (suitableRooms.length === 0) {
        suggestions.push(`Add a ${task.requiredRoomType} to the room list for ${task.subjectName}.`);
      }
    }
  }

  if (unscheduledTasks.some(t => t.sessionType === 'practical')) {
    suggestions.push('Practical blocks need consecutive free periods. Consider spreading subjects across more days or adding lab rooms.');
  }

  return { messages, suggestions };
}

// ─────────────────────────────────────────────────────────────────────────────
// PUBLIC API: schedule()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Run the scheduling algorithm.
 *
 * @param {object} config  - See data.js CONFIG schema
 * @returns {ScheduleResult}
 *
 * @typedef {object} ScheduleResult
 * @property {'complete'|'partial'|'failed'} status
 * @property {PlacedSession[]}  sessions           - Successfully scheduled sessions
 * @property {Task[]}           unscheduledTasks   - Tasks that could not be placed
 * @property {string[]}         validationErrors   - Populated after independent validation
 * @property {{backtracks:number, searchLimitReached:boolean, totalTasks:number}} stats
 * @property {string[]}         diagnosticMessages
 * @property {string[]}         suggestions
 */
function schedule(config) {
  // Build lookup maps
  const roomMap     = indexBy(config.rooms,    r => r.id);
  const facultyMap  = indexBy(config.faculty,  f => f.id);
  const divisionMap = indexBy(config.divisions, d => d.id);
  const periodMap   = indexBy(config.periods,  p => p.id);

  // Expand all tasks
  const rawTasks = expandTasks(config);

  // Order by MCV
  const tasks = sortByMCV(rawTasks, config, roomMap, facultyMap, periodMap);

  // Initialise state
  const state = createState(config);
  const backtracks = { count: 0 };

  // Run backtracking
  const success = backtrack(
    tasks, 0, state, config, roomMap, facultyMap, divisionMap, periodMap, backtracks
  );

  const searchLimitReached = !success && backtracks.count >= config.maxBacktracks;

  // Determine unscheduled tasks
  const scheduledTaskIds = new Set(state.sessions.map(s => s.taskId));
  const unscheduledTasks = tasks.filter(t => !scheduledTaskIds.has(t.id));

  // Diagnostics
  const { messages: diagnosticMessages, suggestions } = diagnose(
    unscheduledTasks, state, config, roomMap, facultyMap, periodMap
  );

  let status;
  if (unscheduledTasks.length === 0) status = 'complete';
  else if (state.sessions.length > 0) status = 'partial';
  else status = 'failed';

  return {
    status,
    sessions: state.sessions,
    unscheduledTasks,
    validationErrors: [],   // caller should run validate() and merge
    stats: {
      backtracks: backtracks.count,
      searchLimitReached,
      totalTasks: tasks.length,
      scheduledCount: state.sessions.length,
    },
    diagnosticMessages,
    suggestions,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// EXPORTS
// ─────────────────────────────────────────────────────────────────────────────

module.exports = {
  schedule,
  expandTasks,
  sortByMCV,
  generateCandidates,
  getConsecutivePeriods,
  checkConstraints,
  createState,
  placeSession,
  removeLastSession,
  indexBy,
  slotKey,
};
