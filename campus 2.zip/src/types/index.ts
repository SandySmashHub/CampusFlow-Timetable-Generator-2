export type SessionType = 'lecture' | 'practical';
export type RoomType = 'classroom' | 'lab';
export type PeriodType = 'lecture' | 'break' | 'lunch';

export interface Period {
  id: number;
  label: string; // e.g., "08:00–08:55"
  startTime: string; // e.g. "08:00"
  endTime: string; // e.g. "08:55"
  type: PeriodType;
}

export interface Room {
  id: string;
  name: string;
  type: RoomType;
  capacity: number;
  blockedSlots?: string[]; // array of "Day:periodId" e.g., "Friday:8"
}

export interface Faculty {
  id: string;
  name: string;
  email?: string;
  department?: string;
  maxPeriodsPerDay: number;
  maxPeriodsPerWeek: number;
  blockedSlots?: string[]; // array of "Day:periodId"
}

export interface Subject {
  id: string;
  code: string;
  name: string;
  department?: string;
  lecturesPerWeek: number;
  practicalsPerWeek: number;
  practicalPeriods: number; // consecutive periods per practical block (e.g. 2)
  roomType: RoomType; // usually 'classroom'
  labRoomType?: RoomType; // usually 'lab'
  color?: string; // Hex or tailwind color class
  preferredDays?: string[];
  preferredPeriods?: number[];
}

export interface Division {
  id: string;
  name: string;
  strength: number;
  practicalBatchSize?: number;
}

export interface SubjectAssignment {
  divisionId: string;
  subjectId: string;
  facultyLectureId: string;
  facultyPracticalId?: string | null;
  preferredDays?: string[];
  preferredPeriods?: number[];
}

export interface CollegeConfig {
  collegeName: string;
  academicYear: string;
  semester: string;
  department: string;
  workingDays: string[];
  periods: Period[];
  schedulablePeriodIds: number[];
  rooms: Room[];
  faculty: Faculty[];
  subjects: Subject[];
  divisions: Division[];
  assignments: SubjectAssignment[];
  maxBacktracks: number;
}

export interface Task {
  id: string;
  divisionId: string;
  subjectId: string;
  subjectName: string;
  subjectCode: string;
  sessionType: SessionType;
  facultyId: string;
  requiredRoomType: RoomType;
  periodsRequired: number;
  preferredDays?: string[] | null;
  preferredPeriods?: number[] | null;
}

export interface PlacedSession {
  taskId: string;
  divisionId: string;
  subjectId: string;
  subjectName: string;
  subjectCode?: string;
  sessionType: SessionType;
  facultyId: string;
  roomId: string;
  day: string;
  periodIds: number[];
}

export interface ScheduleStats {
  backtracks: number;
  searchLimitReached: boolean;
  totalTasks: number;
  scheduledCount: number;
  executionTimeMs: number;
}

export interface ScheduleResult {
  status: 'complete' | 'partial' | 'failed';
  sessions: PlacedSession[];
  unscheduledTasks: Task[];
  validationErrors: string[];
  stats: ScheduleStats;
  diagnosticMessages: string[];
  suggestions: string[];
}

export interface ValidationError {
  code: string;
  message: string;
  context?: Record<string, any>;
}

export interface ValidationReport {
  valid: boolean;
  complete: boolean;
  errors: ValidationError[];
  summary: {
    totalSessions: number;
    totalRequired: number;
    totalScheduled: number;
    facultyClashes: number;
    roomClashes: number;
    divisionClashes: number;
  };
}

export interface MoveSpec {
  taskId: string;
  newDay?: string;
  newStartPeriodId?: number;
  newRoomId?: string;
}

export interface EditProposal {
  accepted: boolean;
  reason: string;
  originalSession: PlacedSession | null;
  proposedSession: PlacedSession | null;
  violations: string[];
}

export type ViewMode = 'class' | 'faculty' | 'room';
export type ActiveTab = 'dashboard' | 'timetable' | 'config' | 'subjects' | 'faculty' | 'rooms' | 'diagnostics';
