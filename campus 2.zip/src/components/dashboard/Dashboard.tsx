import React from 'react';
import {
  BookOpen,
  Users,
  Building2,
  CalendarCheck2,
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Cpu,
  Layers,
  Clock,
  ShieldCheck,
  ShieldAlert,
} from 'lucide-react';
import {
  CollegeConfig,
  PlacedSession,
  ScheduleResult,
  ValidationReport,
  ActiveTab,
} from '../../types';
import { expandTasks } from '../../engine/scheduler';

interface DashboardProps {
  config: CollegeConfig;
  sessions: PlacedSession[];
  scheduleResult: ScheduleResult | null;
  validationReport: ValidationReport | null;
  isGenerating: boolean;
  onGenerate: () => void;
  onNavigate: (tab: ActiveTab) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  config,
  sessions,
  scheduleResult,
  validationReport,
  isGenerating,
  onGenerate,
  onNavigate,
}) => {
  // Compute real dynamic statistics
  const totalSubjects = config.subjects.length;
  const totalFaculty = config.faculty.length;
  const totalRooms = config.rooms.length;
  const classroomCount = config.rooms.filter((r) => r.type === 'classroom').length;
  const labCount = config.rooms.filter((r) => r.type === 'lab').length;

  const allRequiredTasks = expandTasks(config);
  const totalRequiredSessions = allRequiredTasks.length;
  const totalScheduledSessions = sessions.length;
  const unscheduledCount = Math.max(0, totalRequiredSessions - totalScheduledSessions);

  const completionPercentage =
    totalRequiredSessions > 0
      ? Math.round((totalScheduledSessions / totalRequiredSessions) * 100)
      : 0;

  const facultyClashes = validationReport?.summary.facultyClashes ?? 0;
  const roomClashes = validationReport?.summary.roomClashes ?? 0;
  const divisionClashes = validationReport?.summary.divisionClashes ?? 0;
  const totalClashes = facultyClashes + roomClashes + divisionClashes;

  // Faculty load distribution
  const facultyLoadMap = new Map<string, number>();
  for (const s of sessions) {
    const cur = facultyLoadMap.get(s.facultyId) || 0;
    facultyLoadMap.set(s.facultyId, cur + s.periodIds.length);
  }

  // Room usage distribution
  const roomUsageMap = new Map<string, number>();
  for (const s of sessions) {
    const cur = roomUsageMap.get(s.roomId) || 0;
    roomUsageMap.set(s.roomId, cur + s.periodIds.length);
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner with College Info & Status */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-navy-950 via-navy-900 to-navy-800 text-white p-6 md:p-8 shadow-xl border border-navy-800">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-[radial-gradient(circle_at_top_right,rgba(245,158,11,0.15),transparent_70%)] pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-gold-500/10 text-gold-400 border border-gold-500/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Constraint Satisfaction Timetable Scheduler</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight text-white">
              {config.collegeName}
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl">
              {config.department} • {config.academicYear} • {config.semester}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('timetable')}
              className="px-4 py-2.5 text-xs font-semibold text-white bg-navy-800 hover:bg-navy-700 border border-navy-700 rounded-xl transition-all shadow-sm"
            >
              Open Timetable View
            </button>
            <button
              onClick={onGenerate}
              disabled={isGenerating}
              className="px-5 py-2.5 text-xs font-bold text-navy-950 bg-gradient-to-r from-gold-400 to-gold-500 hover:from-gold-300 hover:to-gold-400 rounded-xl shadow-lg shadow-gold-500/20 active:scale-95 transition-all flex items-center gap-2"
            >
              {isGenerating ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-navy-950 border-t-transparent rounded-full animate-spin" />
                  <span>Computing...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Now</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Completion */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Schedule Status
            </span>
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                completionPercentage === 100
                  ? 'bg-emerald-50 text-emerald-600'
                  : completionPercentage > 0
                  ? 'bg-amber-50 text-amber-600'
                  : 'bg-slate-50 text-slate-400'
              }`}
            >
              <CalendarCheck2 className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-navy-950">{completionPercentage}%</span>
            <span className="text-xs font-medium text-slate-500">
              ({totalScheduledSessions}/{totalRequiredSessions} sessions)
            </span>
          </div>
          <div className="mt-3 w-full bg-slate-100 rounded-full h-2 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                completionPercentage === 100
                  ? 'bg-emerald-500'
                  : completionPercentage > 0
                  ? 'bg-amber-500'
                  : 'bg-slate-300'
              }`}
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
        </div>

        {/* KPI 2: Conflicts */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Hard Conflicts
            </span>
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                totalClashes === 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'
              }`}
            >
              {totalClashes === 0 ? (
                <ShieldCheck className="w-5 h-5" />
              ) : (
                <ShieldAlert className="w-5 h-5" />
              )}
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span
              className={`text-3xl font-extrabold ${
                totalClashes === 0 ? 'text-emerald-600' : 'text-rose-600'
              }`}
            >
              {totalClashes}
            </span>
            <span className="text-xs font-medium text-slate-500">
              {totalClashes === 0 ? 'Zero clashes detected' : 'Violations detected'}
            </span>
          </div>
          <div className="mt-3 flex items-center gap-2 text-[11px] text-slate-500">
            <span>Fac: {facultyClashes}</span>
            <span>•</span>
            <span>Room: {roomClashes}</span>
            <span>•</span>
            <span>Div: {divisionClashes}</span>
          </div>
        </div>

        {/* KPI 3: Academic Resources */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Academic Resources
            </span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-navy-950">{totalFaculty}</span>
            <span className="text-xs font-medium text-slate-500">Faculty Members</span>
          </div>
          <div className="mt-3 flex items-center gap-2 text-[11px] text-slate-500">
            <span>{totalSubjects} Subjects</span>
            <span>•</span>
            <span>{config.divisions.length} Divisions</span>
          </div>
        </div>

        {/* KPI 4: Infrastructure */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Rooms & Labs
            </span>
            <div className="w-9 h-9 rounded-xl bg-gold-50 text-gold-600 flex items-center justify-center">
              <Building2 className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-navy-950">{totalRooms}</span>
            <span className="text-xs font-medium text-slate-500">Spaces Configured</span>
          </div>
          <div className="mt-3 flex items-center gap-2 text-[11px] text-slate-500">
            <span>{classroomCount} Classrooms</span>
            <span>•</span>
            <span>{labCount} Laboratories</span>
          </div>
        </div>
      </div>

      {/* Middle Section: Diagnostics & Quick Alerts if any */}
      {unscheduledCount > 0 && (
        <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-5">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-bold text-amber-900">
                Partial Schedule: {unscheduledCount} session(s) pending placement
              </h3>
              <p className="text-xs text-amber-700 mt-1">
                The constraint solver placed {totalScheduledSessions} of {totalRequiredSessions}{' '}
                sessions without violating hard rules. Click below to inspect exact conflict
                diagnostics and smart suggestions.
              </p>
              {scheduleResult?.suggestions && scheduleResult.suggestions.length > 0 && (
                <div className="mt-3 space-y-1.5">
                  <div className="text-[11px] font-semibold text-amber-900 uppercase tracking-wider">
                    Recommended Fixes:
                  </div>
                  {scheduleResult.suggestions.slice(0, 2).map((sugg, i) => (
                    <div
                      key={i}
                      className="text-xs text-amber-800 bg-white/70 px-3 py-1.5 rounded-lg border border-amber-200/60"
                    >
                      💡 {sugg}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <button
              onClick={() => onNavigate('diagnostics')}
              className="px-3.5 py-1.5 text-xs font-semibold text-amber-900 bg-amber-200/80 hover:bg-amber-200 rounded-xl transition-colors shrink-0"
            >
              View Diagnostics
            </button>
          </div>
        </div>
      )}

      {/* Grid: Faculty Load & Room Load */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Faculty Load Card */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-navy-950">Faculty Teaching Load</h3>
              <p className="text-xs text-slate-500">Scheduled periods vs weekly maximum limits</p>
            </div>
            <button
              onClick={() => onNavigate('faculty')}
              className="text-xs font-medium text-navy-700 hover:text-navy-950 flex items-center gap-1"
            >
              Manage <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3 pt-1">
            {config.faculty.map((fac) => {
              const assigned = facultyLoadMap.get(fac.id) || 0;
              const max = fac.maxPeriodsPerWeek;
              const pct = max > 0 ? Math.min(100, Math.round((assigned / max) * 100)) : 0;
              const isOverloaded = assigned > max;

              return (
                <div key={fac.id} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800 truncate max-w-[200px]">
                      {fac.name}
                    </span>
                    <span
                      className={`font-mono font-medium ${
                        isOverloaded
                          ? 'text-rose-600 font-bold'
                          : assigned === max
                          ? 'text-amber-600'
                          : 'text-slate-600'
                      }`}
                    >
                      {assigned} / {max} periods ({pct}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        isOverloaded
                          ? 'bg-rose-500'
                          : pct >= 80
                          ? 'bg-amber-500'
                          : 'bg-navy-700'
                      }`}
                      style={{ width: `${Math.min(100, pct)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Room Allocation Card */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-navy-950">Facility Utilization</h3>
              <p className="text-xs text-slate-500">Total teaching periods hosted per room</p>
            </div>
            <button
              onClick={() => onNavigate('rooms')}
              className="text-xs font-medium text-navy-700 hover:text-navy-950 flex items-center gap-1"
            >
              Manage <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3 pt-1">
            {config.rooms.map((room) => {
              const periodsHosted = roomUsageMap.get(room.id) || 0;
              // Total potential weekly slots = workingDays * schedulablePeriods
              const totalSlots = config.workingDays.length * config.schedulablePeriodIds.length;
              const pct = totalSlots > 0 ? Math.round((periodsHosted / totalSlots) * 100) : 0;

              return (
                <div key={room.id} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-800">{room.name}</span>
                      <span
                        className={`px-1.5 py-0.2 rounded text-[10px] uppercase font-bold ${
                          room.type === 'lab'
                            ? 'bg-purple-100 text-purple-700'
                            : 'bg-blue-100 text-blue-700'
                        }`}
                      >
                        {room.type}
                      </span>
                    </div>
                    <span className="font-mono text-slate-600">
                      {periodsHosted} periods ({pct}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        room.type === 'lab' ? 'bg-purple-600' : 'bg-blue-600'
                      }`}
                      style={{ width: `${Math.min(100, pct)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Quick Subject Overview */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-navy-950">Active Subject Curricula</h3>
            <p className="text-xs text-slate-500">Lectures, practical sessions, and lab allocations</p>
          </div>
          <button
            onClick={() => onNavigate('subjects')}
            className="text-xs font-medium text-navy-700 hover:text-navy-950 flex items-center gap-1"
          >
            All Subjects <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {config.subjects.map((subj) => (
            <div
              key={subj.id}
              className="p-3.5 rounded-xl border border-slate-200 hover:border-navy-300 transition-colors bg-slate-50/50"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-mono text-xs font-bold text-navy-900 bg-white px-2 py-0.5 rounded border border-slate-200 shadow-2xs">
                  {subj.code}
                </span>
                <span className="text-[10px] text-slate-500">
                  {subj.lecturesPerWeek}L + {subj.practicalsPerWeek}P
                </span>
              </div>
              <h4 className="text-xs font-semibold text-slate-900 truncate">{subj.name}</h4>
              <p className="text-[11px] text-slate-500 mt-1">
                Room: {subj.roomType}
                {subj.practicalsPerWeek > 0 && ` • Lab: ${subj.labRoomType || 'lab'} (${subj.practicalPeriods}p)`}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
