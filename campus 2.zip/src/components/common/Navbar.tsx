import React, { useRef } from 'react';
import {
  Sparkles,
  RotateCcw,
  Download,
  Upload,
  Printer,
  FileSpreadsheet,
  Calendar,
  Layers,
  Menu,
} from 'lucide-react';
import { CollegeConfig, PlacedSession, ScheduleResult } from '../../types';
import { exportTimetableToCSV, exportProjectConfigJSON } from '../../engine/exportUtils';

interface NavbarProps {
  config: CollegeConfig;
  sessions: PlacedSession[];
  scheduleResult: ScheduleResult | null;
  isGenerating: boolean;
  onGenerate: () => void;
  onResetConfirm: () => void;
  onImportJSON: (file: File) => void;
  onToggleMobileMenu: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  config,
  sessions,
  scheduleResult,
  isGenerating,
  onGenerate,
  onResetConfirm,
  onImportJSON,
  onToggleMobileMenu,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImportJSON(file);
      e.target.value = '';
    }
  };

  const getStatusBadge = () => {
    if (!scheduleResult) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-600 border border-slate-200">
          <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
          Not Generated
        </span>
      );
    }

    if (scheduleResult.status === 'complete') {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 shadow-sm">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          100% Conflict-Free
        </span>
      );
    }

    if (scheduleResult.status === 'partial') {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
          Partial ({scheduleResult.stats.scheduledCount}/{scheduleResult.stats.totalTasks})
        </span>
      );
    }

    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
        <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
        Generation Failed
      </span>
    );
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-slate-200 no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Left Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={onToggleMobileMenu}
              className="md:hidden p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 focus:outline-none"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-navy-900 to-navy-700 flex items-center justify-center text-gold-400 shadow-md shadow-navy-900/10">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold tracking-tight text-navy-950">CampusFlow</span>
                  <span className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] uppercase font-bold tracking-wider rounded bg-gold-50 text-gold-700 border border-gold-300">
                    Smart Engine
                  </span>
                </div>
                <p className="text-xs text-slate-500 truncate max-w-[200px] md:max-w-xs">
                  {config.department} • {config.academicYear}
                </p>
              </div>
            </div>
          </div>

          {/* Center Status Badge */}
          <div className="hidden lg:flex items-center gap-3">
            {getStatusBadge()}
            {scheduleResult && scheduleResult.stats.executionTimeMs > 0 && (
              <span className="text-xs text-slate-400">
                generated in {scheduleResult.stats.executionTimeMs}ms ({scheduleResult.stats.backtracks} backtracks)
              </span>
            )}
          </div>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2">
            {/* Hidden JSON input */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".json"
              className="hidden"
            />

            {/* Print button */}
            <button
              onClick={() => window.print()}
              title="Print Timetable"
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors shadow-sm"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Print</span>
            </button>

            {/* Export CSV button */}
            <button
              onClick={() => exportTimetableToCSV(sessions, config)}
              title="Export as CSV"
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors shadow-sm"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden md:inline">CSV</span>
            </button>

            {/* Export JSON */}
            <button
              onClick={() => exportProjectConfigJSON(config, sessions)}
              title="Export Full Project JSON"
              className="hidden xl:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export</span>
            </button>

            {/* Import JSON */}
            <button
              onClick={() => fileInputRef.current?.click()}
              title="Import Project JSON"
              className="hidden xl:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors shadow-sm"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Import</span>
            </button>

            {/* Reset Demo */}
            <button
              onClick={onResetConfirm}
              title="Reset to Demo Data"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors shadow-sm"
            >
              <RotateCcw className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden sm:inline">Reset Demo</span>
            </button>

            {/* Primary Generate Button */}
            <button
              onClick={onGenerate}
              disabled={isGenerating}
              className="relative inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-gradient-to-r from-navy-900 to-navy-800 hover:from-navy-800 hover:to-navy-700 active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl shadow-md shadow-navy-900/20 border border-navy-700/50 transition-all duration-200 group"
            >
              {isGenerating ? (
                <>
                  <div className="w-4 h-4 border-2 border-gold-400 border-t-transparent rounded-full animate-spin"></div>
                  <span>Solving CSP...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-gold-400 group-hover:rotate-12 transition-transform" />
                  <span>Generate Timetable</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
