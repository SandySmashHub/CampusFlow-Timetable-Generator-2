import React from 'react';
import {
  LayoutDashboard,
  CalendarDays,
  Settings,
  BookOpen,
  Users,
  Building2,
  ShieldAlert,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { ActiveTab, ValidationReport } from '../../types';

interface SidebarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
  validationReport?: ValidationReport | null;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  isMobileOpen,
  onCloseMobile,
  validationReport,
}) => {
  const navItems = [
    {
      id: 'dashboard' as ActiveTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'timetable' as ActiveTab,
      label: 'Timetable Grid',
      icon: CalendarDays,
      badge: null,
    },
    {
      id: 'config' as ActiveTab,
      label: 'College & Schedule',
      icon: Settings,
      badge: null,
    },
    {
      id: 'subjects' as ActiveTab,
      label: 'Subjects',
      icon: BookOpen,
      badge: null,
    },
    {
      id: 'faculty' as ActiveTab,
      label: 'Faculty Members',
      icon: Users,
      badge: null,
    },
    {
      id: 'rooms' as ActiveTab,
      label: 'Rooms & Labs',
      icon: Building2,
      badge: null,
    },
    {
      id: 'diagnostics' as ActiveTab,
      label: 'Diagnostics & Rules',
      icon: ShieldAlert,
      badge: validationReport && !validationReport.valid ? `${validationReport.errors.length}` : null,
      badgeColor: 'bg-rose-100 text-rose-700',
    },
  ];

  const handleItemClick = (id: ActiveTab) => {
    onSelectTab(id);
    onCloseMobile();
  };

  const content = (
    <div className="flex flex-col h-full bg-navy-950 text-slate-300">
      {/* College Info Header */}
      <div className="p-5 border-b border-navy-800/80">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gold-500/10 border border-gold-500/30 flex items-center justify-center text-gold-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-white tracking-wide">CampusFlow OS</h2>
            <p className="text-[11px] text-slate-400">Constraint Satisfaction Engine</p>
          </div>
        </div>
      </div>

      {/* Nav list */}
      <div className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
          Navigation
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => handleItemClick(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all group ${
                isActive
                  ? 'bg-navy-800 text-gold-400 shadow-inner font-semibold border-l-2 border-gold-400'
                  : 'text-slate-300 hover:bg-navy-900 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-4 h-4 transition-colors ${
                    isActive ? 'text-gold-400' : 'text-slate-400 group-hover:text-slate-200'
                  }`}
                />
                <span>{item.label}</span>
              </div>

              <div className="flex items-center gap-1.5">
                {item.badge && (
                  <span
                    className={`px-1.5 py-0.5 text-[10px] font-bold rounded-full ${
                      item.badgeColor || 'bg-navy-700 text-slate-200'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
                {isActive && <ChevronRight className="w-3.5 h-3.5 text-gold-400/80" />}
              </div>
            </button>
          );
        })}
      </div>

      {/* Footer info */}
      <div className="p-4 border-t border-navy-800/80 bg-navy-900/50">
        <div className="bg-navy-900/90 rounded-xl p-3 border border-navy-800 text-xs">
          <div className="flex items-center justify-between text-slate-300 mb-1">
            <span className="font-semibold text-white">Hackathon Build</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 font-mono">
              v1.0.0
            </span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Zero backend required. 100% client-side constraint backtracking search.
          </p>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop fixed sidebar */}
      <aside className="hidden md:block w-64 shrink-0 h-[calc(100vh-4rem)] sticky top-16 no-print shadow-xl">
        {content}
      </aside>

      {/* Mobile Drawer */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            className="fixed inset-0 bg-navy-950/70 backdrop-blur-sm transition-opacity"
            onClick={onCloseMobile}
          />
          <div className="relative flex-1 flex flex-col max-w-xs w-full bg-navy-950 z-10 shadow-2xl">
            {content}
          </div>
        </div>
      )}
    </>
  );
};
