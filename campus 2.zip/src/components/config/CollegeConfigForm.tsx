import React, { useState } from 'react';
import {
  Settings,
  Calendar,
  Clock,
  Building,
  GraduationCap,
  Save,
  Check,
  Plus,
  Trash2,
  AlertCircle,
  Coffee,
  Utensils,
} from 'lucide-react';
import { CollegeConfig, Period, PeriodType } from '../../types';

interface CollegeConfigFormProps {
  config: CollegeConfig;
  onSaveConfig: (updated: CollegeConfig) => void;
}

export const CollegeConfigForm: React.FC<CollegeConfigFormProps> = ({
  config,
  onSaveConfig,
}) => {
  const [formData, setFormData] = useState<CollegeConfig>({ ...config });
  const [isSaved, setIsSaved] = useState(false);

  const ALL_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const toggleDay = (day: string) => {
    let nextDays: string[];
    if (formData.workingDays.includes(day)) {
      if (formData.workingDays.length <= 1) return; // Prevent 0 days
      nextDays = formData.workingDays.filter((d) => d !== day);
    } else {
      nextDays = [...formData.workingDays, day];
      // Keep natural day order
      nextDays.sort((a, b) => ALL_DAYS.indexOf(a) - ALL_DAYS.indexOf(b));
    }
    setFormData({ ...formData, workingDays: nextDays });
  };

  const handlePeriodTypeChange = (id: number, type: PeriodType) => {
    const updated = formData.periods.map((p) => (p.id === id ? { ...p, type } : p));
    const schedulable = updated.filter((p) => p.type === 'lecture').map((p) => p.id);
    setFormData({ ...formData, periods: updated, schedulablePeriodIds: schedulable });
  };

  const handlePeriodTimingChange = (
    id: number,
    field: 'startTime' | 'endTime' | 'label',
    val: string
  ) => {
    const updated = formData.periods.map((p) => {
      if (p.id === id) {
        const next = { ...p, [field]: val };
        if (field === 'startTime' || field === 'endTime') {
          next.label = `${field === 'startTime' ? val : p.startTime}–${
            field === 'endTime' ? val : p.endTime
          }`;
        }
        return next;
      }
      return p;
    });
    setFormData({ ...formData, periods: updated });
  };

  const addPeriod = () => {
    const nextId = formData.periods.length + 1;
    const newPeriod: Period = {
      id: nextId,
      label: `Period ${nextId}`,
      startTime: '16:50',
      endTime: '17:45',
      type: 'lecture',
    };
    const updated = [...formData.periods, newPeriod];
    const schedulable = updated.filter((p) => p.type === 'lecture').map((p) => p.id);
    setFormData({ ...formData, periods: updated, schedulablePeriodIds: schedulable });
  };

  const removePeriod = (id: number) => {
    if (formData.periods.length <= 3) return; // Keep minimum periods
    const updated = formData.periods
      .filter((p) => p.id !== id)
      .map((p, index) => ({ ...p, id: index + 1 }));
    const schedulable = updated.filter((p) => p.type === 'lecture').map((p) => p.id);
    setFormData({ ...formData, periods: updated, schedulablePeriodIds: schedulable });
  };

  const handleDivisionChange = (index: number, field: string, val: any) => {
    const updated = [...formData.divisions];
    updated[index] = { ...updated[index], [field]: val };
    setFormData({ ...formData, divisions: updated });
  };

  const addDivision = () => {
    const nextLetter = String.fromCharCode(65 + formData.divisions.length);
    const newDiv = {
      id: `DIV-${nextLetter}`,
      name: `CS Division ${nextLetter}`,
      strength: 60,
      practicalBatchSize: 30,
    };
    setFormData({ ...formData, divisions: [...formData.divisions, newDiv] });
  };

  const removeDivision = (index: number) => {
    if (formData.divisions.length <= 1) return;
    const updated = formData.divisions.filter((_, i) => i !== index);
    setFormData({ ...formData, divisions: updated });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveConfig(formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-5xl animate-in fade-in duration-200">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-8 h-8 rounded-lg bg-navy-100 text-navy-900 flex items-center justify-center font-bold">
              <Settings className="w-4 h-4" />
            </span>
            <h2 className="text-lg font-bold text-navy-950">College & Schedule Parameters</h2>
          </div>
          <p className="text-xs text-slate-500">
            Define institutional details, working days, daily period slots, and class divisions.
          </p>
        </div>

        <button
          type="submit"
          className="px-5 py-2.5 text-xs font-bold text-white bg-navy-900 hover:bg-navy-800 rounded-xl shadow-md shadow-navy-900/20 active:scale-95 transition-all flex items-center gap-2 self-start sm:self-auto"
        >
          {isSaved ? (
            <>
              <Check className="w-4 h-4 text-emerald-400" />
              <span>Saved Successfully</span>
            </>
          ) : (
            <>
              <Save className="w-4 h-4 text-gold-400" />
              <span>Save Configuration</span>
            </>
          )}
        </button>
      </div>

      {/* Institutional Metadata Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
        <h3 className="text-sm font-bold text-navy-950 flex items-center gap-2">
          <Building className="w-4 h-4 text-navy-700" />
          <span>Institutional Information</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700">College / University Name</label>
            <input
              type="text"
              value={formData.collegeName}
              onChange={(e) => setFormData({ ...formData, collegeName: e.target.value })}
              className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
              required
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700">Department</label>
            <input
              type="text"
              value={formData.department}
              onChange={(e) => setFormData({ ...formData, department: e.target.value })}
              className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
              required
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700">Academic Year</label>
            <input
              type="text"
              value={formData.academicYear}
              onChange={(e) => setFormData({ ...formData, academicYear: e.target.value })}
              className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
              required
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700">Semester / Term</label>
            <input
              type="text"
              value={formData.semester}
              onChange={(e) => setFormData({ ...formData, semester: e.target.value })}
              className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
              required
            />
          </div>
        </div>
      </div>

      {/* Working Days Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
        <h3 className="text-sm font-bold text-navy-950 flex items-center gap-2">
          <Calendar className="w-4 h-4 text-navy-700" />
          <span>Institutional Working Days</span>
        </h3>
        <p className="text-xs text-slate-500">
          The timetable generator will only allocate periods on these active working days.
        </p>

        <div className="flex flex-wrap gap-2.5">
          {ALL_DAYS.map((day) => {
            const isChecked = formData.workingDays.includes(day);
            return (
              <button
                type="button"
                key={day}
                onClick={() => toggleDay(day)}
                className={`px-4 py-2.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 border ${
                  isChecked
                    ? 'bg-navy-900 text-white border-navy-900 shadow-sm'
                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div
                  className={`w-3.5 h-3.5 rounded flex items-center justify-center border text-[9px] ${
                    isChecked
                      ? 'bg-gold-400 text-navy-950 border-gold-400'
                      : 'border-slate-400 bg-white'
                  }`}
                >
                  {isChecked && '✓'}
                </div>
                <span>{day}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Class Divisions Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-navy-950 flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-navy-700" />
              <span>Classes & Student Divisions</span>
            </h3>
            <p className="text-xs text-slate-500">
              Each division receives an independent timetable schedule with zero internal clashes.
            </p>
          </div>
          <button
            type="button"
            onClick={addDivision}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-navy-900 bg-navy-50 hover:bg-navy-100 border border-navy-200 rounded-xl transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Division</span>
          </button>
        </div>

        <div className="space-y-3">
          {formData.divisions.map((div, index) => (
            <div
              key={div.id}
              className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 flex flex-col md:flex-row md:items-center justify-between gap-3"
            >
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 flex-1">
                <div>
                  <label className="text-[11px] font-semibold text-slate-500">Division ID</label>
                  <input
                    type="text"
                    value={div.id}
                    onChange={(e) => handleDivisionChange(index, 'id', e.target.value)}
                    className="w-full text-xs font-mono font-bold bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-900"
                    required
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-500">Division Name</label>
                  <input
                    type="text"
                    value={div.name}
                    onChange={(e) => handleDivisionChange(index, 'name', e.target.value)}
                    className="w-full text-xs font-semibold bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-900"
                    required
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-500">
                    Total Strength / Batch Size
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={10}
                      max={200}
                      value={div.strength}
                      onChange={(e) =>
                        handleDivisionChange(index, 'strength', Number(e.target.value))
                      }
                      className="w-1/2 text-xs font-medium bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-900"
                      title="Total student strength"
                    />
                    <input
                      type="number"
                      min={5}
                      max={div.strength}
                      value={div.practicalBatchSize || Math.ceil(div.strength / 2)}
                      onChange={(e) =>
                        handleDivisionChange(index, 'practicalBatchSize', Number(e.target.value))
                      }
                      className="w-1/2 text-xs font-medium bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-900"
                      title="Lab batch size"
                    />
                  </div>
                </div>
              </div>

              {formData.divisions.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeDivision(index)}
                  className="p-2 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors self-end md:self-center"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Daily Periods & Breaks Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-navy-950 flex items-center gap-2">
              <Clock className="w-4 h-4 text-navy-700" />
              <span>Daily Period Structure & Break Timings</span>
            </h3>
            <p className="text-xs text-slate-500">
              Set start/end timings, and designate intervals as Lecture slots, Tea Breaks, or Lunch
              Breaks.
            </p>
          </div>
          <button
            type="button"
            onClick={addPeriod}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-navy-900 bg-navy-50 hover:bg-navy-100 border border-navy-200 rounded-xl transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Period Slot</span>
          </button>
        </div>

        <div className="space-y-2">
          {formData.periods.map((p) => {
            const isBreak = p.type === 'break';
            const isLunch = p.type === 'lunch';

            return (
              <div
                key={p.id}
                className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors ${
                  isLunch
                    ? 'bg-amber-50/70 border-amber-200'
                    : isBreak
                    ? 'bg-slate-100/70 border-slate-200'
                    : 'bg-white border-slate-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="w-7 h-7 rounded-lg bg-navy-900 text-white flex items-center justify-center font-mono text-xs font-bold shrink-0">
                    {p.id}
                  </span>

                  <div className="flex items-center gap-2">
                    <input
                      type="time"
                      value={p.startTime}
                      onChange={(e) => handlePeriodTimingChange(p.id, 'startTime', e.target.value)}
                      className="text-xs font-mono font-medium bg-white border border-slate-200 rounded-lg px-2 py-1 text-slate-900"
                    />
                    <span className="text-slate-400 text-xs">to</span>
                    <input
                      type="time"
                      value={p.endTime}
                      onChange={(e) => handlePeriodTimingChange(p.id, 'endTime', e.target.value)}
                      className="text-xs font-mono font-medium bg-white border border-slate-200 rounded-lg px-2 py-1 text-slate-900"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1 text-xs">
                    <button
                      type="button"
                      onClick={() => handlePeriodTypeChange(p.id, 'lecture')}
                      className={`px-2.5 py-1 rounded-lg font-semibold transition-all ${
                        p.type === 'lecture'
                          ? 'bg-blue-600 text-white shadow-2xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      Lecture
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePeriodTypeChange(p.id, 'break')}
                      className={`px-2.5 py-1 rounded-lg font-semibold transition-all flex items-center gap-1 ${
                        p.type === 'break'
                          ? 'bg-slate-800 text-white shadow-2xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      <Coffee className="w-3 h-3" />
                      Break
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePeriodTypeChange(p.id, 'lunch')}
                      className={`px-2.5 py-1 rounded-lg font-semibold transition-all flex items-center gap-1 ${
                        p.type === 'lunch'
                          ? 'bg-amber-600 text-white shadow-2xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      <Utensils className="w-3 h-3" />
                      Lunch
                    </button>
                  </div>

                  {formData.periods.length > 3 && (
                    <button
                      type="button"
                      onClick={() => removePeriod(p.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                      title="Remove period"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </form>
  );
};
