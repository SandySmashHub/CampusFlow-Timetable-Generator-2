import React, { useState, useEffect } from 'react';
import { X, Building2, Users, Clock, ShieldAlert } from 'lucide-react';
import { Room, RoomType, CollegeConfig } from '../../types';
import { slotKey } from '../../engine/scheduler';

interface RoomModalProps {
  room: Room | null;
  config: CollegeConfig;
  isOpen: boolean;
  onClose: () => void;
  onSave: (room: Room) => void;
}

export const RoomModal: React.FC<RoomModalProps> = ({
  room,
  config,
  isOpen,
  onClose,
  onSave,
}) => {
  const [formData, setFormData] = useState<Partial<Room>>({
    id: '',
    name: '',
    type: 'classroom',
    capacity: 70,
    blockedSlots: [],
  });

  useEffect(() => {
    if (room) {
      setFormData({
        ...room,
        blockedSlots: room.blockedSlots ? [...room.blockedSlots] : [],
      });
    } else {
      const nextId = `CR-${Date.now().toString().slice(-3)}`;
      setFormData({
        id: nextId,
        name: 'Lecture Hall 204',
        type: 'classroom',
        capacity: 75,
        blockedSlots: [],
      });
    }
  }, [room]);

  if (!isOpen) return null;

  const blockedSet = new Set(formData.blockedSlots || []);

  const toggleSlot = (day: string, periodId: number) => {
    const k = slotKey(day, periodId);
    const updated = new Set(blockedSet);
    if (updated.has(k)) {
      updated.delete(k);
    } else {
      updated.add(k);
    }
    setFormData({ ...formData, blockedSlots: Array.from(updated) });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.id) return;
    onSave(formData as Room);
    onClose();
  };

  const schedulablePeriods = config.periods.filter((p) => config.schedulablePeriodIds.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden transform transition-all scale-100 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-navy-900 to-navy-800 text-white flex items-start justify-between shrink-0">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-7 h-7 rounded-lg bg-gold-500/20 text-gold-400 flex items-center justify-center font-bold">
                <Building2 className="w-4 h-4" />
              </span>
              <span className="text-xs text-gold-300 font-semibold uppercase tracking-wider">
                Facility Configuration
              </span>
            </div>
            <h3 className="text-lg font-bold text-white">{room ? 'Edit Room / Lab' : 'Add New Space'}</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-navy-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Room Identifier / Code</label>
              <input
                type="text"
                value={formData.id || ''}
                onChange={(e) => setFormData({ ...formData, id: e.target.value.toUpperCase() })}
                placeholder="e.g. CR-101 or LAB-CS1"
                className="w-full text-xs font-mono font-bold bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Display Name</label>
              <input
                type="text"
                value={formData.name || ''}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g. Lecture Hall 101"
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Facility Type</label>
              <select
                value={formData.type || 'classroom'}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as RoomType })}
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
              >
                <option value="classroom">Classroom (Lecture Hall)</option>
                <option value="lab">Computer / Engineering Laboratory</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Seating Capacity</label>
              <input
                type="number"
                min={10}
                max={500}
                value={formData.capacity ?? 70}
                onChange={(e) => setFormData({ ...formData, capacity: Number(e.target.value) })}
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
                required
              />
            </div>
          </div>

          {/* Blocked Slots Matrix */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <h4 className="text-xs font-bold text-navy-950 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-navy-700" />
              <span>Maintenance & Blocked Time Slots</span>
            </h4>
            <p className="text-[11px] text-slate-500">
              Click slots to toggle room maintenance downtime or administrative booking.
            </p>

            <div className="border border-slate-200 rounded-xl overflow-x-auto shadow-2xs">
              <table className="w-full text-center text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-[11px]">
                    <th className="py-2 px-3 text-left">Day</th>
                    {schedulablePeriods.map((p) => (
                      <th key={p.id} className="py-2 px-2 whitespace-nowrap">
                        P{p.id}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {config.workingDays.map((day) => (
                    <tr key={day} className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 text-left font-semibold text-slate-800 text-xs">
                        {day}
                      </td>
                      {schedulablePeriods.map((p) => {
                        const isBlocked = blockedSet.has(slotKey(day, p.id));
                        return (
                          <td key={p.id} className="py-1 px-1">
                            <button
                              type="button"
                              onClick={() => toggleSlot(day, p.id)}
                              className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs transition-transform active:scale-90 ${
                                isBlocked
                                  ? 'bg-rose-100 text-rose-700 border border-rose-300'
                                  : 'bg-slate-50 text-slate-600 border border-slate-200 hover:bg-slate-100'
                              }`}
                            >
                              {isBlocked ? '✕' : '—'}
                            </button>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Footer */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-navy-900 hover:bg-navy-800 rounded-xl shadow-md shadow-navy-900/20 transition-all"
            >
              {room ? 'Update Facility' : 'Register Facility'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
