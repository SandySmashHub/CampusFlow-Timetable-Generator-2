import React, { useState } from 'react';
import {
  Building2,
  Plus,
  Search,
  Edit2,
  Trash2,
  Users,
  Clock,
  Sparkles,
  Layers,
  ShieldAlert,
} from 'lucide-react';
import { Room, CollegeConfig, PlacedSession } from '../../types';
import { RoomModal } from './RoomModal';
import { ConfirmModal } from '../common/ConfirmModal';

interface RoomManagementProps {
  config: CollegeConfig;
  sessions: PlacedSession[];
  onUpdateRooms: (updated: Room[]) => void;
}

export const RoomManagement: React.FC<RoomManagementProps> = ({
  config,
  sessions,
  onUpdateRooms,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [modalRoom, setModalRoom] = useState<Room | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Room | null>(null);

  const filteredRooms = config.rooms.filter((r) => {
    const matchesQuery =
      r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || r.type === filterType;
    return matchesQuery && matchesType;
  });

  const handleSaveRoom = (savedRoom: Room) => {
    let updated: Room[];
    const exists = config.rooms.some((r) => r.id === savedRoom.id);
    if (exists) {
      updated = config.rooms.map((r) => (r.id === savedRoom.id ? savedRoom : r));
    } else {
      updated = [...config.rooms, savedRoom];
    }
    onUpdateRooms(updated);
  };

  const handleDeleteRoom = () => {
    if (!deleteTarget) return;
    const updated = config.rooms.filter((r) => r.id !== deleteTarget.id);
    onUpdateRooms(updated);
    setDeleteTarget(null);
  };

  return (
    <div className="space-y-6 max-w-6xl animate-in fade-in duration-200">
      {/* Header Bar */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-8 h-8 rounded-lg bg-navy-100 text-navy-900 flex items-center justify-center font-bold">
              <Building2 className="w-4 h-4" />
            </span>
            <h2 className="text-lg font-bold text-navy-950">Campus Facilities: Classrooms & Labs</h2>
          </div>
          <p className="text-xs text-slate-500">
            Configure lecture halls and laboratories with student capacity limits and maintenance windows.
          </p>
        </div>

        <button
          onClick={() => {
            setModalRoom(null);
            setIsModalOpen(true);
          }}
          className="px-4 py-2 text-xs font-bold text-white bg-navy-900 hover:bg-navy-800 rounded-xl shadow-md shadow-navy-900/20 active:scale-95 transition-all flex items-center gap-2 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 text-gold-400" />
          <span>Add Space</span>
        </button>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by code or room name..."
            className="w-full text-xs font-medium bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-navy-900 shadow-2xs"
          />
        </div>

        <div className="flex items-center gap-1.5 self-start sm:self-auto">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              filterType === 'all'
                ? 'bg-navy-900 text-white shadow-2xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            All Spaces ({config.rooms.length})
          </button>
          <button
            onClick={() => setFilterType('classroom')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              filterType === 'classroom'
                ? 'bg-navy-900 text-white shadow-2xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            Classrooms ({config.rooms.filter((r) => r.type === 'classroom').length})
          </button>
          <button
            onClick={() => setFilterType('lab')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              filterType === 'lab'
                ? 'bg-navy-900 text-white shadow-2xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            Laboratories ({config.rooms.filter((r) => r.type === 'lab').length})
          </button>
        </div>
      </div>

      {/* Room Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredRooms.map((room) => {
          const roomSessions = sessions.filter((s) => s.roomId === room.id);
          const totalAssignedPeriods = roomSessions.reduce(
            (acc, s) => acc + s.periodIds.length,
            0
          );
          const blockedCount = room.blockedSlots?.length || 0;

          return (
            <div
              key={room.id}
              className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">
                        {room.id}
                      </span>
                      <span
                        className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                          room.type === 'lab'
                            ? 'bg-purple-100 text-purple-800 border border-purple-200'
                            : 'bg-blue-100 text-blue-800 border border-blue-200'
                        }`}
                      >
                        {room.type}
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-navy-950">{room.name}</h3>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        setModalRoom(room);
                        setIsModalOpen(true);
                      }}
                      className="p-1.5 text-slate-400 hover:text-navy-900 hover:bg-slate-100 rounded-lg transition-colors"
                      title="Edit Room"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    {config.rooms.length > 1 && (
                      <button
                        onClick={() => setDeleteTarget(room)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Delete Room"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-500 font-semibold block">Seating Capacity</span>
                    <span className="font-bold text-navy-950 text-sm">{room.capacity} Seats</span>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-500 font-semibold block">Weekly Usage</span>
                    <span className="font-bold text-navy-950 text-sm">{totalAssignedPeriods} Periods</span>
                  </div>
                </div>

                {blockedCount > 0 ? (
                  <div className="text-[11px] text-amber-700 bg-amber-50 p-2 rounded-lg border border-amber-200 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 shrink-0" />
                    <span>{blockedCount} maintenance slot(s) blocked</span>
                  </div>
                ) : (
                  <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    <span>100% available across all working slots</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <RoomModal
        room={modalRoom}
        config={config}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveRoom}
      />

      <ConfirmModal
        isOpen={!!deleteTarget}
        title="Delete Space"
        message={`Are you sure you want to delete ${deleteTarget?.name}? Sessions assigned to this space may become unplaceable.`}
        confirmLabel="Delete"
        isDestructive={true}
        onConfirm={handleDeleteRoom}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
};
