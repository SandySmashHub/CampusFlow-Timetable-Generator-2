import React, { useState, useEffect } from 'react';
import { X, BookOpen, Layers, Clock, Building2, User, Sparkles } from 'lucide-react';
import { Subject, RoomType, Faculty, CollegeConfig } from '../../types';

interface SubjectModalProps {
  subject: Subject | null;
  config: CollegeConfig;
  isOpen: boolean;
  onClose: () => void;
  onSave: (subject: Subject) => void;
}

export const SubjectModal: React.FC<SubjectModalProps> = ({
  subject,
  config,
  isOpen,
  onClose,
  onSave,
}) => {
  const [formData, setFormData] = useState<Partial<Subject>>({
    id: '',
    code: '',
    name: '',
    department: 'CSE',
    lecturesPerWeek: 3,
    practicalsPerWeek: 1,
    practicalPeriods: 2,
    roomType: 'classroom',
    labRoomType: 'lab',
    color: 'emerald',
    preferredDays: [],
    preferredPeriods: [],
  });

  useEffect(() => {
    if (subject) {
      setFormData({ ...subject });
    } else {
      const nextId = `SUBJ-${Date.now().toString().slice(-4)}`;
      setFormData({
        id: nextId,
        code: 'CS407',
        name: 'New Course',
        department: config.department || 'CSE',
        lecturesPerWeek: 3,
        practicalsPerWeek: 0,
        practicalPeriods: 0,
        roomType: 'classroom',
        labRoomType: 'lab',
        color: 'emerald',
        preferredDays: [],
        preferredPeriods: [],
      });
    }
  }, [subject, config]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.code) return;
    onSave(formData as Subject);
    onClose();
  };

  const colors = [
    { id: 'emerald', label: 'Emerald' },
    { id: 'indigo', label: 'Indigo' },
    { id: 'amber', label: 'Amber' },
    { id: 'cyan', label: 'Cyan' },
    { id: 'rose', label: 'Rose' },
    { id: 'violet', label: 'Violet' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden transform transition-all scale-100 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-navy-900 to-navy-800 text-white flex items-start justify-between shrink-0">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-7 h-7 rounded-lg bg-gold-500/20 text-gold-400 flex items-center justify-center font-bold">
                <BookOpen className="w-4 h-4" />
              </span>
              <span className="text-xs text-gold-300 font-semibold uppercase tracking-wider">
                Curriculum Definition
              </span>
            </div>
            <h3 className="text-lg font-bold text-white">
              {subject ? 'Edit Subject' : 'Add New Subject'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-navy-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Subject Code</label>
              <input
                type="text"
                value={formData.code || ''}
                onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                placeholder="e.g. CS401"
                className="w-full text-xs font-mono font-bold bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Subject Name</label>
              <input
                type="text"
                value={formData.name || ''}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g. Operating Systems"
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Lectures per Week</label>
              <input
                type="number"
                min={0}
                max={10}
                value={formData.lecturesPerWeek ?? 3}
                onChange={(e) =>
                  setFormData({ ...formData, lecturesPerWeek: Number(e.target.value) })
                }
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">
                Practicals (Lab Blocks) / Wk
              </label>
              <input
                type="number"
                min={0}
                max={5}
                value={formData.practicalsPerWeek ?? 0}
                onChange={(e) =>
                  setFormData({ ...formData, practicalsPerWeek: Number(e.target.value) })
                }
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
              />
            </div>

            {(formData.practicalsPerWeek ?? 0) > 0 && (
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700">
                  Consecutive Periods / Practical
                </label>
                <input
                  type="number"
                  min={1}
                  max={4}
                  value={formData.practicalPeriods ?? 2}
                  onChange={(e) =>
                    setFormData({ ...formData, practicalPeriods: Number(e.target.value) })
                  }
                  className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
                />
              </div>
            )}

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Lecture Room Type</label>
              <select
                value={formData.roomType || 'classroom'}
                onChange={(e) => setFormData({ ...formData, roomType: e.target.value as RoomType })}
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
              >
                <option value="classroom">Classroom (Lecture Hall)</option>
                <option value="lab">Laboratory</option>
              </select>
            </div>

            {(formData.practicalsPerWeek ?? 0) > 0 && (
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700">Practical Lab Type</label>
                <select
                  value={formData.labRoomType || 'lab'}
                  onChange={(e) =>
                    setFormData({ ...formData, labRoomType: e.target.value as RoomType })
                  }
                  className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
                >
                  <option value="lab">Computer / Hardware Laboratory</option>
                  <option value="classroom">Classroom</option>
                </select>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Badge Color</label>
              <select
                value={formData.color || 'emerald'}
                onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
              >
                {colors.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Footer inside form */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-navy-900 hover:bg-navy-800 rounded-xl shadow-md shadow-navy-900/20 transition-all"
            >
              {subject ? 'Update Subject' : 'Add Subject'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
