import React, { useState } from 'react';
import {
  BookOpen,
  Plus,
  Search,
  Edit2,
  Trash2,
  Layers,
  Clock,
  Building2,
  User,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { Subject, CollegeConfig, SubjectAssignment } from '../../types';
import { SubjectModal } from './SubjectModal';
import { ConfirmModal } from '../common/ConfirmModal';

interface SubjectManagementProps {
  config: CollegeConfig;
  onUpdateSubjects: (updatedSubjects: Subject[], updatedAssignments: SubjectAssignment[]) => void;
}

export const SubjectManagement: React.FC<SubjectManagementProps> = ({
  config,
  onUpdateSubjects,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [modalSubject, setModalSubject] = useState<Subject | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Subject | null>(null);

  const filteredSubjects = config.subjects.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSaveSubject = (savedSubject: Subject) => {
    let updatedSubjects: Subject[];
    let updatedAssignments = [...config.assignments];

    const exists = config.subjects.some((s) => s.id === savedSubject.id);
    if (exists) {
      updatedSubjects = config.subjects.map((s) => (s.id === savedSubject.id ? savedSubject : s));
    } else {
      updatedSubjects = [...config.subjects, savedSubject];
      // Create default assignments for each division
      const defaultFaculty = config.faculty[0]?.id || 'FAC-01';
      for (const div of config.divisions) {
        updatedAssignments.push({
          divisionId: div.id,
          subjectId: savedSubject.id,
          facultyLectureId: defaultFaculty,
          facultyPracticalId: savedSubject.practicalsPerWeek > 0 ? defaultFaculty : null,
        });
      }
    }

    onUpdateSubjects(updatedSubjects, updatedAssignments);
  };

  const handleDeleteSubject = () => {
    if (!deleteTarget) return;
    const updatedSubjects = config.subjects.filter((s) => s.id !== deleteTarget.id);
    const updatedAssignments = config.assignments.filter((a) => a.subjectId !== deleteTarget.id);
    onUpdateSubjects(updatedSubjects, updatedAssignments);
    setDeleteTarget(null);
  };

  const handleAssignmentChange = (
    divisionId: string,
    subjectId: string,
    type: 'lecture' | 'practical',
    facultyId: string
  ) => {
    const updatedAssignments = config.assignments.map((asgn) => {
      if (asgn.divisionId === divisionId && asgn.subjectId === subjectId) {
        return {
          ...asgn,
          [type === 'lecture' ? 'facultyLectureId' : 'facultyPracticalId']: facultyId || null,
        };
      }
      return asgn;
    });
    onUpdateSubjects(config.subjects, updatedAssignments);
  };

  return (
    <div className="space-y-6 max-w-6xl animate-in fade-in duration-200">
      {/* Header Bar */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-8 h-8 rounded-lg bg-navy-100 text-navy-900 flex items-center justify-center font-bold">
              <BookOpen className="w-4 h-4" />
            </span>
            <h2 className="text-lg font-bold text-navy-950">Subject Curriculum & Faculty Allocation</h2>
          </div>
          <p className="text-xs text-slate-500">
            Define curriculum requirements, practical lab blocks, and division-wise faculty assignments.
          </p>
        </div>

        <button
          onClick={() => {
            setModalSubject(null);
            setIsModalOpen(true);
          }}
          className="px-4 py-2 text-xs font-bold text-white bg-navy-900 hover:bg-navy-800 rounded-xl shadow-md shadow-navy-900/20 active:scale-95 transition-all flex items-center gap-2 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 text-gold-400" />
          <span>Add New Subject</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by code or subject name..."
            className="w-full text-xs font-medium bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-navy-900 shadow-2xs"
          />
        </div>
        <span className="text-xs text-slate-500 font-medium">
          Showing {filteredSubjects.length} of {config.subjects.length} subjects
        </span>
      </div>

      {/* Cards List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredSubjects.map((subj) => {
          return (
            <div
              key={subj.id}
              className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs hover:shadow-md transition-all space-y-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-navy-100 text-navy-900 border border-navy-200">
                      {subj.code}
                    </span>
                    <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      {subj.department || 'CSE'}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-navy-950">{subj.name}</h3>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      setModalSubject(subj);
                      setIsModalOpen(true);
                    }}
                    className="p-1.5 text-slate-400 hover:text-navy-900 hover:bg-slate-100 rounded-lg transition-colors"
                    title="Edit Subject"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setDeleteTarget(subj)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                    title="Delete Subject"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Requirement Pills */}
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 font-semibold border border-blue-200/60">
                  {subj.lecturesPerWeek} Lecture(s) / wk
                </span>
                {subj.practicalsPerWeek > 0 ? (
                  <span className="px-2.5 py-1 rounded-lg bg-purple-50 text-purple-800 font-semibold border border-purple-200/60">
                    {subj.practicalsPerWeek} Lab Block ({subj.practicalPeriods} consecutive periods)
                  </span>
                ) : (
                  <span className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-600 font-medium">
                    No Practicals
                  </span>
                )}
                <span className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 font-medium">
                  Room: {subj.roomType}
                </span>
              </div>

              {/* Division Faculty Assignments */}
              <div className="pt-3 border-t border-slate-100 space-y-2">
                <h4 className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  Division Faculty Assignments:
                </h4>
                <div className="space-y-2">
                  {config.divisions.map((div) => {
                    const asgn = config.assignments.find(
                      (a) => a.divisionId === div.id && a.subjectId === subj.id
                    );

                    return (
                      <div
                        key={div.id}
                        className="p-2.5 rounded-xl bg-slate-50/70 border border-slate-200/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                      >
                        <span className="font-semibold text-slate-800 shrink-0 w-28">
                          {div.name}:
                        </span>

                        <div className="flex flex-wrap items-center gap-2 flex-1">
                          {/* Lecture Faculty */}
                          <div className="flex items-center gap-1">
                            <span className="text-[10px] text-slate-500">Lec:</span>
                            <select
                              value={asgn?.facultyLectureId || ''}
                              onChange={(e) =>
                                handleAssignmentChange(div.id, subj.id, 'lecture', e.target.value)
                              }
                              className="text-xs bg-white border border-slate-200 rounded-lg px-2 py-1 text-slate-800 font-medium"
                            >
                              {config.faculty.map((f) => (
                                <option key={f.id} value={f.id}>
                                  {f.name}
                                </option>
                              ))}
                            </select>
                          </div>

                          {/* Practical Faculty */}
                          {subj.practicalsPerWeek > 0 && (
                            <div className="flex items-center gap-1">
                              <span className="text-[10px] text-purple-600 font-semibold">Lab:</span>
                              <select
                                value={asgn?.facultyPracticalId || ''}
                                onChange={(e) =>
                                  handleAssignmentChange(div.id, subj.id, 'practical', e.target.value)
                                }
                                className="text-xs bg-white border border-slate-200 rounded-lg px-2 py-1 text-slate-800 font-medium"
                              >
                                {config.faculty.map((f) => (
                                  <option key={f.id} value={f.id}>
                                    {f.name}
                                  </option>
                                ))}
                              </select>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <SubjectModal
        subject={modalSubject}
        config={config}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveSubject}
      />

      <ConfirmModal
        isOpen={!!deleteTarget}
        title="Delete Subject"
        message={`Are you sure you want to delete ${deleteTarget?.code} (${deleteTarget?.name})? All assigned sessions will be removed.`}
        confirmLabel="Delete"
        isDestructive={true}
        onConfirm={handleDeleteSubject}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
};
