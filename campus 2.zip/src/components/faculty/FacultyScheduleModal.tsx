import React from 'react';
import { X, Calendar, User, Clock, Building2, GraduationCap, Printer } from 'lucide-react';
import { Faculty, PlacedSession, CollegeConfig } from '../../types';

interface FacultyScheduleModalProps {
  faculty: Faculty | null;
  sessions: PlacedSession[];
  config: CollegeConfig;
  isOpen: boolean;
  onClose: () => void;
}

export const FacultyScheduleModal: React.FC<FacultyScheduleModalProps> = ({
  faculty,
  sessions,
  config,
  isOpen,
  onClose,
}) => {
  if (!isOpen || !faculty) return null;

  const facSessions = sessions.filter((s) => s.facultyId === faculty.id);
  const totalAssignedPeriods = facSessions.reduce((acc, s) => acc + s.periodIds.length, 0);

  const cellMap = new Map<string, PlacedSession>();
  for (const s of facSessions) {
    for (const pid of s.periodIds) {
      cellMap.set(`${s.day}:${pid}`, s);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden transform transition-all scale-100 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-navy-900 to-navy-800 text-white flex items-start justify-between shrink-0">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs px-2 py-0.5 rounded bg-gold-400 text-navy-950 font-bold">
                {faculty.department || 'CSE'}
              </span>
              <span className="text-xs text-slate-300">
                Weekly Load: {totalAssignedPeriods} / {faculty.maxPeriodsPerWeek} periods
              </span>
            </div>
            <h3 className="text-lg font-bold text-white">{faculty.name}'s Weekly Timetable</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-navy-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Timetable Table Body */}
        <div className="p-6 overflow-y-auto flex-1">
          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-navy-950 text-white text-[11px] uppercase tracking-wider">
                  <th className="py-2.5 px-3 border-r border-navy-800 w-28">Period</th>
                  {config.workingDays.map((d) => (
                    <th key={d} className="py-2.5 px-3 border-r border-navy-800 last:border-r-0 text-center">
                      {d}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {config.periods.map((p) => {
                  if (p.type !== 'lecture') {
                    return (
                      <tr key={p.id} className="bg-slate-50/80 text-slate-500 font-semibold text-[10px]">
                        <td className="py-1.5 px-3 border-r border-slate-200">
                          {p.type === 'lunch' ? 'Lunch' : 'Break'}
                        </td>
                        <td colSpan={config.workingDays.length} className="text-center py-1.5 text-slate-400">
                          {p.startTime} – {p.endTime}
                        </td>
                      </tr>
                    );
                  }

                  return (
                    <tr key={p.id} className="hover:bg-slate-50/50">
                      <td className="py-2.5 px-3 border-r border-slate-200 font-semibold text-slate-700 bg-slate-50/50">
                        <div>P{p.id}</div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {p.startTime}–{p.endTime}
                        </div>
                      </td>
                      {config.workingDays.map((day) => {
                        const session = cellMap.get(`${day}:${p.id}`);
                        const room = session
                          ? config.rooms.find((r) => r.id === session.roomId)
                          : null;
                        const division = session
                          ? config.divisions.find((d) => d.id === session.divisionId)
                          : null;

                        return (
                          <td
                            key={day}
                            className="p-1.5 border-r border-slate-200 last:border-r-0 align-top min-w-[130px]"
                          >
                            {session ? (
                              <div
                                className={`p-2 rounded-lg border text-[11px] leading-tight ${
                                  session.sessionType === 'practical'
                                    ? 'bg-purple-50 border-purple-200 text-purple-950'
                                    : 'bg-blue-50 border-blue-200 text-blue-950'
                                }`}
                              >
                                <div className="font-bold">{session.subjectCode}</div>
                                <div className="text-[10px] text-slate-600 truncate">
                                  {session.subjectName}
                                </div>
                                <div className="mt-1 flex items-center justify-between text-[10px] font-semibold text-slate-700">
                                  <span>{division?.name || session.divisionId}</span>
                                  <span>{room?.name || session.roomId}</span>
                                </div>
                              </div>
                            ) : (
                              <div className="h-12 border border-dashed border-slate-100 rounded-lg flex items-center justify-center text-slate-300 text-[10px]">
                                Free
                              </div>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-4 flex items-center justify-end gap-3 border-t border-slate-100 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
