import React, { useState, useEffect } from 'react';
import { X, User, Clock, ShieldAlert, Check, Ban } from 'lucide-react';
import { Faculty, CollegeConfig } from '../../types';
import { slotKey } from '../../engine/scheduler';

interface FacultyModalProps {
  faculty: Faculty | null;
  config: CollegeConfig;
  isOpen: boolean;
  onClose: () => void;
  onSave: (faculty: Faculty) => void;
}

export const FacultyModal: React.FC<FacultyModalProps> = ({
  faculty,
  config,
  isOpen,
  onClose,
  onSave,
}) => {
  const [formData, setFormData] = useState<Partial<Faculty>>({
    id: '',
    name: '',
    email: '',
    department: 'CSE',
    maxPeriodsPerDay: 4,
    maxPeriodsPerWeek: 16,
    blockedSlots: [],
  });

  useEffect(() => {
    if (faculty) {
      setFormData({
        ...faculty,
        blockedSlots: faculty.blockedSlots ? [...faculty.blockedSlots] : [],
      });
    } else {
      const nextId = `FAC-${Date.now().toString().slice(-4)}`;
      setFormData({
        id: nextId,
        name: 'Prof. New Faculty',
        email: 'faculty@campus.edu',
        department: config.department || 'CSE',
        maxPeriodsPerDay: 4,
        maxPeriodsPerWeek: 16,
        blockedSlots: [],
      });
    }
  }, [faculty, config]);

  if (!isOpen) return null;

  const blockedSet = new Set(formData.blockedSlots || []);

  const toggleSlot = (day: string, periodId: number) => {
    const k = slotKey(day, periodId);
    const updated = new Set(blockedSet);
    if (updated.has(k)) {
      updated.delete(k);
    } else {
      updated.add(k);
    }
    setFormData({ ...formData, blockedSlots: Array.from(updated) });
  };

  const blockDay = (day: string) => {
    const updated = new Set(blockedSet);
    for (const pid of config.schedulablePeriodIds) {
      updated.add(slotKey(day, pid));
    }
    setFormData({ ...formData, blockedSlots: Array.from(updated) });
  };

  const clearAllBlocked = () => {
    setFormData({ ...formData, blockedSlots: [] });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;
    onSave(formData as Faculty);
    onClose();
  };

  const schedulablePeriods = config.periods.filter((p) => config.schedulablePeriodIds.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden transform transition-all scale-100 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-navy-900 to-navy-800 text-white flex items-start justify-between shrink-0">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-7 h-7 rounded-lg bg-gold-500/20 text-gold-400 flex items-center justify-center font-bold">
                <User className="w-4 h-4" />
              </span>
              <span className="text-xs text-gold-300 font-semibold uppercase tracking-wider">
                Faculty Profile & Availability
              </span>
            </div>
            <h3 className="text-lg font-bold text-white">
              {faculty ? `Edit ${faculty.name}` : 'Register Faculty Member'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-navy-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto flex-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Full Name</label>
              <input
                type="text"
                value={formData.name || ''}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g. Dr. Jane Doe"
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Email Address</label>
              <input
                type="email"
                value={formData.email || ''}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="j.doe@campus.edu"
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Max Periods / Day</label>
              <input
                type="number"
                min={1}
                max={8}
                value={formData.maxPeriodsPerDay ?? 4}
                onChange={(e) =>
                  setFormData({ ...formData, maxPeriodsPerDay: Number(e.target.value) })
                }
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Max Periods / Week</label>
              <input
                type="number"
                min={1}
                max={30}
                value={formData.maxPeriodsPerWeek ?? 16}
                onChange={(e) =>
                  setFormData({ ...formData, maxPeriodsPerWeek: Number(e.target.value) })
                }
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy-900"
                required
              />
            </div>
          </div>

          {/* Interactive Availability Matrix */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-navy-950 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-navy-700" />
                  <span>Availability Matrix (Click slot to toggle)</span>
                </h4>
                <p className="text-[11px] text-slate-500">
                  Green = Available for classes. Red = Blocked (Research day, admin duty, leave).
                </p>
              </div>

              <button
                type="button"
                onClick={clearAllBlocked}
                className="text-[11px] font-semibold text-slate-600 hover:text-navy-900 px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 transition-colors"
              >
                Clear All Restrictions
              </button>
            </div>

            <div className="border border-slate-200 rounded-xl overflow-x-auto shadow-2xs">
              <table className="w-full text-center text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-[11px]">
                    <th className="py-2 px-3 text-left">Day</th>
                    {schedulablePeriods.map((p) => (
                      <th key={p.id} className="py-2 px-2 whitespace-nowrap">
                        P{p.id}
                      </th>
                    ))}
                    <th className="py-2 px-2 text-right pr-3">Quick</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {config.workingDays.map((day) => (
                    <tr key={day} className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 text-left font-semibold text-slate-800 text-xs">
                        {day}
                      </td>
                      {schedulablePeriods.map((p) => {
                        const isBlocked = blockedSet.has(slotKey(day, p.id));
                        return (
                          <td key={p.id} className="py-1 px-1">
                            <button
                              type="button"
                              onClick={() => toggleSlot(day, p.id)}
                              className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs transition-transform active:scale-90 ${
                                isBlocked
                                  ? 'bg-rose-100 text-rose-700 border border-rose-300 shadow-2xs'
                                  : 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                              }`}
                              title={
                                isBlocked
                                  ? `Blocked on ${day} Period ${p.id}`
                                  : `Available on ${day} Period ${p.id}`
                              }
                            >
                              {isBlocked ? '✕' : '✓'}
                            </button>
                          </td>
                        );
                      })}
                      <td className="py-1 px-2 text-right pr-3">
                        <button
                          type="button"
                          onClick={() => blockDay(day)}
                          className="text-[10px] font-medium text-slate-500 hover:text-rose-700 px-1.5 py-0.5 rounded hover:bg-rose-50"
                        >
                          Block Day
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Footer */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-navy-900 hover:bg-navy-800 rounded-xl shadow-md shadow-navy-900/20 transition-all"
            >
              {faculty ? 'Update Faculty' : 'Register Faculty'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
