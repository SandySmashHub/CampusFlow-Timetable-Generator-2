import React, { useState } from 'react';
import {
  Users,
  Plus,
  Search,
  Edit2,
  Trash2,
  Calendar,
  Clock,
  ShieldCheck,
  ShieldAlert,
  Mail,
  BookOpen,
} from 'lucide-react';
import { Faculty, CollegeConfig, PlacedSession } from '../../types';
import { FacultyModal } from './FacultyModal';
import { FacultyScheduleModal } from './FacultyScheduleModal';
import { ConfirmModal } from '../common/ConfirmModal';

interface FacultyManagementProps {
  config: CollegeConfig;
  sessions: PlacedSession[];
  onUpdateFaculty: (updated: Faculty[]) => void;
}

export const FacultyManagement: React.FC<FacultyManagementProps> = ({
  config,
  sessions,
  onUpdateFaculty,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [modalFaculty, setModalFaculty] = useState<Faculty | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [scheduleModalFaculty, setScheduleModalFaculty] = useState<Faculty | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Faculty | null>(null);

  const filteredFaculty = config.faculty.filter(
    (f) =>
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (f.department && f.department.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (f.email && f.email.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleSaveFaculty = (savedFaculty: Faculty) => {
    let updated: Faculty[];
    const exists = config.faculty.some((f) => f.id === savedFaculty.id);
    if (exists) {
      updated = config.faculty.map((f) => (f.id === savedFaculty.id ? savedFaculty : f));
    } else {
      updated = [...config.faculty, savedFaculty];
    }
    onUpdateFaculty(updated);
  };

  const handleDeleteFaculty = () => {
    if (!deleteTarget) return;
    const updated = config.faculty.filter((f) => f.id !== deleteTarget.id);
    onUpdateFaculty(updated);
    setDeleteTarget(null);
  };

  return (
    <div className="space-y-6 max-w-6xl animate-in fade-in duration-200">
      {/* Header Bar */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-8 h-8 rounded-lg bg-navy-100 text-navy-900 flex items-center justify-center font-bold">
              <Users className="w-4 h-4" />
            </span>
            <h2 className="text-lg font-bold text-navy-950">Faculty Roster & Availability</h2>
          </div>
          <p className="text-xs text-slate-500">
            Manage teaching loads, restricted time slots, and view individual professor timetables.
          </p>
        </div>

        <button
          onClick={() => {
            setModalFaculty(null);
            setIsModalOpen(true);
          }}
          className="px-4 py-2 text-xs font-bold text-white bg-navy-900 hover:bg-navy-800 rounded-xl shadow-md shadow-navy-900/20 active:scale-95 transition-all flex items-center gap-2 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 text-gold-400" />
          <span>Add Faculty Member</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search faculty by name or email..."
            className="w-full text-xs font-medium bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-navy-900 shadow-2xs"
          />
        </div>
        <span className="text-xs text-slate-500 font-medium">
          Showing {filteredFaculty.length} of {config.faculty.length} faculty
        </span>
      </div>

      {/* Faculty Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredFaculty.map((fac) => {
          const assignedSessions = sessions.filter((s) => s.facultyId === fac.id);
          const totalAssignedPeriods = assignedSessions.reduce(
            (acc, s) => acc + s.periodIds.length,
            0
          );
          const blockedCount = fac.blockedSlots?.length || 0;

          // Find assigned subjects
          const assignedSubjIds = Array.from(
            new Set(
              config.assignments
                .filter(
                  (a) => a.facultyLectureId === fac.id || a.facultyPracticalId === fac.id
                )
                .map((a) => a.subjectId)
            )
          );
          const assignedSubjects = config.subjects.filter((s) => assignedSubjIds.includes(s.id));

          return (
            <div
              key={fac.id}
              className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-bold text-navy-950">{fac.name}</h3>
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-0.5">
                      <Mail className="w-3 h-3 text-slate-400" />
                      <span>{fac.email || 'faculty@campus.edu'}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        setModalFaculty(fac);
                        setIsModalOpen(true);
                      }}
                      className="p-1.5 text-slate-400 hover:text-navy-900 hover:bg-slate-100 rounded-lg transition-colors"
                      title="Edit Faculty & Availability"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    {config.faculty.length > 1 && (
                      <button
                        onClick={() => setDeleteTarget(fac)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Delete Faculty"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Workload Progress */}
                <div className="space-y-1.5 bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-600">Weekly Teaching Load</span>
                    <span className="font-mono font-bold text-navy-900">
                      {totalAssignedPeriods} / {fac.maxPeriodsPerWeek} p
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        totalAssignedPeriods > fac.maxPeriodsPerWeek
                          ? 'bg-rose-500'
                          : totalAssignedPeriods === fac.maxPeriodsPerWeek
                          ? 'bg-amber-500'
                          : 'bg-navy-900'
                      }`}
                      style={{
                        width: `${Math.min(
                          100,
                          Math.round((totalAssignedPeriods / fac.maxPeriodsPerWeek) * 100)
                        )}%`,
                      }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-0.5">
                    <span>Max {fac.maxPeriodsPerDay} p/day</span>
                    <span>
                      {blockedCount > 0 ? (
                        <span className="text-amber-700 font-medium">
                          {blockedCount} slot(s) blocked
                        </span>
                      ) : (
                        <span className="text-emerald-700 font-medium">Full availability</span>
                      )}
                    </span>
                  </div>
                </div>

                {/* Assigned Subjects */}
                <div className="space-y-1.5">
                  <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                    <BookOpen className="w-3 h-3" />
                    <span>Assigned Subjects</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {assignedSubjects.length > 0 ? (
                      assignedSubjects.map((s) => (
                        <span
                          key={s.id}
                          className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-200"
                        >
                          {s.code}
                        </span>
                      ))
                    ) : (
                      <span className="text-xs text-slate-400 italic">No subjects assigned</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Button: View Weekly Schedule */}
              <button
                type="button"
                onClick={() => setScheduleModalFaculty(fac)}
                className="w-full mt-2 py-2 text-xs font-semibold text-navy-900 bg-navy-50 hover:bg-navy-100 border border-navy-200 rounded-xl transition-colors flex items-center justify-center gap-1.5"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>View Weekly Timetable</span>
              </button>
            </div>
          );
        })}
      </div>

      <FacultyModal
        faculty={modalFaculty}
        config={config}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveFaculty}
      />

      <FacultyScheduleModal
        faculty={scheduleModalFaculty}
        sessions={sessions}
        config={config}
        isOpen={!!scheduleModalFaculty}
        onClose={() => setScheduleModalFaculty(null)}
      />

      <ConfirmModal
        isOpen={!!deleteTarget}
        title="Delete Faculty Member"
        message={`Are you sure you want to delete ${deleteTarget?.name}? Any assigned classes will lose this faculty assignment.`}
        confirmLabel="Delete"
        isDestructive={true}
        onConfirm={handleDeleteFaculty}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
};
