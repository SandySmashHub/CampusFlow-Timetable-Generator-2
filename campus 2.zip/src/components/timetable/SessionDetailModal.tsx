import React from 'react';
import {
  X,
  Calendar,
  Clock,
  MapPin,
  User,
  GraduationCap,
  Layers,
  ArrowRightLeft,
  CheckCircle2,
  Users,
} from 'lucide-react';
import { CollegeConfig, PlacedSession } from '../../types';

interface SessionDetailModalProps {
  session: PlacedSession | null;
  config: CollegeConfig;
  isOpen: boolean;
  onClose: () => void;
  onOpenMoveModal: (session: PlacedSession) => void;
}

export const SessionDetailModal: React.FC<SessionDetailModalProps> = ({
  session,
  config,
  isOpen,
  onClose,
  onOpenMoveModal,
}) => {
  if (!isOpen || !session) return null;

  const subject = config.subjects.find((s) => s.id === session.subjectId);
  const faculty = config.faculty.find((f) => f.id === session.facultyId);
  const room = config.rooms.find((r) => r.id === session.roomId);
  const division = config.divisions.find((d) => d.id === session.divisionId);

  const periodLabels = session.periodIds
    .map((pid) => {
      const p = config.periods.find((x) => x.id === pid);
      return p ? `Period ${pid} (${p.startTime}–${p.endTime})` : `Period ${pid}`;
    })
    .join(', ');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden transform transition-all scale-100">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-navy-900 to-navy-800 text-white flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="font-mono text-xs px-2 py-0.5 rounded bg-gold-400 text-navy-950 font-bold">
                {session.subjectCode || subject?.code || 'SUBJ'}
              </span>
              <span
                className={`text-xs px-2 py-0.5 rounded-full font-semibold uppercase ${
                  session.sessionType === 'practical'
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-400/30'
                    : 'bg-blue-500/20 text-blue-300 border border-blue-400/30'
                }`}
              >
                {session.sessionType === 'practical'
                  ? `Practical (${session.periodIds.length} consecutive periods)`
                  : 'Lecture (1 period)'}
              </span>
            </div>
            <h3 className="text-lg font-bold text-white">{session.subjectName}</h3>
            <p className="text-xs text-slate-300 mt-0.5">
              Division: {division?.name || session.divisionId} ({division?.strength || 60} students)
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-navy-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Details */}
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Timing */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <Clock className="w-3.5 h-3.5 text-navy-700" />
                <span>Day & Time</span>
              </div>
              <p className="text-sm font-bold text-navy-950">{session.day}</p>
              <p className="text-xs text-slate-600">{periodLabels}</p>
            </div>

            {/* Room */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <MapPin className="w-3.5 h-3.5 text-navy-700" />
                <span>Facility / Location</span>
              </div>
              <p className="text-sm font-bold text-navy-950">{room?.name || session.roomId}</p>
              <p className="text-xs text-slate-600">
                Type: {room?.type.toUpperCase()} • Capacity: {room?.capacity} seats
              </p>
            </div>

            {/* Faculty */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <User className="w-3.5 h-3.5 text-navy-700" />
                <span>Assigned Faculty</span>
              </div>
              <p className="text-sm font-bold text-navy-950">{faculty?.name || session.facultyId}</p>
              <p className="text-xs text-slate-600">
                {faculty?.department || 'CSE'} {faculty?.email && `• ${faculty.email}`}
              </p>
            </div>

            {/* Class / Batch */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <Users className="w-3.5 h-3.5 text-navy-700" />
                <span>Batch & Capacity</span>
              </div>
              <p className="text-sm font-bold text-navy-950">{division?.name || session.divisionId}</p>
              <p className="text-xs text-slate-600">
                {session.sessionType === 'practical'
                  ? `Lab Batch: ~${division?.practicalBatchSize || Math.ceil((division?.strength || 60) / 2)} students`
                  : `Full Class: ${division?.strength || 60} students`}
              </p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center gap-2.5 text-xs text-emerald-800">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              All hard constraints satisfied: No faculty clash, no room clash, capacity adequate.
            </span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="bg-slate-50 px-6 py-4 flex items-center justify-between border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors shadow-sm"
          >
            Close
          </button>

          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenMoveModal(session);
            }}
            className="px-4 py-2 text-xs font-bold text-white bg-navy-900 hover:bg-navy-800 rounded-xl shadow-md shadow-navy-900/20 transition-all flex items-center gap-2"
          >
            <ArrowRightLeft className="w-3.5 h-3.5 text-gold-400" />
            <span>Move / Reschedule Session</span>
          </button>
        </div>
      </div>
    </div>
  );
};
