import React, { useState } from 'react';
import {
  Calendar,
  Filter,
  User,
  Building2,
  GraduationCap,
  Sparkles,
  Undo2,
  Clock,
  Printer,
  FileSpreadsheet,
  Coffee,
  Utensils,
  Maximize2,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import {
  CollegeConfig,
  PlacedSession,
  ViewMode,
  Subject,
  Faculty,
  Room,
  Division,
  EditProposal,
} from '../../types';
import { SessionDetailModal } from './SessionDetailModal';
import { MoveSessionModal } from './MoveSessionModal';
import { exportTimetableToCSV } from '../../engine/exportUtils';

interface TimetableGridProps {
  config: CollegeConfig;
  sessions: PlacedSession[];
  canUndo: boolean;
  onUndo: () => void;
  onApplyMove: (sessions: PlacedSession[], proposal: EditProposal) => void;
  onRegenerate: () => void;
  isGenerating: boolean;
}

export const TimetableGrid: React.FC<TimetableGridProps> = ({
  config,
  sessions,
  canUndo,
  onUndo,
  onApplyMove,
  onRegenerate,
  isGenerating,
}) => {
  // View mode: 'class' | 'faculty' | 'room'
  const [viewMode, setViewMode] = useState<ViewMode>('class');

  // Selected filters
  const [selectedDivisionId, setSelectedDivisionId] = useState<string>(
    config.divisions[0]?.id || ''
  );
  const [selectedFacultyId, setSelectedFacultyId] = useState<string>(
    config.faculty[0]?.id || ''
  );
  const [selectedRoomId, setSelectedRoomId] = useState<string>(
    config.rooms[0]?.id || ''
  );
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState<string>('all');

  // Modals state
  const [inspectSession, setInspectSession] = useState<PlacedSession | null>(null);
  const [moveSession, setMoveSession] = useState<PlacedSession | null>(null);

  // Subject color mapping
  const subjectColorMap: Record<string, { bg: string; border: string; text: string; badge: string }> = {
    emerald: {
      bg: 'bg-emerald-50/90 hover:bg-emerald-100/90',
      border: 'border-emerald-300',
      text: 'text-emerald-950',
      badge: 'bg-emerald-600 text-white',
    },
    indigo: {
      bg: 'bg-indigo-50/90 hover:bg-indigo-100/90',
      border: 'border-indigo-300',
      text: 'text-indigo-950',
      badge: 'bg-indigo-600 text-white',
    },
    amber: {
      bg: 'bg-amber-50/90 hover:bg-amber-100/90',
      border: 'border-amber-300',
      text: 'text-amber-950',
      badge: 'bg-amber-600 text-white',
    },
    cyan: {
      bg: 'bg-cyan-50/90 hover:bg-cyan-100/90',
      border: 'border-cyan-300',
      text: 'text-cyan-950',
      badge: 'bg-cyan-600 text-white',
    },
    rose: {
      bg: 'bg-rose-50/90 hover:bg-rose-100/90',
      border: 'border-rose-300',
      text: 'text-rose-950',
      badge: 'bg-rose-600 text-white',
    },
    violet: {
      bg: 'bg-violet-50/90 hover:bg-violet-100/90',
      border: 'border-violet-300',
      text: 'text-violet-950',
      badge: 'bg-violet-600 text-white',
    },
  };

  const getSubjectColorStyle = (subjectId: string) => {
    const subj = config.subjects.find((s) => s.id === subjectId);
    const colorKey = subj?.color || 'indigo';
    return (
      subjectColorMap[colorKey] || {
        bg: 'bg-blue-50/90 hover:bg-blue-100/90',
        border: 'border-blue-300',
        text: 'text-blue-950',
        badge: 'bg-blue-600 text-white',
      }
    );
  };

  // Filter sessions based on current viewMode and selected filter
  const visibleSessions = sessions.filter((s) => {
    if (selectedSubjectFilter !== 'all' && s.subjectId !== selectedSubjectFilter) {
      return false;
    }

    if (viewMode === 'class') {
      return s.divisionId === selectedDivisionId;
    }
    if (viewMode === 'faculty') {
      return s.facultyId === selectedFacultyId;
    }
    if (viewMode === 'room') {
      return s.roomId === selectedRoomId;
    }
    return true;
  });

  // Fast cell lookup: (day, periodId) -> PlacedSession
  const sessionCellMap = new Map<string, PlacedSession>();
  for (const s of visibleSessions) {
    for (const pid of s.periodIds) {
      sessionCellMap.set(`${s.day}:${pid}`, s);
    }
  }

  // Active view header title
  const currentViewTitle = () => {
    if (viewMode === 'class') {
      const div = config.divisions.find((d) => d.id === selectedDivisionId);
      return `Class Timetable — ${div?.name || selectedDivisionId} (${div?.strength || 60} students)`;
    }
    if (viewMode === 'faculty') {
      const fac = config.faculty.find((f) => f.id === selectedFacultyId);
      return `Faculty Schedule — ${fac?.name || selectedFacultyId} (${fac?.department || 'CSE'})`;
    }
    const rm = config.rooms.find((r) => r.id === selectedRoomId);
    return `Room Allocation — ${rm?.name || selectedRoomId} (${rm?.type.toUpperCase()} • Cap: ${rm?.capacity})`;
  };

  return (
    <div className="space-y-4">
      {/* View Selector & Action Controls */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm no-print space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* View mode toggle tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100/90 rounded-xl max-w-fit">
            <button
              onClick={() => setViewMode('class')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                viewMode === 'class'
                  ? 'bg-white text-navy-950 shadow-sm'
                  : 'text-slate-600 hover:text-navy-900'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              <span>Class View</span>
            </button>

            <button
              onClick={() => setViewMode('faculty')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                viewMode === 'faculty'
                  ? 'bg-white text-navy-950 shadow-sm'
                  : 'text-slate-600 hover:text-navy-900'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>Faculty View</span>
            </button>

            <button
              onClick={() => setViewMode('room')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                viewMode === 'room'
                  ? 'bg-white text-navy-950 shadow-sm'
                  : 'text-slate-600 hover:text-navy-900'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>Room View</span>
            </button>
          </div>

          {/* Action buttons: Undo, Regenerate, Export */}
          <div className="flex flex-wrap items-center gap-2">
            {canUndo && (
              <button
                onClick={onUndo}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-xl transition-colors shadow-2xs"
                title="Undo last manual move"
              >
                <Undo2 className="w-3.5 h-3.5 text-amber-600" />
                <span>Undo Edit</span>
              </button>
            )}

            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl transition-colors shadow-2xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Timetable</span>
            </button>

            <button
              onClick={() =>
                exportTimetableToCSV(
                  sessions,
                  config,
                  viewMode === 'class' ? selectedDivisionId : undefined
                )
              }
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl transition-colors shadow-2xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>Export CSV</span>
            </button>

            <button
              onClick={onRegenerate}
              disabled={isGenerating}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold text-white bg-navy-900 hover:bg-navy-800 disabled:opacity-60 rounded-xl shadow-sm transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 text-gold-400" />
              <span>Regenerate</span>
            </button>
          </div>
        </div>

        {/* Dynamic Secondary Filter Bar */}
        <div className="flex flex-wrap items-center gap-4 pt-3 border-t border-slate-100 text-xs">
          {/* Filter 1: Main entity based on viewMode */}
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-500">
              {viewMode === 'class'
                ? 'Select Division:'
                : viewMode === 'faculty'
                ? 'Select Faculty:'
                : 'Select Room:'}
            </span>

            {viewMode === 'class' && (
              <select
                value={selectedDivisionId}
                onChange={(e) => setSelectedDivisionId(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-navy-900"
              >
                {config.divisions.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.strength} students)
                  </option>
                ))}
              </select>
            )}

            {viewMode === 'faculty' && (
              <select
                value={selectedFacultyId}
                onChange={(e) => setSelectedFacultyId(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-navy-900"
              >
                {config.faculty.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name} ({f.department || 'CSE'})
                  </option>
                ))}
              </select>
            )}

            {viewMode === 'room' && (
              <select
                value={selectedRoomId}
                onChange={(e) => setSelectedRoomId(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-navy-900"
              >
                {config.rooms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name} ({r.type.toUpperCase()} • Cap: {r.capacity})
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Filter 2: Subject Filter */}
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-500">Filter Subject:</span>
            <select
              value={selectedSubjectFilter}
              onChange={(e) => setSelectedSubjectFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-slate-800 font-medium focus:outline-none focus:ring-1 focus:ring-navy-900"
            >
              <option value="all">All Subjects</option>
              {config.subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.code} - {s.name}
                </option>
              ))}
            </select>
          </div>

          <div className="ml-auto text-[11px] text-slate-400 hidden sm:block">
            💡 Click any placed card to inspect details or relocate slot safely.
          </div>
        </div>
      </div>

      {/* Printable Header Info (Appears in Print Mode) */}
      <div className="hidden print-only mb-4 p-4 border-b border-slate-300">
        <h1 className="text-xl font-bold text-black">{config.collegeName}</h1>
        <p className="text-sm text-slate-700">
          {config.department} • {config.academicYear} • {config.semester}
        </p>
        <p className="text-sm font-semibold mt-1 text-slate-900">{currentViewTitle()}</p>
      </div>

      {/* The Master Timetable Table Grid */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden print-full-width">
        {/* Table title bar */}
        <div className="p-4 bg-slate-50/80 border-b border-slate-200 flex items-center justify-between no-print">
          <div className="flex items-center gap-2.5">
            <Calendar className="w-4 h-4 text-navy-800" />
            <h3 className="text-sm font-bold text-navy-950">{currentViewTitle()}</h3>
          </div>
          <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-navy-100 text-navy-800">
            {visibleSessions.length} sessions active
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse timetable-grid-table text-left">
            <thead>
              <tr className="bg-navy-950 text-white text-xs border-b border-navy-900">
                <th className="py-3 px-3.5 font-bold uppercase tracking-wider w-36 border-r border-navy-800/60 sticky left-0 bg-navy-950 z-10">
                  Period / Time
                </th>
                {config.workingDays.map((day) => (
                  <th
                    key={day}
                    className="py-3 px-4 font-bold uppercase tracking-wider min-w-[170px] border-r border-navy-800/60 last:border-r-0 text-center"
                  >
                    {day}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-xs">
              {config.periods.map((period) => {
                // Special handling for Break / Lunch rows
                if (period.type === 'break' || period.type === 'lunch') {
                  const isLunch = period.type === 'lunch';
                  return (
                    <tr
                      key={period.id}
                      className={
                        isLunch
                          ? 'bg-amber-50/70 border-y border-amber-200'
                          : 'bg-slate-100/80 border-y border-slate-200'
                      }
                    >
                      <td className="py-2 px-3.5 font-semibold text-slate-600 border-r border-slate-200/80 sticky left-0 bg-inherit z-10">
                        <div className="flex items-center gap-1.5 text-[11px]">
                          {isLunch ? (
                            <Utensils className="w-3 h-3 text-amber-600" />
                          ) : (
                            <Coffee className="w-3 h-3 text-slate-500" />
                          )}
                          <span>
                            P{period.id} ({period.startTime}–{period.endTime})
                          </span>
                        </div>
                      </td>
                      <td
                        colSpan={config.workingDays.length}
                        className="py-2 px-4 text-center text-xs font-bold uppercase tracking-widest text-slate-600"
                      >
                        {isLunch ? '🍽️ Lunch Interval' : '☕ Tea & Short Break'} (
                        {period.startTime} – {period.endTime})
                      </td>
                    </tr>
                  );
                }

                // Regular teaching period row
                return (
                  <tr key={period.id} className="hover:bg-slate-50/50 transition-colors">
                    {/* Period header cell */}
                    <td className="py-3 px-3.5 border-r border-slate-200 bg-slate-50/90 font-medium text-slate-700 sticky left-0 z-10">
                      <div className="font-bold text-navy-950">Period {period.id}</div>
                      <div className="text-[11px] text-slate-500 font-mono">
                        {period.startTime}–{period.endTime}
                      </div>
                    </td>

                    {/* Day Cells */}
                    {config.workingDays.map((day) => {
                      const cellKey = `${day}:${period.id}`;
                      const session = sessionCellMap.get(cellKey);

                      // If session is a multi-period practical and this is NOT the first period of that block,
                      // we can render a continuation tag or skip if rowSpan is used.
                      // For clear grid fidelity, we show connected cards.
                      if (!session) {
                        return (
                          <td
                            key={cellKey}
                            className="p-2 border-r border-slate-200 last:border-r-0 align-top h-24 bg-white/40"
                          >
                            <div className="h-full border border-dashed border-slate-200 rounded-xl flex items-center justify-center text-slate-300 hover:border-slate-300 hover:text-slate-400 transition-colors group">
                              <span className="text-[11px] font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                                Free Slot
                              </span>
                            </div>
                          </td>
                        );
                      }

                      const isFirstPeriodOfBlock = session.periodIds[0] === period.id;
                      const isMultiPeriod = session.periodIds.length > 1;
                      const style = getSubjectColorStyle(session.subjectId);
                      const faculty = config.faculty.find((f) => f.id === session.facultyId);
                      const room = config.rooms.find((r) => r.id === session.roomId);
                      const division = config.divisions.find((d) => d.id === session.divisionId);

                      return (
                        <td
                          key={cellKey}
                          className="p-2 border-r border-slate-200 last:border-r-0 align-top h-24"
                        >
                          <div
                            onClick={() => setInspectSession(session)}
                            className={`h-full p-2.5 rounded-xl border ${style.border} ${style.bg} cursor-pointer shadow-2xs hover:shadow-md transition-all flex flex-col justify-between timetable-card group`}
                          >
                            <div>
                              <div className="flex items-center justify-between gap-1 mb-1">
                                <span
                                  className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded ${style.badge}`}
                                >
                                  {session.subjectCode || session.subjectId}
                                </span>

                                <span
                                  className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.2 rounded-full ${
                                    session.sessionType === 'practical'
                                      ? 'bg-purple-200 text-purple-900 border border-purple-300'
                                      : 'bg-blue-100 text-blue-800'
                                  }`}
                                >
                                  {session.sessionType === 'practical'
                                    ? `Lab (${session.periodIds.length}P)`
                                    : 'Lecture'}
                                </span>
                              </div>

                              <h4
                                className={`text-xs font-bold leading-snug line-clamp-2 ${style.text}`}
                              >
                                {session.subjectName}
                              </h4>
                            </div>

                            <div className="pt-2 mt-1 border-t border-slate-200/50 flex flex-col gap-0.5 text-[10px] text-slate-600">
                              {viewMode !== 'faculty' && (
                                <div className="flex items-center gap-1 truncate font-medium">
                                  <User className="w-2.5 h-2.5 text-slate-500 shrink-0" />
                                  <span className="truncate">{faculty?.name || session.facultyId}</span>
                                </div>
                              )}

                              {viewMode !== 'room' && (
                                <div className="flex items-center gap-1 truncate">
                                  <Building2 className="w-2.5 h-2.5 text-slate-500 shrink-0" />
                                  <span className="truncate">{room?.name || session.roomId}</span>
                                </div>
                              )}

                              {viewMode !== 'class' && (
                                <div className="flex items-center gap-1 truncate font-semibold text-navy-900">
                                  <GraduationCap className="w-2.5 h-2.5 text-slate-500 shrink-0" />
                                  <span className="truncate">{division?.name || session.divisionId}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Legend */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs no-print flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-4 flex-wrap">
          <span className="font-bold text-slate-700">Subjects Legend:</span>
          {config.subjects.map((subj) => {
            const style = getSubjectColorStyle(subj.id);
            return (
              <div key={subj.id} className="flex items-center gap-1.5">
                <span className={`w-3 h-3 rounded-full ${style.badge}`} />
                <span className="text-slate-600 font-medium">
                  {subj.code} ({subj.name})
                </span>
              </div>
            );
          })}
        </div>

        <div className="flex items-center gap-3">
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-purple-100 text-purple-800 font-semibold text-[11px]">
            Lab / Practical (Consecutive Periods)
          </span>
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-semibold text-[11px]">
            Classroom Lecture
          </span>
        </div>
      </div>

      {/* Modals */}
      <SessionDetailModal
        session={inspectSession}
        config={config}
        isOpen={!!inspectSession}
        onClose={() => setInspectSession(null)}
        onOpenMoveModal={(s) => setMoveSession(s)}
      />

      <MoveSessionModal
        session={moveSession}
        sessions={sessions}
        config={config}
        isOpen={!!moveSession}
        onClose={() => setMoveSession(null)}
        onApplyMove={onApplyMove}
      />
    </div>
  );
};
