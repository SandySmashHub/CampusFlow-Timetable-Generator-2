import React, { useState, useEffect } from 'react';
import {
  X,
  ArrowRightLeft,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Clock,
  MapPin,
  ShieldAlert,
} from 'lucide-react';
import { CollegeConfig, PlacedSession, EditProposal } from '../../types';
import { proposeMove, applyMove } from '../../engine/editor';

interface MoveSessionModalProps {
  session: PlacedSession | null;
  sessions: PlacedSession[];
  config: CollegeConfig;
  isOpen: boolean;
  onClose: () => void;
  onApplyMove: (updatedSessions: PlacedSession[], proposal: EditProposal) => void;
}

export const MoveSessionModal: React.FC<MoveSessionModalProps> = ({
  session,
  sessions,
  config,
  isOpen,
  onClose,
  onApplyMove,
}) => {
  if (!isOpen || !session) return null;

  const [selectedDay, setSelectedDay] = useState<string>(session.day);
  const [selectedStartPeriodId, setSelectedStartPeriodId] = useState<number>(session.periodIds[0]);
  const [selectedRoomId, setSelectedRoomId] = useState<string>(session.roomId);
  const [proposal, setProposal] = useState<EditProposal | null>(null);

  // Sync state when session changes
  useEffect(() => {
    if (session) {
      setSelectedDay(session.day);
      setSelectedStartPeriodId(session.periodIds[0]);
      setSelectedRoomId(session.roomId);
    }
  }, [session]);

  // Live constraint validation whenever choices change
  useEffect(() => {
    if (!session) return;
    const prop = proposeMove(sessions, config, {
      taskId: session.taskId,
      newDay: selectedDay,
      newStartPeriodId: selectedStartPeriodId,
      newRoomId: selectedRoomId,
    });
    setProposal(prop);
  }, [selectedDay, selectedStartPeriodId, selectedRoomId, session, sessions, config]);

  const handleConfirm = () => {
    if (proposal && proposal.accepted) {
      const updated = applyMove(sessions, proposal);
      onApplyMove(updated, proposal);
      onClose();
    }
  };

  const periodOptions = config.periods.filter((p) => config.schedulablePeriodIds.includes(p.id));
  const isModified =
    selectedDay !== session.day ||
    selectedStartPeriodId !== session.periodIds[0] ||
    selectedRoomId !== session.roomId;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden transform transition-all scale-100">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-navy-900 to-navy-800 text-white flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs px-2 py-0.5 rounded bg-gold-400 text-navy-950 font-bold">
                {session.subjectCode || session.subjectId}
              </span>
              <span className="text-xs text-slate-300">
                {session.sessionType === 'practical'
                  ? `Practical Block (${session.periodIds.length} periods)`
                  : 'Single Lecture'}
              </span>
            </div>
            <h3 className="text-lg font-bold text-white">Relocate / Move Session</h3>
            <p className="text-xs text-slate-300 mt-0.5">
              Live constraint validator will test the move before committing.
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-navy-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form controls */}
        <div className="p-6 space-y-4">
          <div className="text-xs text-slate-500 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <span className="font-semibold text-slate-700">Current Placement:</span>{' '}
            {session.day}, Period {session.periodIds.join('-')} in{' '}
            {config.rooms.find((r) => r.id === session.roomId)?.name || session.roomId}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Day Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-navy-700" />
                <span>Target Day</span>
              </label>
              <select
                value={selectedDay}
                onChange={(e) => setSelectedDay(e.target.value)}
                className="w-full text-xs font-medium bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-navy-900"
              >
                {config.workingDays.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            {/* Start Period Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-navy-700" />
                <span>
                  {session.sessionType === 'practical' ? 'Start Period' : 'Target Period'}
                </span>
              </label>
              <select
                value={selectedStartPeriodId}
                onChange={(e) => setSelectedStartPeriodId(Number(e.target.value))}
                className="w-full text-xs font-medium bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-navy-900"
              >
                {periodOptions.map((p) => (
                  <option key={p.id} value={p.id}>
                    Period {p.id} ({p.startTime}–{p.endTime})
                  </option>
                ))}
              </select>
            </div>

            {/* Room Selector */}
            <div className="sm:col-span-2 space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-navy-700" />
                <span>Target Classroom / Laboratory</span>
              </label>
              <select
                value={selectedRoomId}
                onChange={(e) => setSelectedRoomId(e.target.value)}
                className="w-full text-xs font-medium bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-navy-900"
              >
                {config.rooms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name} ({r.type.toUpperCase()} • Cap: {r.capacity})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Real-time Constraint Feedback Box */}
          {proposal && (
            <div
              className={`p-4 rounded-xl border transition-all ${
                proposal.accepted
                  ? 'bg-emerald-50/80 border-emerald-300 text-emerald-900'
                  : 'bg-rose-50/90 border-rose-300 text-rose-900'
              }`}
            >
              <div className="flex items-start gap-2.5">
                {proposal.accepted ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                )}
                <div className="space-y-1">
                  <h4 className="text-xs font-bold uppercase tracking-wider">
                    {proposal.accepted ? 'Move Permitted' : 'Constraint Conflict Detected'}
                  </h4>
                  <p className="text-xs leading-relaxed">{proposal.reason}</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-4 flex items-center justify-between border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors shadow-sm"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handleConfirm}
            disabled={!proposal || !proposal.accepted || !isModified}
            className="px-5 py-2 text-xs font-bold text-white bg-navy-900 hover:bg-navy-800 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-md shadow-navy-900/20 transition-all flex items-center gap-2"
          >
            <ArrowRightLeft className="w-3.5 h-3.5 text-gold-400" />
            <span>Apply Relocation</span>
          </button>
        </div>
      </div>
    </div>
  );
};
