import {
  CollegeConfig,
  Task,
  PlacedSession,
  ScheduleResult,
  Room,
  Faculty,
  Period,
  Division,
  Subject,
} from '../types';

export function slotKey(day: string, periodId: number): string {
  return `${day}:${periodId}`;
}

export function indexBy<T, K>(arr: T[], keyFn: (item: T) => K): Map<K, T> {
  const map = new Map<K, T>();
  for (const item of arr) {
    map.set(keyFn(item), item);
  }
  return map;
}

export function expandTasks(config: CollegeConfig): Task[] {
  const { assignments, subjects } = config;
  const subjectMap = indexBy(subjects, (s) => s.id);
  const tasks: Task[] = [];
  let seq = 0;

  for (const asgn of assignments) {
    const subj = subjectMap.get(asgn.subjectId);
    if (!subj) continue;

    // Lectures
    for (let i = 0; i < subj.lecturesPerWeek; i++) {
      tasks.push({
        id: `T${++seq}`,
        divisionId: asgn.divisionId,
        subjectId: subj.id,
        subjectName: subj.name,
        subjectCode: subj.code,
        sessionType: 'lecture',
        facultyId: asgn.facultyLectureId,
        requiredRoomType: subj.roomType || 'classroom',
        periodsRequired: 1,
        preferredDays: asgn.preferredDays || subj.preferredDays || null,
        preferredPeriods: asgn.preferredPeriods || subj.preferredPeriods || null,
      });
    }

    // Practical blocks (consecutive periods)
    if (subj.practicalsPerWeek > 0 && asgn.facultyPracticalId) {
      for (let i = 0; i < subj.practicalsPerWeek; i++) {
        tasks.push({
          id: `T${++seq}`,
          divisionId: asgn.divisionId,
          subjectId: subj.id,
          subjectName: subj.name,
          subjectCode: subj.code,
          sessionType: 'practical',
          facultyId: asgn.facultyPracticalId,
          requiredRoomType: subj.labRoomType || 'lab',
          periodsRequired: subj.practicalPeriods > 0 ? subj.practicalPeriods : 2,
          preferredDays: asgn.preferredDays || subj.preferredDays || null,
          preferredPeriods: asgn.preferredPeriods || subj.preferredPeriods || null,
        });
      }
    }
  }

  return tasks;
}

export function getConsecutivePeriods(
  startId: number,
  count: number,
  schedulablePeriodIds: number[],
  periodMap: Map<number, Period>
): number[] | null {
  const result: number[] = [];
  let current = startId;
  const schedulableSet = new Set(schedulablePeriodIds);

  for (let i = 0; i < count; i++) {
    const period = periodMap.get(current);
    if (!period || period.type !== 'lecture') return null;
    if (!schedulableSet.has(current)) return null;
    result.push(current);
    current++;
  }

  return result;
}

interface CandidateSlot {
  day: string;
  startPeriodId: number;
  room: Room;
  prefScore: number;
}

function isSlotBlocked(blocked: string[] | Set<string> | undefined, key: string): boolean {
  if (!blocked) return false;
  if (blocked instanceof Set) return blocked.has(key);
  if (Array.isArray(blocked)) return blocked.includes(key);
  return false;
}

export function generateCandidates(
  task: Task,
  config: CollegeConfig,
  roomMap: Map<string, Room>,
  facultyMap: Map<string, Faculty>,
  periodMap: Map<number, Period>
): CandidateSlot[] {
  const { workingDays, schedulablePeriodIds } = config;
  const faculty = facultyMap.get(task.facultyId);
  const candidates: CandidateSlot[] = [];

  for (const day of workingDays) {
    for (const startPeriodId of schedulablePeriodIds) {
      const periodIds =
        task.periodsRequired === 1
          ? [startPeriodId]
          : getConsecutivePeriods(startPeriodId, task.periodsRequired, schedulablePeriodIds, periodMap);

      if (!periodIds || periodIds.length === 0) continue;

      // Check faculty structural availability
      if (faculty && faculty.blockedSlots) {
        let facultyBlocked = false;
        for (const pid of periodIds) {
          if (isSlotBlocked(faculty.blockedSlots, slotKey(day, pid))) {
            facultyBlocked = true;
            break;
          }
        }
        if (facultyBlocked) continue;
      }

      // Check rooms
      for (const room of config.rooms) {
        if (room.type !== task.requiredRoomType) continue;

        let roomBlocked = false;
        if (room.blockedSlots) {
          for (const pid of periodIds) {
            if (isSlotBlocked(room.blockedSlots, slotKey(day, pid))) {
              roomBlocked = true;
              break;
            }
          }
        }
        if (roomBlocked) continue;

        // Preference scoring (lower = better)
        let prefScore = 0;
        if (task.preferredDays && task.preferredDays.length > 0 && !task.preferredDays.includes(day)) {
          prefScore += 10;
        }
        if (task.preferredPeriods && task.preferredPeriods.length > 0 && !task.preferredPeriods.includes(startPeriodId)) {
          prefScore += 5;
        }

        candidates.push({ day, startPeriodId, room, prefScore });
      }
    }
  }

  return candidates;
}

export function sortByMCV(
  tasks: Task[],
  config: CollegeConfig,
  roomMap: Map<string, Room>,
  facultyMap: Map<string, Faculty>,
  periodMap: Map<number, Period>
): Task[] {
  const candidateCounts = new Map<string, number>();
  for (const task of tasks) {
    const cands = generateCandidates(task, config, roomMap, facultyMap, periodMap);
    candidateCounts.set(task.id, cands.length);
  }

  return [...tasks].sort((a, b) => {
    // 1. Practicals first (harder to fit consecutive blocks)
    const aIsPrac = a.sessionType === 'practical' ? 0 : 1;
    const bIsPrac = b.sessionType === 'practical' ? 0 : 1;
    if (aIsPrac !== bIsPrac) return aIsPrac - bIsPrac;

    // 2. Fewest candidates first (MCV)
    const aCount = candidateCounts.get(a.id) ?? 999;
    const bCount = candidateCounts.get(b.id) ?? 999;
    if (aCount !== bCount) return aCount - bCount;

    // 3. Stable tie-break by ID
    return a.id.localeCompare(b.id);
  });
}

export interface ScheduleState {
  divisionOccupancy: Map<string, Set<string>>;
  facultyOccupancy: Map<string, Set<string>>;
  roomOccupancy: Map<string, Set<string>>;
  dailyLoad: Map<string, number>;
  weeklyLoad: Map<string, number>;
  sessions: PlacedSession[];
}

export function createState(config: CollegeConfig): ScheduleState {
  const divOcc = new Map<string, Set<string>>();
  const facOcc = new Map<string, Set<string>>();
  const roomOcc = new Map<string, Set<string>>();
  const dailyLoad = new Map<string, number>();
  const weeklyLoad = new Map<string, number>();

  for (const div of config.divisions) divOcc.set(div.id, new Set<string>());
  for (const fac of config.faculty) {
    facOcc.set(fac.id, new Set<string>());
    weeklyLoad.set(fac.id, 0);
    for (const day of config.workingDays) {
      dailyLoad.set(`${fac.id}:${day}`, 0);
    }
  }
  for (const room of config.rooms) roomOcc.set(room.id, new Set<string>());

  return {
    divisionOccupancy: divOcc,
    facultyOccupancy: facOcc,
    roomOccupancy: roomOcc,
    dailyLoad,
    weeklyLoad,
    sessions: [],
  };
}

export function placeSession(state: ScheduleState, session: PlacedSession): void {
  const { day, periodIds, divisionId, facultyId, roomId } = session;

  for (const pid of periodIds) {
    const k = slotKey(day, pid);
    state.divisionOccupancy.get(divisionId)?.add(k);
    state.facultyOccupancy.get(facultyId)?.add(k);
    state.roomOccupancy.get(roomId)?.add(k);
  }

  const dlKey = `${facultyId}:${day}`;
  state.dailyLoad.set(dlKey, (state.dailyLoad.get(dlKey) || 0) + periodIds.length);
  state.weeklyLoad.set(facultyId, (state.weeklyLoad.get(facultyId) || 0) + periodIds.length);
  state.sessions.push(session);
}

export function removeLastSession(state: ScheduleState): void {
  const session = state.sessions.pop();
  if (!session) return;
  const { day, periodIds, divisionId, facultyId, roomId } = session;

  for (const pid of periodIds) {
    const k = slotKey(day, pid);
    state.divisionOccupancy.get(divisionId)?.delete(k);
    state.facultyOccupancy.get(facultyId)?.delete(k);
    state.roomOccupancy.get(roomId)?.delete(k);
  }

  const dlKey = `${facultyId}:${day}`;
  state.dailyLoad.set(dlKey, (state.dailyLoad.get(dlKey) || 0) - periodIds.length);
  state.weeklyLoad.set(facultyId, (state.weeklyLoad.get(facultyId) || 0) - periodIds.length);
}

export function checkConstraints(
  state: ScheduleState,
  task: Task,
  day: string,
  periodIds: number[],
  room: Room,
  faculty?: Faculty,
  division?: Division
): string | null {
  for (const pid of periodIds) {
    const k = slotKey(day, pid);

    // C1: Division clash
    if (state.divisionOccupancy.get(task.divisionId)?.has(k)) {
      return `Division conflict: ${division?.name || task.divisionId} is already scheduled at ${day} Period ${pid}`;
    }

    // C2: Faculty clash
    if (faculty && state.facultyOccupancy.get(task.facultyId)?.has(k)) {
      return `Faculty conflict: ${faculty.name} is already teaching another class at ${day} Period ${pid}`;
    }

    // C3: Room clash
    if (state.roomOccupancy.get(room.id)?.has(k)) {
      return `Room conflict: ${room.name} is already occupied at ${day} Period ${pid}`;
    }

    // C4: Faculty availability
    if (faculty && isSlotBlocked(faculty.blockedSlots, k)) {
      return `Faculty unavailable: ${faculty.name} has marked ${day} Period ${pid} as unavailable`;
    }

    // C5: Room availability
    if (isSlotBlocked(room.blockedSlots, k)) {
      return `Room unavailable: ${room.name} is unavailable at ${day} Period ${pid}`;
    }
  }

  // C6: Room type match
  if (room.type !== task.requiredRoomType) {
    return `Room type mismatch: Session requires a ${task.requiredRoomType}, but ${room.name} is a ${room.type}`;
  }

  // C7: Room capacity
  if (division) {
    const relevantStrength =
      room.type === 'lab'
        ? division.practicalBatchSize ?? Math.ceil(division.strength / 2)
        : division.strength;
    if (room.capacity < relevantStrength) {
      return `Room capacity insufficient: ${room.name} holds ${room.capacity} students, but required capacity is ${relevantStrength}`;
    }
  }

  // C9 & C10: Faculty workload limits
  if (faculty) {
    const dlKey = `${faculty.id}:${day}`;
    const currentDaily = state.dailyLoad.get(dlKey) || 0;
    if (currentDaily + periodIds.length > faculty.maxPeriodsPerDay) {
      return `Faculty daily load exceeded: ${faculty.name} has max ${faculty.maxPeriodsPerDay} periods/day (currently at ${currentDaily})`;
    }

    const currentWeekly = state.weeklyLoad.get(faculty.id) || 0;
    if (currentWeekly + periodIds.length > faculty.maxPeriodsPerWeek) {
      return `Faculty weekly load exceeded: ${faculty.name} has max ${faculty.maxPeriodsPerWeek} periods/week (currently at ${currentWeekly})`;
    }
  }

  return null;
}

function backtrack(
  tasks: Task[],
  index: number,
  state: ScheduleState,
  config: CollegeConfig,
  roomMap: Map<string, Room>,
  facultyMap: Map<string, Faculty>,
  divisionMap: Map<string, Division>,
  periodMap: Map<number, Period>,
  backtracks: { count: number }
): boolean {
  if (index === tasks.length) return true;
  if (backtracks.count >= config.maxBacktracks) return false;

  const task = tasks[index];
  const faculty = facultyMap.get(task.facultyId);
  const division = divisionMap.get(task.divisionId);

  const rawCandidates = generateCandidates(task, config, roomMap, facultyMap, periodMap);
  rawCandidates.sort((a, b) => a.prefScore - b.prefScore);

  for (const cand of rawCandidates) {
    const { day, startPeriodId, room } = cand;

    const periodIds =
      task.periodsRequired === 1
        ? [startPeriodId]
        : getConsecutivePeriods(startPeriodId, task.periodsRequired, config.schedulablePeriodIds, periodMap) || [];

    if (periodIds.length === 0) continue;

    const violation = checkConstraints(state, task, day, periodIds, room, faculty, division);
    if (violation) continue;

    const session: PlacedSession = {
      taskId: task.id,
      divisionId: task.divisionId,
      subjectId: task.subjectId,
      subjectName: task.subjectName,
      subjectCode: task.subjectCode,
      sessionType: task.sessionType,
      facultyId: task.facultyId,
      roomId: room.id,
      day,
      periodIds,
    };

    placeSession(state, session);

    if (backtrack(tasks, index + 1, state, config, roomMap, facultyMap, divisionMap, periodMap, backtracks)) {
      return true;
    }

    removeLastSession(state);
    backtracks.count++;
  }

  return false;
}

export function diagnose(
  unscheduledTasks: Task[],
  state: ScheduleState,
  config: CollegeConfig,
  roomMap: Map<string, Room>,
  facultyMap: Map<string, Faculty>,
  periodMap: Map<number, Period>
): { messages: string[]; suggestions: string[] } {
  const messages: string[] = [];
  const suggestions: string[] = [];
  const suggestionSet = new Set<string>();

  const addSuggestion = (s: string) => {
    if (!suggestionSet.has(s)) {
      suggestionSet.add(s);
      suggestions.push(s);
    }
  };

  for (const task of unscheduledTasks) {
    const faculty = facultyMap.get(task.facultyId);
    const div = config.divisions.find((d) => d.id === task.divisionId);
    const rawCandidates = generateCandidates(task, config, roomMap, facultyMap, periodMap);

    messages.push(
      `[${task.id}] ${div?.name || task.divisionId} - ${task.subjectName} (${task.sessionType}): ` +
        `${rawCandidates.length} potential slots available prior to occupancy checks.`
    );

    if (rawCandidates.length === 0) {
      messages.push(`  → No structural slot matches availability, room type, and consecutive duration constraints.`);

      if (faculty) {
        const wkLoad = state.weeklyLoad.get(faculty.id) || 0;
        if (wkLoad >= faculty.maxPeriodsPerWeek) {
          addSuggestion(
            `Faculty capacity reached: ${faculty.name} is at maximum weekly load (${wkLoad}/${faculty.maxPeriodsPerWeek}). Increase workload limit or assign co-faculty.`
          );
        }
      }

      const suitableRooms = config.rooms.filter((r) => r.type === task.requiredRoomType);
      if (suitableRooms.length === 0) {
        addSuggestion(
          `Missing facility: No rooms registered with type '${task.requiredRoomType}' for subject ${task.subjectName}. Add a new ${task.requiredRoomType}.`
        );
      }
    }
  }

  if (unscheduledTasks.some((t) => t.sessionType === 'practical')) {
    addSuggestion(
      `Consecutive slot constraint: Practical blocks require multiple unbroken periods outside of lunch and breaks. Consider relaxing faculty blocked hours or adding laboratory capacity.`
    );
  }

  if (unscheduledTasks.length > 0 && suggestions.length === 0) {
    addSuggestion(
      `High density schedule: The number of total required periods is close to maximum weekly slot availability. Consider adding periods or expanding working days.`
    );
  }

  return { messages, suggestions };
}

export function schedule(config: CollegeConfig): ScheduleResult {
  const startTime = performance.now();

  const roomMap = indexBy(config.rooms, (r) => r.id);
  const facultyMap = indexBy(config.faculty, (f) => f.id);
  const divisionMap = indexBy(config.divisions, (d) => d.id);
  const periodMap = indexBy(config.periods, (p) => p.id);

  const rawTasks = expandTasks(config);
  const tasks = sortByMCV(rawTasks, config, roomMap, facultyMap, periodMap);

  const state = createState(config);
  const backtracks = { count: 0 };

  const success = backtrack(tasks, 0, state, config, roomMap, facultyMap, divisionMap, periodMap, backtracks);

  const executionTimeMs = Math.round(performance.now() - startTime);
  const searchLimitReached = !success && backtracks.count >= config.maxBacktracks;

  const scheduledTaskIds = new Set(state.sessions.map((s) => s.taskId));
  const unscheduledTasks = tasks.filter((t) => !scheduledTaskIds.has(t.id));

  const { messages: diagnosticMessages, suggestions } = diagnose(
    unscheduledTasks,
    state,
    config,
    roomMap,
    facultyMap,
    periodMap
  );

  let status: 'complete' | 'partial' | 'failed';
  if (unscheduledTasks.length === 0) {
    status = 'complete';
  } else if (state.sessions.length > 0) {
    status = 'partial';
  } else {
    status = 'failed';
  }

  return {
    status,
    sessions: state.sessions,
    unscheduledTasks,
    validationErrors: [],
    stats: {
      backtracks: backtracks.count,
      searchLimitReached,
      totalTasks: tasks.length,
      scheduledCount: state.sessions.length,
      executionTimeMs,
    },
    diagnosticMessages,
    suggestions,
  };
}
