import {
  CollegeConfig,
  PlacedSession,
  ValidationReport,
  ValidationError,
} from '../types';
import { indexBy, slotKey, expandTasks } from './scheduler';

function isSlotBlocked(blocked: string[] | Set<string> | undefined, key: string): boolean {
  if (!blocked) return false;
  if (blocked instanceof Set) return blocked.has(key);
  if (Array.isArray(blocked)) return blocked.includes(key);
  return false;
}

export function validate(sessions: PlacedSession[], config: CollegeConfig): ValidationReport {
  const errors: ValidationError[] = [];

  const roomMap = indexBy(config.rooms, (r) => r.id);
  const facultyMap = indexBy(config.faculty, (f) => f.id);
  const divisionMap = indexBy(config.divisions, (d) => d.id);
  const subjectMap = indexBy(config.subjects, (s) => s.id);
  const periodMap = indexBy(config.periods, (p) => p.id);
  const workingDaySet = new Set(config.workingDays);

  const divisionOccupancy = new Map<string, string[]>(); // "divId:day:pid" -> taskIds
  const facultyOccupancy = new Map<string, string[]>();  // "facId:day:pid" -> taskIds
  const roomOccupancy = new Map<string, string[]>();     // "roomId:day:pid" -> taskIds

  const facultyDailyLoad = new Map<string, number>();    // "facId:day" -> count
  const facultyWeeklyLoad = new Map<string, number>();   // "facId" -> count

  const addOccupancy = (map: Map<string, string[]>, key: string, taskId: string) => {
    const list = map.get(key) || [];
    list.push(taskId);
    map.set(key, list);
  };

  let facultyClashCount = 0;
  let roomClashCount = 0;
  let divisionClashCount = 0;

  // Pass 1: Session-level validity
  for (const session of sessions) {
    const { taskId, divisionId, subjectId, sessionType, facultyId, roomId, day, periodIds } = session;

    // V01: Unknown references
    const division = divisionMap.get(divisionId);
    const faculty = facultyMap.get(facultyId);
    const room = roomMap.get(roomId);
    const subject = subjectMap.get(subjectId);

    if (!division) {
      errors.push({ code: 'V01', message: `Unknown division '${divisionId}' in session ${taskId}` });
    }
    if (!faculty) {
      errors.push({ code: 'V01', message: `Unknown faculty '${facultyId}' in session ${taskId}` });
    }
    if (!room) {
      errors.push({ code: 'V01', message: `Unknown room '${roomId}' in session ${taskId}` });
    }
    if (!subject) {
      errors.push({ code: 'V01', message: `Unknown subject '${subjectId}' in session ${taskId}` });
    }

    // V02: Non-working day
    if (!workingDaySet.has(day)) {
      errors.push({
        code: 'V02',
        message: `Session ${taskId} scheduled on non-working day '${day}'`,
        context: { taskId, day },
      });
    }

    // V03: Break or lunch slot
    for (const pid of periodIds) {
      const period = periodMap.get(pid);
      if (period && period.type !== 'lecture') {
        errors.push({
          code: 'V03',
          message: `Session ${taskId} scheduled during ${period.type} (Period ${pid}) on ${day}`,
          context: { taskId, periodId: pid, periodType: period.type },
        });
      }
    }

    // V07: Faculty blocked slot
    if (faculty) {
      for (const pid of periodIds) {
        const k = slotKey(day, pid);
        if (isSlotBlocked(faculty.blockedSlots, k)) {
          errors.push({
            code: 'V07',
            message: `Faculty ${faculty.name} is unavailable on ${day} Period ${pid}`,
            context: { taskId, facultyId, day, periodId: pid },
          });
        }
      }
    }

    // V08: Room blocked slot
    if (room) {
      for (const pid of periodIds) {
        const k = slotKey(day, pid);
        if (isSlotBlocked(room.blockedSlots, k)) {
          errors.push({
            code: 'V08',
            message: `Room ${room.name} is unavailable on ${day} Period ${pid}`,
            context: { taskId, roomId, day, periodId: pid },
          });
        }
      }
    }

    // V09: Room type match
    if (room && subject) {
      const requiredRoomType = sessionType === 'practical' ? (subject.labRoomType || 'lab') : (subject.roomType || 'classroom');
      if (room.type !== requiredRoomType) {
        errors.push({
          code: 'V09',
          message: `Room type mismatch: Session ${taskId} (${sessionType}) requires ${requiredRoomType}, but ${room.name} is ${room.type}`,
          context: { taskId, requiredRoomType, actualRoomType: room.type },
        });
      }
    }

    // V10: Room capacity
    if (room && division) {
      const requiredCapacity =
        sessionType === 'practical'
          ? (division.practicalBatchSize ?? Math.ceil(division.strength / 2))
          : division.strength;
      if (room.capacity < requiredCapacity) {
        errors.push({
          code: 'V10',
          message: `Insufficient room capacity: ${room.name} (${room.capacity}) < required (${requiredCapacity}) for ${division.name}`,
          context: { taskId, roomCapacity: room.capacity, requiredCapacity },
        });
      }
    }

    // V11 & V12: Practical consecutive periods & breaks
    if (sessionType === 'practical' && periodIds.length > 1) {
      for (let i = 0; i < periodIds.length - 1; i++) {
        if (periodIds[i + 1] !== periodIds[i] + 1) {
          errors.push({
            code: 'V11',
            message: `Practical session ${taskId} periods are not consecutive: [${periodIds.join(', ')}]`,
            context: { taskId, periodIds },
          });
          break;
        }

        const midPeriod = periodMap.get(periodIds[i]);
        if (midPeriod && midPeriod.type !== 'lecture') {
          errors.push({
            code: 'V12',
            message: `Practical session ${taskId} spans across break/lunch at period ${periodIds[i]}`,
            context: { taskId, periodId: periodIds[i] },
          });
        }
      }
    }

    // Accumulate occupancy for clash detection
    for (const pid of periodIds) {
      const divKey = `${divisionId}:${day}:${pid}`;
      const facKey = `${facultyId}:${day}:${pid}`;
      const rmKey = `${roomId}:${day}:${pid}`;

      addOccupancy(divisionOccupancy, divKey, taskId);
      addOccupancy(facultyOccupancy, facKey, taskId);
      addOccupancy(roomOccupancy, rmKey, taskId);
    }

    // Accumulate faculty workload
    if (faculty) {
      const dlKey = `${faculty.id}:${day}`;
      facultyDailyLoad.set(dlKey, (facultyDailyLoad.get(dlKey) || 0) + periodIds.length);
      facultyWeeklyLoad.set(faculty.id, (facultyWeeklyLoad.get(faculty.id) || 0) + periodIds.length);
    }
  }

  // Pass 2: Clash detections
  // V04: Division clashes
  for (const [key, taskIds] of divisionOccupancy.entries()) {
    if (taskIds.length > 1) {
      divisionClashCount++;
      const [divId, day, pid] = key.split(':');
      errors.push({
        code: 'V04',
        message: `Division clash: Division ${divId} has ${taskIds.length} simultaneous sessions on ${day} Period ${pid} (${taskIds.join(', ')})`,
        context: { divisionId: divId, day, periodId: pid, taskIds },
      });
    }
  }

  // V05: Faculty clashes
  for (const [key, taskIds] of facultyOccupancy.entries()) {
    if (taskIds.length > 1) {
      facultyClashCount++;
      const [facId, day, pid] = key.split(':');
      const fac = facultyMap.get(facId);
      errors.push({
        code: 'V05',
        message: `Faculty clash: ${fac?.name || facId} is double-booked on ${day} Period ${pid} (${taskIds.join(', ')})`,
        context: { facultyId: facId, day, periodId: pid, taskIds },
      });
    }
  }

  // V06: Room clashes
  for (const [key, taskIds] of roomOccupancy.entries()) {
    if (taskIds.length > 1) {
      roomClashCount++;
      const [rmId, day, pid] = key.split(':');
      const rm = roomMap.get(rmId);
      errors.push({
        code: 'V06',
        message: `Room clash: ${rm?.name || rmId} is booked for multiple sessions on ${day} Period ${pid} (${taskIds.join(', ')})`,
        context: { roomId: rmId, day, periodId: pid, taskIds },
      });
    }
  }

  // Pass 3: Workload limits (V14 & V15)
  for (const fac of config.faculty) {
    for (const day of config.workingDays) {
      const dl = facultyDailyLoad.get(`${fac.id}:${day}`) || 0;
      if (dl > fac.maxPeriodsPerDay) {
        errors.push({
          code: 'V14',
          message: `Faculty daily load exceeded: ${fac.name} teaches ${dl} periods on ${day} (max: ${fac.maxPeriodsPerDay})`,
          context: { facultyId: fac.id, day, actualLoad: dl, maxLoad: fac.maxPeriodsPerDay },
        });
      }
    }

    const wl = facultyWeeklyLoad.get(fac.id) || 0;
    if (wl > fac.maxPeriodsPerWeek) {
      errors.push({
        code: 'V15',
        message: `Faculty weekly load exceeded: ${fac.name} teaches ${wl} periods per week (max: ${fac.maxPeriodsPerWeek})`,
        context: { facultyId: fac.id, actualLoad: wl, maxLoad: fac.maxPeriodsPerWeek },
      });
    }
  }

  // Pass 4: Completeness (V13 - required sessions count)
  const allRequiredTasks = expandTasks(config);
  const totalRequired = allRequiredTasks.length;
  const totalScheduled = sessions.length;

  if (totalScheduled < totalRequired) {
    errors.push({
      code: 'V13',
      message: `Incomplete schedule: ${totalScheduled} of ${totalRequired} required sessions are scheduled (${totalRequired - totalScheduled} missing)`,
      context: { totalScheduled, totalRequired },
    });
  }

  return {
    valid: errors.length === 0,
    complete: totalScheduled >= totalRequired && errors.length === 0,
    errors,
    summary: {
      totalSessions: sessions.length,
      totalRequired,
      totalScheduled,
      facultyClashes: facultyClashCount,
      roomClashes: roomClashCount,
      divisionClashes: divisionClashCount,
    },
  };
}
