import {
  CollegeConfig,
  PlacedSession,
  MoveSpec,
  EditProposal,
  Task,
} from '../types';
import {
  indexBy,
  createState,
  placeSession,
  getConsecutivePeriods,
  checkConstraints,
} from './scheduler';

export function rebuildState(sessions: PlacedSession[], config: CollegeConfig) {
  const state = createState(config);
  for (const s of sessions) {
    placeSession(state, s);
  }
  return state;
}

export function proposeMove(
  sessions: PlacedSession[],
  config: CollegeConfig,
  moveSpec: MoveSpec
): EditProposal {
  const roomMap = indexBy(config.rooms, (r) => r.id);
  const facultyMap = indexBy(config.faculty, (f) => f.id);
  const divisionMap = indexBy(config.divisions, (d) => d.id);
  const periodMap = indexBy(config.periods, (p) => p.id);
  const subjectMap = indexBy(config.subjects, (s) => s.id);

  const original = sessions.find((s) => s.taskId === moveSpec.taskId);
  if (!original) {
    return {
      accepted: false,
      reason: `Session '${moveSpec.taskId}' was not found in the timetable.`,
      originalSession: null,
      proposedSession: null,
      violations: [`Session '${moveSpec.taskId}' not found.`],
    };
  }

  const newDay = moveSpec.newDay ?? original.day;
  const newStartPeriodId = moveSpec.newStartPeriodId ?? original.periodIds[0];
  const newRoomId = moveSpec.newRoomId ?? original.roomId;

  const targetRoom = roomMap.get(newRoomId);
  if (!targetRoom) {
    return {
      accepted: false,
      reason: `Selected room '${newRoomId}' does not exist.`,
      originalSession: original,
      proposedSession: null,
      violations: [`Room '${newRoomId}' does not exist.`],
    };
  }

  const faculty = facultyMap.get(original.facultyId);
  const division = divisionMap.get(original.divisionId);
  const subject = subjectMap.get(original.subjectId);

  // Compute required consecutive periods for this session
  const periodsRequired = original.periodIds.length;
  const proposedPeriodIds =
    periodsRequired === 1
      ? [newStartPeriodId]
      : getConsecutivePeriods(newStartPeriodId, periodsRequired, config.schedulablePeriodIds, periodMap);

  if (!proposedPeriodIds || proposedPeriodIds.length < periodsRequired) {
    const periodObj = periodMap.get(newStartPeriodId);
    return {
      accepted: false,
      reason: `Cannot fit a ${periodsRequired}-period practical starting at Period ${newStartPeriodId} (${periodObj?.label || ''}). It crosses a break, lunch, or exceeds the day.`,
      originalSession: original,
      proposedSession: null,
      violations: [
        `Insufficient consecutive periods starting at Period ${newStartPeriodId}. Practical sessions require ${periodsRequired} continuous teaching periods.`,
      ],
    };
  }

  // Rebuild state without original session
  const remainingSessions = sessions.filter((s) => s.taskId !== original.taskId);
  const state = rebuildState(remainingSessions, config);

  const mockTask: Task = {
    id: original.taskId,
    divisionId: original.divisionId,
    subjectId: original.subjectId,
    subjectName: original.subjectName,
    subjectCode: original.subjectCode || '',
    sessionType: original.sessionType,
    facultyId: original.facultyId,
    requiredRoomType: original.sessionType === 'practical' ? (subject?.labRoomType || 'lab') : (subject?.roomType || 'classroom'),
    periodsRequired,
  };

  const violation = checkConstraints(
    state,
    mockTask,
    newDay,
    proposedPeriodIds,
    targetRoom,
    faculty,
    division
  );

  const proposedSession: PlacedSession = {
    ...original,
    day: newDay,
    periodIds: proposedPeriodIds,
    roomId: newRoomId,
  };

  if (violation) {
    return {
      accepted: false,
      reason: violation,
      originalSession: original,
      proposedSession,
      violations: [violation],
    };
  }

  return {
    accepted: true,
    reason: `Valid placement: Session moved to ${newDay}, Period ${proposedPeriodIds.join('-')} in ${targetRoom.name}.`,
    originalSession: original,
    proposedSession,
    violations: [],
  };
}

export function applyMove(
  sessions: PlacedSession[],
  proposal: EditProposal
): PlacedSession[] {
  if (!proposal.accepted || !proposal.proposedSession) {
    return sessions;
  }

  return sessions.map((s) =>
    s.taskId === proposal.proposedSession!.taskId ? proposal.proposedSession! : s
  );
}
