import { CollegeConfig, PlacedSession } from '../types';

export function exportTimetableToCSV(
  sessions: PlacedSession[],
  config: CollegeConfig,
  filterDivisionId?: string
): void {
  const filteredSessions = filterDivisionId
    ? sessions.filter((s) => s.divisionId === filterDivisionId)
    : sessions;

  const roomMap = new Map(config.rooms.map((r) => [r.id, r.name]));
  const facultyMap = new Map(config.faculty.map((f) => [f.id, f.name]));
  const divMap = new Map(config.divisions.map((d) => [d.id, d.name]));
  const periodMap = new Map(config.periods.map((p) => [p.id, p]));

  const headers = [
    'Day',
    'Period ID(s)',
    'Time Slot',
    'Division',
    'Subject Code',
    'Subject Name',
    'Type',
    'Faculty',
    'Room / Lab',
  ];

  const rows = filteredSessions.map((s) => {
    const timeSlots = s.periodIds
      .map((pid) => {
        const p = periodMap.get(pid);
        return p ? `${p.startTime}-${p.endTime}` : `P${pid}`;
      })
      .join(', ');

    return [
      `"${s.day}"`,
      `"P${s.periodIds.join(', P')}"`,
      `"${timeSlots}"`,
      `"${divMap.get(s.divisionId) || s.divisionId}"`,
      `"${s.subjectCode || s.subjectId}"`,
      `"${s.subjectName.replace(/"/g, '""')}"`,
      `"${s.sessionType.toUpperCase()}"`,
      `"${facultyMap.get(s.facultyId) || s.facultyId}"`,
      `"${roomMap.get(s.roomId) || s.roomId}"`,
    ];
  });

  // Sort rows by day and first period
  const dayOrder: Record<string, number> = {};
  config.workingDays.forEach((d, i) => {
    dayOrder[d] = i;
  });

  rows.sort((a, b) => {
    const dayA = a[0].replace(/"/g, '');
    const dayB = b[0].replace(/"/g, '');
    if (dayOrder[dayA] !== dayOrder[dayB]) {
      return (dayOrder[dayA] ?? 99) - (dayOrder[dayB] ?? 99);
    }
    return a[1].localeCompare(b[1]);
  });

  const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  const timestamp = new Date().toISOString().slice(0, 10);
  link.setAttribute('download', `CampusFlow_Timetable_${filterDivisionId || 'All'}_${timestamp}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function exportProjectConfigJSON(config: CollegeConfig, sessions: PlacedSession[]): void {
  const exportPayload = {
    version: '1.0.0',
    exportedAt: new Date().toISOString(),
    config,
    sessions,
  };

  const jsonStr = JSON.stringify(exportPayload, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `CampusFlow_Config_${config.academicYear}_${Date.now()}.json`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export interface ImportValidationResult {
  valid: boolean;
  config?: CollegeConfig;
  sessions?: PlacedSession[];
  error?: string;
}

export function validateAndParseImportedJSON(rawText: string): ImportValidationResult {
  try {
    const parsed = JSON.parse(rawText);

    // Support both direct config object and wrapped export payload
    const config: CollegeConfig = parsed.config ? parsed.config : parsed;
    const sessions: PlacedSession[] = parsed.sessions || [];

    if (!config.collegeName) return { valid: false, error: 'Missing collegeName in JSON' };
    if (!Array.isArray(config.workingDays) || config.workingDays.length === 0) {
      return { valid: false, error: 'Invalid or missing workingDays array' };
    }
    if (!Array.isArray(config.periods) || config.periods.length === 0) {
      return { valid: false, error: 'Invalid or missing periods array' };
    }
    if (!Array.isArray(config.rooms) || config.rooms.length === 0) {
      return { valid: false, error: 'Invalid or missing rooms array' };
    }
    if (!Array.isArray(config.faculty) || config.faculty.length === 0) {
      return { valid: false, error: 'Invalid or missing faculty array' };
    }
    if (!Array.isArray(config.subjects) || config.subjects.length === 0) {
      return { valid: false, error: 'Invalid or missing subjects array' };
    }
    if (!Array.isArray(config.divisions) || config.divisions.length === 0) {
      return { valid: false, error: 'Invalid or missing divisions array' };
    }
    if (!Array.isArray(config.assignments) || config.assignments.length === 0) {
      return { valid: false, error: 'Invalid or missing assignments array' };
    }

    if (!Array.isArray(config.schedulablePeriodIds)) {
      config.schedulablePeriodIds = config.periods
        .filter((p) => p.type === 'lecture')
        .map((p) => p.id);
    }
    if (!config.maxBacktracks) {
      config.maxBacktracks = 100000;
    }

    return { valid: true, config, sessions };
  } catch (err: any) {
    return { valid: false, error: `Invalid JSON file syntax: ${err.message}` };
  }
}
