# CampusFlow — Smart College Timetable Generator

**CampusFlow** is a complete, production-grade, constraint-based college timetable generator built with React, TypeScript, Vite, and Tailwind CSS for academic institutions and college hackathons.

Unlike shallow UI mockups or templates, CampusFlow contains a **genuine Constraint Satisfaction Problem (CSP) scheduling engine** running natively in TypeScript on the client. It automatically generates valid, conflict-free weekly timetables across multiple divisions, faculty members, classrooms, and laboratories without requiring any external backend, database, or API keys.

---

## 🚀 Key Features

### 1. Genuine Constraint Satisfaction Engine (CSP)
- **Recursive Backtracking with MCV Heuristic:** Uses the *Most Constrained Variable* (MCV) heuristic to order tasks before search, prioritizing multi-period laboratory practical blocks and tightly constrained resources to avoid combinatorial traps.
- **Least Constraining Value (LCV) & Soft Preferences:** Scores slot candidates by faculty and subject preferences (preferred teaching days and morning/afternoon slots).
- **Zero Hallucination / Honest Diagnostics:** Distinguishes between complete (100% placed) and partial timetables. When constraints are mathematically impossible (e.g., insufficient lab hours or overloaded faculty), it highlights the unplaced sessions with actionable suggestions (e.g. "Add a second lab", "Relax Prof. X's Wednesday restriction").

### 2. Multi-Perspective Interactive Timetable View
- **Class-Wise View:** View weekly schedules for individual student divisions (e.g., CS Division A, CS Division B).
- **Faculty-Wise View:** View individual weekly schedules for any professor, showing their daily workload and teaching assignments.
- **Room-Wise View:** Inspect allocation and utilization across lecture halls and specialized laboratories.
- **Subject Color Coding:** Each subject features distinct, high-contrast visual styling for instant recognition.
- **Visual Distinctions:** Distinct cards and badges for single lectures, consecutive practical blocks, tea breaks, lunch intervals, and free periods.

### 3. Safe Manual Relocation & Clash Prevention
- Click any timetable session to inspect detailed batch size, faculty email, room capacity, and timing.
- **Interactive Move Modal:** Test relocating a session to another day, period, or room with real-time constraint validation.
- Conflicting edits (such as faculty double-booking, room overlap, capacity violation, or breaking practical continuity) are **strictly rejected with explicit diagnostic explanations**.
- **Undo Edit:** One-click rollback for any manual modification.

### 4. Comprehensive College & Resource Management
- **College & Schedule Configuration:** Configure institution name, department, semester, working days (5 or 6-day weeks), daily period counts, timestamps, and tea/lunch breaks.
- **Subject Management:** Full CRUD with weekly lecture counts, practical counts, required consecutive periods, and required room/lab types.
- **Faculty Management:** Workload caps (max periods/day and max periods/week) with an **interactive Day × Period availability matrix** to block out research days or committee meetings.
- **Facility Management:** Classrooms and labs with seating capacities and scheduled maintenance windows.

### 5. Local Storage, Export & Print Notice-Board Support
- **LocalStorage Persistence:** All user changes (curricula, faculty, rooms, settings, and generated sessions) automatically persist on the browser.
- **Reset to Demo Data:** One-click restoration of the realistic demo college schedule with modal confirmation.
- **Export & Import JSON:** Full project backup and restore with strict schema verification and error handling.
- **CSV Export:** Download notice-board ready CSV files filtered by division.
- **Print Optimization:** Print-friendly stylesheet (`window.print()`) that formats clean timetables for display.

---

## 🏛️ Constraint Specification

### Hard Constraints (Strictly Enforced)
Hard constraints are never silently violated:
- **C1 (Division No Double-Booking):** No class division can have more than one session in the same period.
- **C2 (Faculty No Double-Booking):** No professor can teach two sessions simultaneously.
- **C3 (Room No Double-Booking):** No classroom or laboratory can host multiple sessions simultaneously.
- **C4 (Faculty Availability):** Sessions are never placed during a professor's blocked slots (e.g., research days, leave).
- **C5 (Room Availability):** Sessions are never placed during room maintenance windows.
- **C6 (Room Type Compatibility):** Lectures must be assigned to classrooms; practicals must be assigned to laboratories.
- **C7 (Room Seating Capacity):** Classrooms must accommodate full division strength; labs must accommodate lab batch sizes.
- **C8 (Practical Consecutive Blocks):** Practicals requiring $N$ periods must occupy consecutive periods on the same day without crossing break or lunch slots.
- **C9 (Faculty Daily Load Cap):** A professor's daily teaching periods cannot exceed `maxPeriodsPerDay`.
- **C10 (Faculty Weekly Load Cap):** A professor's weekly teaching periods cannot exceed `maxPeriodsPerWeek`.

### Soft Constraints (Optimized via Heuristics)
- Preferred teaching days specified by department heads.
- Preferred morning vs. afternoon periods.
- Balanced spread of difficult courses throughout the week.

---

## 📁 Project Architecture

```
campusflow/
├── index.html                   # HTML entry point with Inter typography
├── package.json                 # Dependencies and scripts
├── tsconfig.json                # Strict TypeScript configuration
├── vite.config.ts               # Vite configuration
├── tailwind.config.js           # Navy & subtle gold color palette
├── postcss.config.js            # PostCSS plugins
├── src/
│   ├── types/
│   │   └── index.ts             # TypeScript definitions & data models
│   ├── engine/
│   │   ├── scheduler.ts         # CSP backtracking search engine + MCV heuristic
│   │   ├── validator.ts         # Independent 15-rule constraint validator
│   │   ├── editor.ts            # Manual session move proposal & validation
│   │   ├── demoData.ts          # Realistic demo dataset (CSE Dept, 2 Divs, 6 Subjs)
│   │   └── exportUtils.ts       # CSV export, JSON backup/restore, print layout
│   ├── storage/
│   │   └── localStorage.ts      # LocalStorage manager with versioned fallbacks
│   ├── components/
│   │   ├── common/
│   │   │   ├── Navbar.tsx       # Brand, solver status badge, generate button, export
│   │   │   ├── Sidebar.tsx      # Sidebar navigation with rule violation counters
│   │   │   ├── Toast.tsx        # Toast notifications
│   │   │   └── ConfirmModal.tsx # Confirmation modals for resets & deletions
│   │   ├── dashboard/
│   │   │   └── Dashboard.tsx    # Live calculated KPIs, load charts, conflict alerts
│   │   ├── timetable/
│   │   │   ├── TimetableGrid.tsx      # Interactive weekly grid (Class/Faculty/Room)
│   │   │   ├── SessionDetailModal.tsx # Cell inspection drawer
│   │   │   └── MoveSessionModal.tsx   # Live validated relocation modal
│   │   ├── config/
│   │   │   └── CollegeConfigForm.tsx  # Settings, working days, period timings
│   │   ├── subjects/
│   │   │   ├── SubjectManagement.tsx  # Subject list & division faculty allocation
│   │   │   └── SubjectModal.tsx       # Add/edit subject with lab parameters
│   │   ├── faculty/
│   │   │   ├── FacultyManagement.tsx  # Faculty roster & workload progress
│   │   │   ├── FacultyModal.tsx       # Day × Period availability matrix toggle
│   │   │   └── FacultyScheduleModal.tsx # Individual professor weekly timetable
│   │   ├── rooms/
│   │   │   ├── RoomManagement.tsx     # Classrooms and labs management
│   │   │   └── RoomModal.tsx          # Capacity and maintenance downtime editor
│   │   └── diagnostics/
│   │       └── DiagnosticsPanel.tsx   # 10-rule compliance matrix & remediation
│   ├── App.tsx                  # Root state container & lifecycle
│   ├── main.tsx                 # React DOM mount
│   └── index.css                # Tailwind directives & print layout styles
└── tests/
    └── scheduler.test.cjs       # 41 automated unit tests verifying the scheduler
```

---

## 🛠️ Getting Started

### Prerequisites
- Node.js (v18.0.0 or higher; v20+ / v22+ recommended)
- npm (v9.0.0 or higher)

### Installation & Run

1. **Clone or navigate to the project directory:**
   ```bash
   cd campusflow
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Start the development server:**
   ```bash
   npm run dev
   ```
   Open your browser at `http://localhost:3000` (or the port shown in terminal).

4. **Build for production:**
   ```bash
   npm run build
   ```
   Generates an optimized bundle in `dist/`.

5. **Preview production build:**
   ```bash
   npm run preview
   ```

---

## 🧪 Automated Testing

CampusFlow includes a comprehensive unit test suite covering **41 test cases** across 22 test suites testing:
- Complete timetable generation for feasible configurations
- Division, faculty, and room clash detection and prevention
- Faculty availability restrictions (blocked slots)
- Room type matching (practical sessions in labs only)
- Room maintenance periods
- Consecutive period allocation for laboratory practicals
- Faculty daily and weekly workload caps
- Impossible configuration handling (zero rooms, blocked faculty)
- Manual move proposal validation and clash rejection
- Independent validator integrity verification (V01 to V15)

To run the automated test suite:
```bash
npm test
```

Expected output:
```
# tests 41
# suites 22
# pass 41
# fail 0
```

---

## 🔮 Future Integration Notes (Backend & Database)

CampusFlow is designed with clean architectural boundaries. When scaling to a full client-server multi-tenant architecture:

1. **Backend API (Node.js / Express or NestJS):**
   - The scheduling engine in `src/engine/scheduler.ts` and `src/engine/validator.ts` contains zero DOM dependencies and can be imported directly into a Node.js backend.
   - Endpoints: `POST /api/timetable/generate`, `POST /api/timetable/validate`, `POST /api/timetable/propose-move`.

2. **Database Schema (PostgreSQL with Prisma / Supabase):**
   - `colleges`: `id, name, department, academic_year, semester`
   - `periods`: `id, college_id, period_number, start_time, end_time, period_type`
   - `faculty`: `id, college_id, name, email, max_daily_load, max_weekly_load, blocked_slots`
   - `rooms`: `id, college_id, name, room_type, capacity, blocked_slots`
   - `subjects`: `id, college_id, code, name, lectures_per_week, practicals_per_week, practical_periods, room_type, lab_room_type`
   - `timetable_sessions`: `id, timetable_id, division_id, subject_id, faculty_id, room_id, day, period_ids`

3. **Authentication & Multi-Tenancy:**
   - Add role-based access control (Admin, HOD, Professor, Student).
   - Professors can submit leave and view their individual timetable on mobile.
   - Students can subscribe to their division's calendar via iCal/Google Calendar feeds.
